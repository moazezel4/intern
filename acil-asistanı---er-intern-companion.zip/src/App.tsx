/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { LanguageProvider } from './context/LanguageContext';
import { Header } from './components/Header';
import { BottomNav, TabType } from './components/BottomNav';
import { DrugsView } from './components/DrugsView';
import { PrescriptionsView } from './components/PrescriptionsView';
import { HistoryTakingView } from './components/HistoryTakingView';
import { CalculatorsView } from './components/CalculatorsView';
import { PearlsView } from './components/PearlsView';
import { AIConsultantView } from './components/AIConsultantView';

function AppContent() {
  const [activeTab, setActiveTab] = useState<TabType>('drugs');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-rose-500 selection:text-white">
      {/* Android-like Top Header */}
      <Header onOpenAI={() => setActiveTab('ai')} />

      {/* Main View Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto p-3 sm:p-4">
        {activeTab === 'drugs' && <DrugsView />}
        {activeTab === 'prescriptions' && <PrescriptionsView />}
        {activeTab === 'history' && <HistoryTakingView />}
        {activeTab === 'calculators' && <CalculatorsView />}
        {activeTab === 'pearls' && <PearlsView />}
        {activeTab === 'ai' && <AIConsultantView />}
      </main>

      {/* Android-like Bottom Navigation */}
      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}

