import { ClinicalCalculator } from '../types';

export const CLINICAL_CALCULATORS_DATABASE: ClinicalCalculator[] = [
  {
    id: 'wells_pe',
    name: {
      tr: 'Wells Pulmoner Emboli (PE) Skoru',
      en: 'Wells Score for Pulmonary Embolism',
    },
    shortName: 'Wells PE',
    category: {
      tr: 'Kardiyovasküler & Pulmoner',
      en: 'Cardiovascular & Pulmonary',
    },
    description: {
      tr: 'Pulmoner emboli şüphesi olan hastalarda klinik olasılığı belirleyerek D-Dimer ve Toraks BT Anjiyo ihtiyacını yönlendirir.',
      en: 'Stratifies pre-test probability of pulmonary embolism to guide D-Dimer vs CTPA testing.',
    },
    items: [
      {
        id: 'dvt_signs',
        label: {
          tr: 'DVT klinik bulgu ve semptomları (bacakta asimetrik ödem, baldırda derin ven boyunca hassasiyet)',
          en: 'Clinical signs and symptoms of DVT (leg swelling, tenderness along deep veins)',
        },
        options: [
          { label: { tr: 'Hayır (Yok)', en: 'No (Absent)' }, points: 0 },
          { label: { tr: 'Evet (Mevcut)', en: 'Yes (Present)' }, points: 3.0 },
        ],
      },
      {
        id: 'pe_most_likely',
        label: {
          tr: 'PE alternatif bir tanıdan daha muhtemel veya eşit olasılıkta mı?',
          en: 'PE is #1 diagnosis or equally likely as an alternative diagnosis',
        },
        options: [
          { label: { tr: 'Hayır', en: 'No' }, points: 0 },
          { label: { tr: 'Evet', en: 'Yes' }, points: 3.0 },
        ],
      },
      {
        id: 'tachycardia',
        label: {
          tr: 'Taşikardi (Kalp Hızı > 100 atım/dakika)',
          en: 'Tachycardia (Heart rate > 100 bpm)',
        },
        options: [
          { label: { tr: 'Hayır (KH ≤ 100)', en: 'No (HR ≤ 100)' }, points: 0 },
          { label: { tr: 'Evet (KH > 100)', en: 'Yes (HR > 100)' }, points: 1.5 },
        ],
      },
      {
        id: 'immobilization_surgery',
        label: {
          tr: 'Son 4 hafta içinde immobilizasyon (en az 3 gün yatak istirahati) veya majör cerrahi',
          en: 'Immobilization (≥3 consecutive days of bed rest) or surgery in previous 4 weeks',
        },
        options: [
          { label: { tr: 'Hayır', en: 'No' }, points: 0 },
          { label: { tr: 'Evet', en: 'Yes' }, points: 1.5 },
        ],
      },
      {
        id: 'previous_dvt_pe',
        label: {
          tr: 'Daha önceden objektif olarak kanıtlanmış DVT veya PE öyküsü',
          en: 'Previous documented DVT or PE history',
        },
        options: [
          { label: { tr: 'Hayır', en: 'No' }, points: 0 },
          { label: { tr: 'Evet', en: 'Yes' }, points: 1.5 },
        ],
      },
      {
        id: 'hemoptysis',
        label: {
          tr: 'Hemoptizi (Öksürükle kan gelmesi)',
          en: 'Hemoptysis (coughing up blood)',
        },
        options: [
          { label: { tr: 'Hayır', en: 'No' }, points: 0 },
          { label: { tr: 'Evet', en: 'Yes' }, points: 1.0 },
        ],
      },
      {
        id: 'malignancy',
        label: {
          tr: 'Aktif kanser (Son 6 ayda tedavi alan veya palyatif evrede)',
          en: 'Active malignancy (treated within last 6 months or palliative)',
        },
        options: [
          { label: { tr: 'Hayır', en: 'No' }, points: 0 },
          { label: { tr: 'Evet', en: 'Yes' }, points: 1.0 },
        ],
      },
    ],
    interpretations: [
      {
        minScore: 0,
        maxScore: 1.9,
        riskLevel: 'low',
        title: {
          tr: 'Düşük Riskli PE Olasılığı (<%10)',
          en: 'Low Probability of PE (<10%)',
        },
        management: {
          tr: 'Önce PERC Kriterlerini değerlendirin. PERC 8/8 negatif ise PE test yapmadan dışlanır. PERC pozitifse D-Dimer testi isteyin. D-Dimer negatif (<500 mcg/L) ise PE dışlanır; pozitifse Toraks BT Anjiyo (CTPA) çekin.',
          en: 'Evaluate PERC criteria. If PERC is completely negative (0/8), PE is safely ruled out without testing. If PERC positive, order D-Dimer. If D-Dimer is negative, PE ruled out; if elevated, perform CTPA.',
        },
      },
      {
        minScore: 2.0,
        maxScore: 6.0,
        riskLevel: 'moderate',
        title: {
          tr: 'Orta Riskli PE Olasılığı (~%30)',
          en: 'Moderate Probability of PE (~30%)',
        },
        management: {
          tr: 'Yüksek duyarlılıklı D-DİMER testi isteyin (veya yaşa göre düzeltilmiş D-dimer: Yaş x 10). D-Dimer normal ise PE dışlanır. D-Dimer yüksek ise acil TORAKS BT ANJİYO (CTPA) çekilmelidir.',
          en: 'Order high-sensitivity D-Dimer (or age-adjusted cut-off: Age x 10). If negative, PE excluded. If elevated, obtain urgent CTPA.',
        },
      },
      {
        minScore: 6.5,
        maxScore: 12.5,
        riskLevel: 'high',
        title: {
          tr: 'Yüksek Riskli PE Olasılığı (>%65)',
          en: 'High Probability of PE (>65%)',
        },
        management: {
          tr: 'D-Dimer testi ile vakit kaybetmeyin! Doğrudan TORAKS BT ANJİYO (CTPA) çekin. Görüntüleme gecikecekse ve kanama kontrendikasyonu yoksa ilk doz CLEXANE (1 mg/kg SC) hemen verilebilir.',
          en: 'Do not wait for D-Dimer! Order immediate CTPA. If CTPA is delayed and no major bleeding contraindications exist, administer first therapeutic dose of Enoxaparin 1 mg/kg SC.',
        },
      },
    ],
  },
  {
    id: 'heart_score',
    name: {
      tr: 'HEART Göğüs Ağrısı Risk Skoru',
      en: 'HEART Score for Major Cardiac Events',
    },
    shortName: 'HEART Score',
    category: {
      tr: 'Kardiyoloji & Acil Tıp',
      en: 'Cardiology & Emergency Medicine',
    },
    description: {
      tr: 'Acil servise başvuran göğüs ağrılı hastalarda 6 haftalık Majör İstenmeyen Kardiyak Olay (MACE) riskini belirler.',
      en: 'Predicts 6-week risk of Major Adverse Cardiac Events (MACE) in ER chest pain patients.',
    },
    items: [
      {
        id: 'history',
        label: {
          tr: 'H - Hikaye / Anamnez (History)',
          en: 'H - History',
        },
        options: [
          { label: { tr: 'Düşük şüpheli (Non-spesifik / plöritik / muskuloskeletal)', en: 'Slightly suspicious' }, points: 0 },
          { label: { tr: 'Orta derecede şüpheli', en: 'Moderately suspicious' }, points: 1 },
          { label: { tr: 'Yüksek derecede şüpheli (Tipik retrosternal baskı, yayılım, terleme)', en: 'Highly suspicious' }, points: 2 },
        ],
      },
      {
        id: 'ecg',
        label: {
          tr: 'E - EKG Bulguları (Electrocardiogram)',
          en: 'E - ECG',
        },
        options: [
          { label: { tr: 'Normal EKG', en: 'Normal' }, points: 0 },
          { label: { tr: 'Non-spesifik repolarizasyon bozukluğu / LBBB / Dijital etkisi', en: 'Non-specific repolarization disturbance / LBBB' }, points: 1 },
          { label: { tr: 'Belirgin ST çökmesi / T negatifliği (Yeni iskemik değişiklik)', en: 'Significant ST depression / T-wave inversion' }, points: 2 },
        ],
      },
      {
        id: 'age',
        label: {
          tr: 'A - Yaş (Age)',
          en: 'A - Age',
        },
        options: [
          { label: { tr: '< 45 Yaş', en: '< 45 years' }, points: 0 },
          { label: { tr: '45 - 64 Yaş', en: '45 - 64 years' }, points: 1 },
          { label: { tr: '≥ 65 Yaş', en: '≥ 65 years' }, points: 2 },
        ],
      },
      {
        id: 'risk_factors',
        label: {
          tr: 'R - Risk Faktörleri (HT, DM, Sigara, Hiperlipidemi, Ailede erken KAH, Obezite)',
          en: 'R - Risk Factors (HT, DM, Smoking, Hyperlipidemia, Family history, Obesity)',
        },
        options: [
          { label: { tr: 'Risk faktörü yok', en: 'No known risk factors' }, points: 0 },
          { label: { tr: '1 veya 2 risk faktörü', en: '1 or 2 risk factors' }, points: 1 },
          { label: { tr: '≥ 3 risk faktörü VEYA bilinen koroner arter / aterosklerotik hastalık', en: '≥ 3 risk factors or established CAD/stroke' }, points: 2 },
        ],
      },
      {
        id: 'troponin',
        label: {
          tr: 'T - İlk Kardiyak Troponin Düzeyi (Initial Troponin)',
          en: 'T - Initial Troponin',
        },
        options: [
          { label: { tr: 'Normal sınırda (≤ 99. persentil üst referans limiti)', en: '≤ Normal limit (≤ 99th percentile URL)' }, points: 0 },
          { label: { tr: '1 - 3 kat arası hafif yüksek', en: '1 - 3x normal limit' }, points: 1 },
          { label: { tr: '> 3 kat belirgin yüksek', en: '> 3x normal limit' }, points: 2 },
        ],
      },
    ],
    interpretations: [
      {
        minScore: 0,
        maxScore: 3,
        riskLevel: 'low',
        title: {
          tr: 'Düşük Risk (MACE Riski: %0.9 - %1.7)',
          en: 'Low Risk (MACE Risk: 0.9% - 1.7%)',
        },
        management: {
          tr: 'Hasta erken taburculuk için adaydır. İkinci seri troponin normalse ve klinik stabilse kardiyoloji poliklinik kontrolü önerilerek güvenle taburcu edilebilir.',
          en: 'Candidate for early discharge. If repeat troponin is negative and clinically stable, can safely be discharged with outpatient cardiology follow-up.',
        },
      },
      {
        minScore: 4,
        maxScore: 6,
        riskLevel: 'moderate',
        title: {
          tr: 'Orta Risk (MACE Riski: %12 - %17)',
          en: 'Moderate Risk (MACE Risk: 12% - 17%)',
        },
        management: {
          tr: 'Acilde gözlem veya koroner ara bakım yatışı önerilir. Seri troponin ve seri EKG takibi yapılmalı, iskemi testi (Efor/EKO) planlanmalıdır.',
          en: 'Recommend ER observation or telemetry admission. Perform serial troponins/ECGs and arrange non-invasive ischemia testing.',
        },
      },
      {
        minScore: 7,
        maxScore: 10,
        riskLevel: 'high',
        title: {
          tr: 'Yüksek Risk (MACE Riski: >%50 - %65)',
          en: 'High Risk (MACE Risk: >50% - 65%)',
        },
        management: {
          tr: 'Acil KARDİYOLOJİ KONSÜLTASYONU ve KORONER YOĞUN BAKIM YATIŞI! Erken invaziv koroner anjiyografi endikasyonu değerlendirilmeli, antiagregan ve antikoagülan yüklemesi yapılmalıdır.',
          en: 'Immediate CARDIOLOGY CONSULTATION and CCU ADMISSION! Urgent coronary angiography indicated; initiate dual antiplatelet and anticoagulation therapy.',
        },
      },
    ],
  },
  {
    id: 'alvarado_score',
    name: {
      tr: 'Alvarado Akut Apandisit Skoru (MANTRELS)',
      en: 'Alvarado Score for Acute Appendicitis',
    },
    shortName: 'Alvarado',
    category: {
      tr: 'Genel Cerrahi & Karın Ağrısı',
      en: 'General Surgery & Abdominal Pain',
    },
    description: {
      tr: 'Akut karın ağrısı olan hastalarda akut apandisit olasılığını belirleyerek cerrahi konsültasyonu ve batın görüntüleme ihtiyacını yönlendirir.',
      en: 'Assesses the likelihood of acute appendicitis in emergency patients with right lower quadrant pain.',
    },
    items: [
      {
        id: 'migration',
        label: {
          tr: 'M - Ağrının sağ alt kadrana göç etmesi (Migration of pain to RLQ)',
          en: 'M - Migration of pain to RLQ',
        },
        options: [
          { label: { tr: 'Hayır', en: 'No' }, points: 0 },
          { label: { tr: 'Evet', en: 'Yes' }, points: 1 },
        ],
      },
      {
        id: 'anorexia',
        label: {
          tr: 'A - İştahsızlık veya idrarda aseton (Anorexia)',
          en: 'A - Anorexia',
        },
        options: [
          { label: { tr: 'Hayır', en: 'No' }, points: 0 },
          { label: { tr: 'Evet', en: 'Yes' }, points: 1 },
        ],
      },
      {
        id: 'nausea_vomiting',
        label: {
          tr: 'N - Bulantı veya kusma (Nausea / Vomiting)',
          en: 'N - Nausea / Vomiting',
        },
        options: [
          { label: { tr: 'Hayır', en: 'No' }, points: 0 },
          { label: { tr: 'Evet', en: 'Yes' }, points: 1 },
        ],
      },
      {
        id: 'tenderness_rlq',
        label: {
          tr: 'T - Sağ alt kadranda (McBurney) hassasiyet (Tenderness in RLQ - 2 Puan!)',
          en: 'T - Tenderness in RLQ (2 Points!)',
        },
        options: [
          { label: { tr: 'Hayır', en: 'No' }, points: 0 },
          { label: { tr: 'Evet', en: 'Yes' }, points: 2 },
        ],
      },
      {
        id: 'rebound',
        label: {
          tr: 'R - Rebound (Blumberg) hassasiyeti (Rebound pain in RLQ)',
          en: 'R - Rebound pain in RLQ',
        },
        options: [
          { label: { tr: 'Hayır', en: 'No' }, points: 0 },
          { label: { tr: 'Evet', en: 'Yes' }, points: 1 },
        ],
      },
      {
        id: 'elevation_temp',
        label: {
          tr: 'E - Ateş yüksekliği (Aksiller ≥ 37.3°C / Oral ≥ 37.8°C)',
          en: 'E - Elevated temperature (≥ 37.3°C axillary)',
        },
        options: [
          { label: { tr: 'Hayır', en: 'No' }, points: 0 },
          { label: { tr: 'Evet', en: 'Yes' }, points: 1 },
        ],
      },
      {
        id: 'leukocytosis',
        label: {
          tr: 'L - Lökositoz (WBC > 10.000 / mm3 - 2 Puan!)',
          en: 'L - Leukocytosis (WBC > 10,000 / mm3 - 2 Points!)',
        },
        options: [
          { label: { tr: 'Hayır (WBC ≤ 10k)', en: 'No' }, points: 0 },
          { label: { tr: 'Evet (WBC > 10k)', en: 'Yes' }, points: 2 },
        ],
      },
      {
        id: 'shift_left',
        label: {
          tr: 'S - Nötrofil sola kayması (Nötrofil > %75)',
          en: 'S - Shift to the left (Neutrophils > 75%)',
        },
        options: [
          { label: { tr: 'Hayır', en: 'No' }, points: 0 },
          { label: { tr: 'Evet', en: 'Yes' }, points: 1 },
        ],
      },
    ],
    interpretations: [
      {
        minScore: 0,
        maxScore: 4,
        riskLevel: 'low',
        title: {
          tr: 'Düşük Apandisit Olasılığı (Skor 0-4)',
          en: 'Low Probability of Appendicitis (Score 0-4)',
        },
        management: {
          tr: 'Apandisit tanısı olası değildir. Diğer gastroenterit, jinekolojik ve ürolojik nedenleri araştırın. Klinik stabilse taburculuk ve semptom artarsa acile tekrar başvuru önerilir.',
          en: 'Appendicitis is unlikely. Look for alternative medical, urological, or gynecological causes. Safe for discharge with clear return precautions.',
        },
      },
      {
        minScore: 5,
        maxScore: 6,
        riskLevel: 'moderate',
        title: {
          tr: 'Şüpheli Apandisit Olasılığı (Skor 5-6)',
          en: 'Equivocal / Possible Appendicitis (Score 5-6)',
        },
        management: {
          tr: 'Batın Ultrasonografisi (USG) veya IV Kontrastlı Batın BT çekilmeli, Genel Cerrahi konsültasyonu istenmeli ve acilde oral alım stoplanarak (NPO) gözlenmelidir.',
          en: 'Obtain Abdominal Ultrasound or IV-contrast CT. Request General Surgery consultation and keep NPO under observation.',
        },
      },
      {
        minScore: 7,
        maxScore: 10,
        riskLevel: 'high',
        title: {
          tr: 'Çok Yüksek Apandisit Olasılığı (Skor 7-10)',
          en: 'High Probability of Appendicitis (Score 7-10)',
        },
        management: {
          tr: 'ACİL GENEL CERRAHİ KONSÜLTASYONU ve AMELİYATHANE HAZIRLIĞI! Damar yolu açın, IV SF infüzyonu başlayın, oral alımı derhal kesin (NPO). Tanısal doğrulama için acil kontrastlı batın BT veya doğrudan diagnostik laparoskopi planlanır.',
          en: 'EMERGENT GENERAL SURGERY CONSULTATION FOR APENDECTOMY! Keep strictly NPO, start IV fluids, and prepare for surgical intervention or confirmatory CT scan.',
        },
      },
    ],
  },
  {
    id: 'gcs_score',
    name: {
      tr: 'Glasgow Koma Skalası (GKS / GCS)',
      en: 'Glasgow Coma Scale (GCS)',
    },
    shortName: 'GCS (GKS)',
    category: {
      tr: 'Nöroloji & Travma Resüsitasyonu',
      en: 'Neurology & Trauma Resuscitation',
    },
    description: {
      tr: 'Bilinç düzeyini ve travma şiddetini değerlendiren altın standart skaladır (Göz, Sözlü, Motor yanıtlar).',
      en: 'Gold standard objective assessment of conscious state in trauma and altered mental status.',
    },
    items: [
      {
        id: 'eye_opening',
        label: {
          tr: 'Göz Açma Yanıtı (Eye Opening - E1-E4)',
          en: 'Eye Opening Response (E1-E4)',
        },
        options: [
          { label: { tr: '1: Hiç açmıyor (Ağrılı uyarana dahi yanıtsız)', en: '1: None (No response to pain)' }, points: 1 },
          { label: { tr: '2: Ağrılı uyaranla açıyor (Trapezius basısı veya tırnak yatağı uyarısı ile)', en: '2: To pain (opens eyes to pressure/trapezius squeeze)' }, points: 2 },
          { label: { tr: '3: Sesli uyaranla açıyor ("Gözlerinizi açın" komutu ile)', en: '3: To speech / sound' }, points: 3 },
          { label: { tr: '4: Spontan açık (Kendiliğinden)', en: '4: Spontaneous (open at baseline)' }, points: 4 },
        ],
      },
      {
        id: 'verbal_response',
        label: {
          tr: 'Sözlü / Sözel Yanıt (Verbal Response - V1-V5)',
          en: 'Verbal Response (V1-V5)',
        },
        options: [
          { label: { tr: '1: Hiç ses yok (Yanıtsız)', en: '1: None (No vocalization)' }, points: 1 },
          { label: { tr: '2: Anlamsız sesler / İnleme (Gruting / Groaning)', en: '2: Incomprehensible sounds (moaning/groaning)' }, points: 2 },
          { label: { tr: '3: Uygunsuz kelimeler (Rastgele bağırma, küfretme, konuyla alakasız)', en: '3: Inappropriate words (random disconnected words)' }, points: 3 },
          { label: { tr: '4: Konfüze / Dezoryante (Konuşuyor ama yer, zaman veya kişiyi karıştırıyor)', en: '4: Confused conversation (disoriented to time/place)' }, points: 4 },
          { label: { tr: '5: Oryante ve Koopere (Kişi, yer, zaman ve olaya tam uyumlu)', en: '5: Oriented (knows name, location, date, context)' }, points: 5 },
        ],
      },
      {
        id: 'motor_response',
        label: {
          tr: 'Motor Yanıt (Motor Response - M1-M6)',
          en: 'Motor Response (M1-M6)',
        },
        options: [
          { label: { tr: '1: Hiç yanıt yok (Flask paralizi)', en: '1: None (Flaccid)' }, points: 1 },
          { label: { tr: '2: Anormal Ekstansiyon (Deserebre Postür - Kollar içe rotasyon ve ekstansiyonda)', en: '2: Abnormal Extension (Decerebrate posturing)' }, points: 2 },
          { label: { tr: '3: Anormal Fleksiyon (Dekortike Postür - Kollar göğse doğru fleksiyonda)', en: '3: Abnormal Flexion (Decorticate posturing)' }, points: 3 },
          { label: { tr: '4: Ağrıdan kaçma / Fleksiyon (Ağrılı uyarandan kolunu/bacağını geri çekiyor)', en: '4: Normal flexion / Withdrawal to pain' }, points: 4 },
          { label: { tr: '5: Ağrıyı lokalize etme (Ağrılı uyaran verilen noktayı eliyle uzaklaştırmaya çalışıyor)', en: '5: Localizes to pain (brings hand above clavicle)' }, points: 5 },
          { label: { tr: '6: Komutlara uyuyor ("Dilini çıkar, iki parmağımı sık" komutlarını başarıyla yapıyor)', en: '6: Obeys commands fully' }, points: 6 },
        ],
      },
    ],
    interpretations: [
      {
        minScore: 3,
        maxScore: 8,
        riskLevel: 'high',
        title: {
          tr: 'Ağır Kafa Travması / Koma (GKS ≤ 8) -> "GCS 8, ENTÜBE ET!"',
          en: 'Severe Head Injury / Coma (GCS ≤ 8) -> "GCS 8, Intubate!"',
        },
        management: {
          tr: 'ACİL HAVA YOLU GÜVENLİĞİ VE ENTÜBASYON ENDİKASYONU! Hastanın aspirasyon ve hipoksi riski çok yüksektir. Hızlı Seri Entübasyon (RSI) hazırlığı yapın, beyin cerrahisi ve yoğun bakım konsültasyonu isteyin, acil kontrastsız Beyin BT çekin.',
          en: 'IMMEDIATE AIRWAY PROTECTION AND INTUBATION MANDATE ("GCS less than 8, intubate!"). High aspiration and secondary brain injury risk. Perform RSI, urgent non-contrast Head CT, and neurosurgery consult.',
        },
      },
      {
        minScore: 9,
        maxScore: 12,
        riskLevel: 'moderate',
        title: {
          tr: 'Orta Dereceli Kafa Travması (GKS 9-12)',
          en: 'Moderate Head Injury (GCS 9-12)',
        },
        management: {
          tr: 'Acil Kontrastsız Beyin BT çekilmeli, yakın nörolojik takip yapılmalı, aspirasyona karşı hava yolu hazırda tutulmalı ve yoğun bakım / beyin cerrahisi konsültasyonu planlanmalıdır.',
          en: 'Mandatory non-contrast Head CT, continuous neurologic checks, and neurosurgical consultation.',
        },
      },
      {
        minScore: 13,
        maxScore: 15,
        riskLevel: 'low',
        title: {
          tr: 'Hafif / Minör Kafa Travması (GKS 13-15)',
          en: 'Minor Head Injury (GCS 13-15)',
        },
        management: {
          tr: 'Canadian CT Head Rule veya New Orleans Kriterlerine göre Beyin BT endikasyonunu değerlendirin (Kusma ≥2, yaş ≥65, antikoagülan kullanımı, şüpheli kafatası kırığı varsa BT çekilir).',
          en: 'Apply Canadian CT Head Rule to decide on Head CT necessity (indicated if age ≥65, vomiting ≥2 episodes, coagulopathy, suspected skull fracture).',
        },
      },
    ],
  },
];
