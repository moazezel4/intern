import { ERDrug } from '../types';

export const ER_DRUGS_DATABASE: ERDrug[] = [
  // --- ANALGESICS & NSAIDs & SPASMOLYTICS ---
  {
    id: 'paracetamol',
    genericName: {
      tr: 'Parasetamol (Asetaminofen)',
      en: 'Paracetamol (Acetaminophen)',
    },
    brandNamesTR: ['Parol', 'Perfalgan', 'Minoset', 'Tylol', 'Partem'],
    category: {
      tr: 'Analjezik / Antipiretik',
      en: 'Analgesic / Antipyretic',
    },
    forms: [
      '10 mg/ml (1000 mg / 100 ml) IV Flakon',
      '500 mg Tablet',
      '120 mg / 5 ml & 250 mg / 5 ml Şurup',
      '120 mg & 250 mg Supozituvar (Fitil)',
    ],
    indications: {
      tr: [
        'Hafif-orta şiddette akut ağrılar (baş ağrısı, kas iskelet ağrısı, dismenore)',
        'Ateş yüksekliği (Febril durumlar)',
        'Opioid sparing multimodal analjezi',
      ],
      en: [
        'Mild to moderate acute pain (headache, musculoskeletal pain, dysmenorrhea)',
        'Fever reduction',
        'Multimodal opioid-sparing analgesia',
      ],
    },
    erAdultDose: {
      tr: '1000 mg IV infüzyon (15 dakikada) veya 500-1000 mg PO. Maksimum günlük doz: 4000 mg (Kronik karaciğer hastalığı veya alkolizmde maks 2000 mg/gün). Doz aralığı en az 4-6 saat olmalıdır.',
      en: '1000 mg IV infusion (over 15 min) or 500-1000 mg PO. Max daily dose: 4000 mg (In chronic liver disease or alcoholism max 2000 mg/day). Minimum interval 4-6 hours.',
    },
    erPediatricDose: {
      tr: '10-15 mg/kg/doz (PO veya IV). Maksimum tek doz 1000 mg, maksimum günlük 60 mg/kg/gün veya 4000 mg.',
      en: '10-15 mg/kg/dose (PO or IV). Max single dose 1000 mg, max daily 60 mg/kg/day or 4000 mg.',
    },
    administration: {
      route: ['IV', 'PO', 'PR'],
      preparation: {
        tr: 'IV Flakon hazır solüsyondur (100 ml), sulandırma gerektirmez. 15 dakikada serbest damla/infüzyon ile gönderilir.',
        en: 'IV vial is ready-to-use (100 ml), no dilution needed. Infuse over 15 minutes.',
      },
      infusionRate: {
        tr: '15 dakika',
        en: '15 minutes',
      },
    },
    contraindications: {
      tr: ['Ağır hepatik yetmezlik', 'Aktif karaciğer hastalığı', 'Parasetamol aşırı duyarlılığı'],
      en: ['Severe hepatic impairment', 'Active liver disease', 'Hypersensitivity to paracetamol'],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Zehirlenme şüphesinde (>150 mg/kg veya >7.5 g alım) serum parasetamol düzeyi ve KCFT bakın, N-Asetilsistein (Asist) antidot protokolünü gecikmeden başlatın.',
        'Kilo < 50 kg olan erişkinlerde doz 15 mg/kg olarak ayarlanmalıdır (1000 mg fazla gelebilir).',
      ],
      en: [
        'In suspected overdose (>150 mg/kg or >7.5 g), check serum paracetamol level and LFTs, start N-Acetylcysteine (Asist) antidote protocol without delay.',
        'In adults <50 kg, adjust dose to 15 mg/kg (1000 mg may cause hepatotoxicity).',
      ],
    },
    pregnancyCategory: 'B',
    tags: ['Ağrı', 'Ateş', 'Parol', 'IV Analjezik', 'Yeşil Alan', 'Sarı Alan'],
  },
  {
    id: 'dexketoprofen',
    genericName: {
      tr: 'Deksketoprofen Trometamol',
      en: 'Dexketoprofen Trometamol',
    },
    brandNamesTR: ['Arveles', 'Dexiren', 'Ketavel', 'Dexday', 'Rastel', 'Leodex'],
    category: {
      tr: 'NSAİİ (Nonsteroid Antiinflamatuar)',
      en: 'NSAID (Non-Steroidal Anti-Inflammatory Drug)',
    },
    forms: [
      '50 mg / 2 ml IM/IV Ampul',
      '25 mg Film Tablet',
      '25 mg Efervesan Tablet / Saşe',
      'Jel (%1.25)',
    ],
    indications: {
      tr: [
        'Akut renal kolik ve üreter taşı ağrısı',
        'Akut kas-iskelet ve lumbago / siyatalji ağrıları',
        'Akut post-travmatik ağrı ve diş ağrısı',
        'Biliyer kolik, dismenore',
      ],
      en: [
        'Acute renal colic and ureteral stone pain',
        'Acute musculoskeletal, low back pain, sciatica',
        'Acute post-traumatic pain and dental pain',
        'Biliary colic, dysmenorrhea',
      ],
    },
    erAdultDose: {
      tr: '50 mg (1 ampul) IM veya IV yavaş infüzyon. Gereğinde 8-12 saatte bir tekrarlanabilir. Maksimum günlük doz 150 mg.',
      en: '50 mg (1 ampoule) IM or slow IV infusion. Can repeat every 8-12h if needed. Max daily dose 150 mg.',
    },
    administration: {
      route: ['IV', 'IM', 'PO'],
      preparation: {
        tr: 'IV kullanımda 1 ampul (50 mg) en az 100 ml %0.9 SF veya %5 Dekstroz içinde seyreltilerek 10-30 dakikada yavaş infüzyonla verilir. Hızlı IV puşe yapılması flebit ve hipotansiyona yol açabilir.',
        en: 'For IV use, dilute 1 ampoule (50 mg) in at least 100 ml 0.9% Normal Saline or 5% Dextrose and infuse over 10-30 min. Rapid IV push can cause phlebitis/hypotension.',
      },
      infusionRate: {
        tr: '10-30 dakika infüzyon',
        en: '10-30 min infusion',
      },
    },
    contraindications: {
      tr: [
        'Aktif peptik ülser veya GİS kanama öyküsü',
        'Şiddetli böbrek yetmezliği (GFR < 30 ml/dk)',
        'Şiddetli kalp yetmezliği (NYHA III-IV)',
        'Aspirin/NSAİİ ile tetiklenen astım/bronkospazm',
        'Gebeliğin 3. trimesteri',
      ],
      en: [
        'Active peptic ulcer or GI bleeding history',
        'Severe renal impairment (GFR < 30 ml/min)',
        'Severe heart failure (NYHA III-IV)',
        'Aspirin/NSAID induced asthma/bronchospasm',
        'Third trimester of pregnancy',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Yaşlı veya dehidrate renal kolik hastalarında kreatinin yükselmesine ve akut böbrek hasarına (ABH) dikkat edin.',
        'Mide hassasiyeti olanlarda PPI (Pantoprazol) ile kombine edilmesi önerilir.',
        'Pediatrik grupta (<18 yaş) etkinliği ve güvenliği onaylanmamıştır.',
      ],
      en: [
        'Watch for Acute Kidney Injury in elderly or dehydrated renal colic patients.',
        'Co-administration with a PPI (Pantoprazole) is recommended in high-risk GI patients.',
        'Not established for pediatric use (<18 years).',
      ],
    },
    pregnancyCategory: 'C (1-2. Trimester) / D (3. Trimester)',
    tags: ['Arveles', 'Ağrı', 'Renal Kolik', 'NSAİİ', 'Lumbago'],
  },
  {
    id: 'diclofenac',
    genericName: {
      tr: 'Diklofenak Sodyum',
      en: 'Diclofenac Sodium',
    },
    brandNamesTR: ['Dikloron', 'Voltaren', 'Miyadren', 'Diclomec', 'Difenak'],
    category: {
      tr: 'NSAİİ (Güçlü Analjezik / Antiinflamatuar)',
      en: 'NSAID (Potent Analgesic / Anti-inflammatory)',
    },
    forms: [
      '75 mg / 3 ml IM Ampul',
      '50 mg & 100 mg SR Tablet',
      '100 mg Supozituvar (Fitil)',
      'Jel (%1)',
    ],
    indications: {
      tr: [
        'Akut renal kolik',
        'Akut lumbago, disk hernisi alevlenmesi, kas spazmı',
        'Akut gut artriti, postoperatif veya posttravmatik ağrılar',
      ],
      en: [
        'Acute renal colic',
        'Acute lumbago, disc herniation flare, muscle spasm',
        'Acute gout attack, postoperative/posttraumatic pain',
      ],
    },
    erAdultDose: {
      tr: '75 mg (1 ampul) Derin İntramüsküler (IM) gluteal bölgeye uygulanır. Şiddetli vakalarda maksimum 150 mg/gün (2 ampul).',
      en: '75 mg (1 ampoule) Deep Intramuscular (IM) in gluteal region. Max 150 mg/day (2 ampoules) in severe cases.',
    },
    administration: {
      route: ['IM', 'PO', 'PR'],
      preparation: {
        tr: 'Rutin Türkiye acil pratiğinde derin İNTRAMÜSKÜLER (IM) gluteus üst dış kadrana uygulanır. Damar içi (IV) puşe verilmez.',
        en: 'Administered by deep Intramuscular (IM) injection into upper outer gluteal quadrant. Not given as IV push.',
      },
    },
    contraindications: {
      tr: [
        'Aktif GİS kanama/ülser',
        'Ağır koroner arter hastalığı / İskemik kalp hastalığı',
        'Ağır böbrek yetmezliği',
        'Aspirin triadı (astım + nazal polip + aspirin duyarlılığı)',
      ],
      en: [
        'Active GI bleed/peptic ulcer',
        'Established ischemic heart disease/severe CAD',
        'Severe renal impairment',
        'Aspirin-exacerbated respiratory disease (AERD)',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Gluteal apse ve siyatik sinir hasarını önlemek için mutlaka gluteal üst-dış kadrana derin IM yapılmalıdır.',
        'Yaşlı koroner hastalarında kardiyovasküler risk nedeniyle parasetamol tercih edilmelidir.',
      ],
      en: [
        'Inject deep IM in upper outer quadrant to prevent sciatic nerve injury or sterile abscess.',
        'Prefer paracetamol in elderly patients with ischemic heart disease.',
      ],
    },
    pregnancyCategory: 'C / D (3. Trimester)',
    tags: ['Dikloron', 'Voltaren', 'IM Ağrı Kesici', 'Renal Kolik', 'Kas Ağrısı'],
  },
  {
    id: 'metamizole',
    genericName: {
      tr: 'Metamizol Sodyum (Dipiron)',
      en: 'Metamizole Sodium (Dipyrone)',
    },
    brandNamesTR: ['Novalgin', 'Adepiron', 'Devaljin', 'Geralgine', 'Metamizol'],
    category: {
      tr: 'Analjezik / Spazmolitik / Antipiretik',
      en: 'Analgesic / Spasmolytic / Antipyretic',
    },
    forms: [
      '1 g / 2 ml IM/IV Ampul',
      '500 mg Tablet',
      '500 mg / ml Damla',
    ],
    indications: {
      tr: [
        'Şiddetli akut viseral ağrılar (renal kolik, biliyer kolik)',
        'Dirençli yüksek ateş',
        'Şiddetli baş ağrısı ve post-travmatik ağrı',
      ],
      en: [
        'Severe acute visceral pain (renal/biliary colic)',
        'Refractory high fever',
        'Severe acute headache and post-traumatic pain',
      ],
    },
    erAdultDose: {
      tr: '1 g (1 ampul) IV yavaş infüzyon veya IM. Maksimum tek doz 1-2 g, maksimum günlük 4 g.',
      en: '1 g (1 ampoule) slow IV infusion or IM. Max single dose 1-2 g, max daily 4 g.',
    },
    erPediatricDose: {
      tr: '10-15 mg/kg/doz yavaş infüzyon veya damla formu. Pediatride hipotansiyon riski nedeniyle çok dikkatli kullanılmalıdır.',
      en: '10-15 mg/kg/dose slow infusion or drops. Use with extreme caution in pediatrics due to hypotension risk.',
    },
    administration: {
      route: ['IV', 'IM', 'PO'],
      preparation: {
        tr: 'MUTLAKA 100 ml SF içinde en az 15-20 dakikada infüzyonla verilmelidir. Hızlı IV puşe yapılması ŞİDDETLİ HİPOTANSİYON ve ŞOKA yol açar!',
        en: 'MUST be diluted in 100 ml Normal Saline and infused over at least 15-20 minutes. RAPID IV PUSH CAUSES SEVERE HYPOTENSION AND SHOCK!',
      },
    },
    contraindications: {
      tr: [
        'Hipotansiyon (SAB < 100 mmHg) veya hemodinamik instabilite',
        'Kemik iliği depresyonu, nötropeni, agranülositoz öyküsü',
        'G6PD eksikliği',
        'Alerji / bronkospazm öyküsü',
      ],
      en: [
        'Hypotension (SBP < 100 mmHg) or hemodynamic instability',
        'Bone marrow suppression, neutropenia, agranulocytosis history',
        'G6PD deficiency',
        'Hypersensitivity / bronchospasm history',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'HIZLI IV VERMEYİN: Tansiyonu aniden düşürür, hastanın baş dönmesi ve bayılmasına yol açabilir.',
        'Agranülositoz riski nadir de olsa mevcuttur; boğaz ağrısı/ateş ile gelen hastada kullanım öyküsü sorgulanmalıdır.',
      ],
      en: [
        'NEVER PUSH RAPIDLY IV: Causes precipitous drop in blood pressure and syncope.',
        'Rare risk of agranulocytosis; inquire if patient develops sudden sore throat/fever after use.',
      ],
    },
    pregnancyCategory: 'D',
    tags: ['Novalgin', 'Ateş Düşürücü', 'Viseral Ağrı', 'Hipotansiyon Riski'],
  },
  {
    id: 'hyoscine',
    genericName: {
      tr: 'Hiyosin-N-butilbromür (Butilskopolamin)',
      en: 'Hyoscine Butylbromide (Scopolamine Butylbromide)',
    },
    brandNamesTR: ['Buscopan', 'Spazmol', 'Buscopan Plus (Parasetamol ile kombine)', 'Molit'],
    category: {
      tr: 'Antispazmodik / Parasempatolitik',
      en: 'Antispasmodic / Anticholinergic',
    },
    forms: [
      '20 mg / 1 ml IM/IV Ampul',
      '10 mg Kaplı Tablet',
      'Buscopan Plus Tablet (10 mg Hiyosin + 500 mg Parasetamol)',
    ],
    indications: {
      tr: [
        'GİS spazmları (gastroenterit, kramp tarzı karın ağrısı, İBS)',
        'Ürogenital spazmlar (Renal kolik, dismenore)',
        'Safra yolu spazmları (Biliyer kolik)',
      ],
      en: [
        'GI spasm (gastroenteritis, cramping abdominal pain, IBS)',
        'Urogenital spasm (Renal colic, dysmenorrhea)',
        'Biliary spasm (Biliary colic)',
      ],
    },
    erAdultDose: {
      tr: '20 mg (1 ampul) Yavaş IV veya IM. Ağır vakalarda 30 dk sonra tekrarlanabilir. Maksimum günlük doz 100 mg.',
      en: '20 mg (1 ampoule) slow IV or IM. May repeat after 30 min in severe cases. Max daily dose 100 mg.',
    },
    administration: {
      route: ['IV', 'IM', 'PO'],
      preparation: {
        tr: 'Doğrudan yavaş IV puşe (en az 2-3 dakika) veya 100 cc SF içerisine eklenerek verilebilir.',
        en: 'Direct slow IV push (over 2-3 minutes) or added into 100 cc Normal Saline.',
      },
    },
    contraindications: {
      tr: [
        'Dar açılı glokom',
        'Prostat hipertrofisi ve idrar retansiyonu riski',
        'Mekanik GİS darlıkları, paralitik ileus veya megakolon',
        'Taşiaritmi',
        'Myastenia gravis',
      ],
      en: [
        'Narrow-angle glaucoma',
        'Prostatic hypertrophy and urinary retention risk',
        'Mechanical GI stenosis, paralytic ileus, megacolon',
        'Tachyarrhythmias',
        'Myasthenia gravis',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Taşikardi yapabilir; nabız > 120 olan hastalarda dikkatli olunmalıdır.',
        'Akut batın şüphesi olan hastada tanı konulmadan önce ağrıyı maskeleyip peritoneal bulguları gizlememeye dikkat edilmelidir.',
      ],
      en: [
        'Can induce tachycardia; exercise caution in patients with HR > 120.',
        'In undifferentiated acute abdomen, do not obscure signs of surgical peritonitis before surgical exam.',
      ],
    },
    pregnancyCategory: 'C',
    tags: ['Buscopan', 'Spazm', 'Karın Ağrısı', 'Renal Kolik', 'Gastroenterit'],
  },
  {
    id: 'tramadol',
    genericName: {
      tr: 'Tramadol Hidroklorür',
      en: 'Tramadol Hydrochloride',
    },
    brandNamesTR: ['Tramal', 'Contramal', 'Ultramex', 'Tramosel'],
    category: {
      tr: 'Zayıf Opioid Analjezik (Yeşil Reçeteli)',
      en: 'Weak Opioid Analgesic (Scheduled Prescription)',
    },
    forms: [
      '100 mg / 2 ml IM/IV Ampul',
      '50 mg Kapsül',
      '100 mg / ml Damla',
      '100 mg / 150 mg / 200 mg Retard Tablet',
    ],
    indications: {
      tr: [
        'NSAİİ ve parasetamole dirençli orta-şiddetli akut ağrılar (travma, kırık, şiddetli renal kolik, kanser ağrısı)',
      ],
      en: [
        'Moderate to severe acute pain refractory to NSAIDs/paracetamol (trauma, fractures, severe renal colic, cancer pain)',
      ],
    },
    erAdultDose: {
      tr: '50-100 mg IV yavaş infüzyon (100 ml SF içinde 20-30 dakikada). Maksimum tek doz 100 mg, maksimum günlük 400 mg.',
      en: '50-100 mg IV slow infusion (in 100 ml NS over 20-30 min). Max single dose 100 mg, max daily 400 mg.',
    },
    administration: {
      route: ['IV', 'IM', 'PO'],
      preparation: {
        tr: '1 ampul (100 mg) mutlaka 100 ml %0.9 SF içine konup 20-30 dakikada infüzyonla verilmelidir. Yanına mutlaka bir antiemetik (Örn: Metpamid veya Zofran) eklenmesi bulantıyı önler.',
        en: 'Dilute 1 ampoule (100 mg) in 100 ml NS and infuse over 20-30 min. Co-administering an antiemetic (e.g. Metoclopramide or Ondansetron) prevents severe nausea/vomiting.',
      },
    },
    contraindications: {
      tr: [
        'Solunum depresyonu riski / ağır KOAH atağı',
        'MAO inhibitörleri kullanan hastalar (Serotonin sendromu)',
        'Kontrolsüz epilepsi (Nöbet eşiğini düşürür)',
        'Kafa travması ve intrakraniyal basınç artışı',
      ],
      en: [
        'Respiratory depression / severe acute COPD exacerbation',
        'Concomitant MAOI use (Serotonin syndrome risk)',
        'Uncontrolled epilepsy (Lowers seizure threshold)',
        'Head trauma with increased ICP',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Hızlı verilirse şiddetli bulantı, kusma ve baş dönmesi yapar.',
        'Nöbet öyküsü olanlarda nöbet tetikleyebilir.',
        'Opioid toksisitesinde (solunum sayısı < 8, pupil miyozisi, stupor) Nalokson (Narcan) 0.4 mg IV hazır bulundurulmalıdır.',
      ],
      en: [
        'Rapid IV push triggers intense nausea, emesis, and dizziness.',
        'Lowers seizure threshold in epileptics.',
        'Have Naloxone (Narcan) 0.4 mg IV ready if respiratory depression occurs.',
      ],
    },
    pregnancyCategory: 'C',
    tags: ['Tramal', 'Opioid', 'Şiddetli Ağrı', 'Kırık', 'Yeşil Reçete'],
  },

  // --- ANTIEMETICS & GASTROINTESTINAL ---
  {
    id: 'ondansetron',
    genericName: {
      tr: 'Ondansetron',
      en: 'Ondansetron',
    },
    brandNamesTR: ['Zofran', 'Zofer', 'Onsedron', 'Zonit'],
    category: {
      tr: '5-HT3 Reseptör Antagonisti Antiemetik',
      en: '5-HT3 Receptor Antagonist Antiemetic',
    },
    forms: [
      '4 mg / 2 ml & 8 mg / 4 ml IM/IV Ampul',
      '4 mg & 8 mg Film Tablet / Ağızda Dağılan Tablet (Zydis)',
      '4 mg / 5 ml Şurup',
    ],
    indications: {
      tr: [
        'Akut gastroenterite bağlı inatçı bulantı ve kusma',
        'Kemoterapi/radyoterapi veya postoperatif bulantı-kusma',
        'Vertigo veya migren atağına eşlik eden şiddetli bulantı',
      ],
      en: [
        'Severe nausea and vomiting associated with acute gastroenteritis',
        'Chemotherapy/radiation or postoperative nausea and vomiting',
        'Nausea associated with vertigo or acute migraine',
      ],
    },
    erAdultDose: {
      tr: '4-8 mg Yavaş IV puşe (2-5 dakikada) veya IM. Gerekirse 8 saatte bir tekrarlanır. Maksimum günlük doz 16 mg.',
      en: '4-8 mg slow IV push (over 2-5 min) or IM. Repeat q8h if needed. Max daily dose 16 mg.',
    },
    erPediatricDose: {
      tr: '0.15 mg/kg IV (Maksimum tek doz 4 mg). 6 ay üzeri çocuklarda AGE kusmasında oral rehidrasyonu sağlamak için çok etkilidir.',
      en: '0.15 mg/kg IV (Max single dose 4 mg). Very effective in pediatrics >6 months with gastroenteritis to enable oral rehydration.',
    },
    administration: {
      route: ['IV', 'IM', 'PO'],
      preparation: {
        tr: 'Doğrudan yavaş IV puşe (2-5 dk) veya 50-100 cc SF içinde 15 dakikada infüzyon.',
        en: 'Direct slow IV push over 2-5 min or 50-100 ml NS infusion over 15 min.',
      },
    },
    contraindications: {
      tr: [
        'Doğuştan Uzun QT Sendromu veya belirgin QTc uzaması (>480 ms)',
        'Apomorfin ile eşzamanlı kullanım (şiddetli hipotansiyon ve senkop)',
      ],
      en: [
        'Congenital Long QT Syndrome or significant QTc prolongation (>480 ms)',
        'Concomitant apomorphine use (severe hypotension)',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'QT aralığını uzatabilir; hipokalemi, hipomagnezemi veya diğer QT uzatan ilaçlar (amiodaron, antipsikotikler) ile birlikte dikkat!',
        'Ekstrapiramidal yan etki yapmaz (Metpamid\'e göre bu açıdan çok daha güvenlidir).',
      ],
      en: [
        'Can prolong QT interval; exercise caution in hypokalemia, hypomagnesemia, or with other QT-prolonging drugs.',
        'Does NOT cause extrapyramidal symptoms (much safer than Metoclopramide in young patients).',
      ],
    },
    pregnancyCategory: 'B',
    tags: ['Zofran', 'Kusma', 'Bulantı', 'Antiemetik', 'Gastroenterit'],
  },
  {
    id: 'metoclopramide',
    genericName: {
      tr: 'Metoklopramid',
      en: 'Metoclopramide',
    },
    brandNamesTR: ['Metpamid', 'Primperan'],
    category: {
      tr: 'Dopamin Reseptör Antagonisti / Prokinetik Antiemetik',
      en: 'Dopamine Receptor Antagonist / Prokinetic Antiemetic',
    },
    forms: [
      '10 mg / 2 ml IM/IV Ampul',
      '10 mg Tablet',
      '1 mg / ml Oral Solüsyon',
    ],
    indications: {
      tr: [
        'Akut bulantı ve kusma',
        'Migren atağı (hem analjezik emilimini artırır hem bulantıyı keser)',
        'Gastroparezi ve reflü semptomları',
      ],
      en: [
        'Acute nausea and vomiting',
        'Acute migraine attack (enhances analgesic absorption & treats nausea)',
        'Gastroparesis and reflux symptoms',
      ],
    },
    erAdultDose: {
      tr: '10 mg (1 ampul) Yavaş IV (en az 3 dakika) veya IM. Maksimum günlük doz 30 mg (veya 0.5 mg/kg).',
      en: '10 mg (1 ampoule) slow IV (over at least 3 min) or IM. Max daily dose 30 mg (or 0.5 mg/kg).',
    },
    administration: {
      route: ['IV', 'IM', 'PO'],
      preparation: {
        tr: 'Hızlı IV puşe KESİNLİKLE YAPILMAMALIDIR! 100 cc SF içinde 15 dakikada gönderilmeli veya çok yavaş enjekte edilmelidir.',
        en: 'DO NOT PUSH FAST IV! Infuse in 100 ml NS over 15 min or inject very slowly.',
      },
    },
    contraindications: {
      tr: [
        'GİS kanama, mekanik obstrüksiyon veya perforasyon',
        'Feokromositoma',
        'Ekstrapiramidal reaksiyon veya tardif diskinezi öyküsü',
        'Epilepsi',
        '<1 yaş çocuklarda kullanımı kontrendikedir',
      ],
      en: [
        'GI bleeding, mechanical obstruction or bowel perforation',
        'Pheochromocytoma',
        'History of extrapyramidal symptoms or tardive dyskinesia',
        'Epilepsy',
        'Contraindicated in infants <1 year',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'AKUT DİSTONİ / EKSTRAPİRAMİDAL YAN ETKİ: Özellikle genç kadınlarda ve hızlı infüzyonda boyun kasılması (tortikolis), gözlerin yukarı kayması (okulojirik kriz) ve akatizi (huzursuzluk) yapabilir. Tedavisi: 1 ampul Biperiden (Akineton) veya Avil (Feniramin) IV yavaş puşedir!',
      ],
      en: [
        'ACUTE DYSTONIA / EXTRA-PYRAMIDAL REACTION: Can trigger oculogyric crisis, torticollis, and intense akathisia, especially in young patients and with rapid push. Treatment: 1 amp Biperiden (Akineton) or Pheniramine (Avil) slow IV!',
      ],
    },
    pregnancyCategory: 'B',
    tags: ['Metpamid', 'Bulantı', 'Migren', 'Akut Distoni Riski', 'Prokinetik'],
  },
  {
    id: 'pantoprazole',
    genericName: {
      tr: 'Pantoprazol',
      en: 'Pantoprazole',
    },
    brandNamesTR: ['Pantpas', 'Pulcet', 'Pantactive', 'Pandev', 'Gastrazol', 'Protium'],
    category: {
      tr: 'Proton Pompa İnhibitörü (PPİ)',
      en: 'Proton Pump Inhibitor (PPI)',
    },
    forms: [
      '40 mg IV Flakon',
      '20 mg & 40 mg Enterik Kaplı Tablet',
    ],
    indications: {
      tr: [
        'Üst GİS kanama (Peptik ülser kanaması)',
        'Akut gastrit, peptik ülser ve GÖRH alevlenmesi',
        'Acilde NSAİİ ile birlikte mide koruyucu olarak',
      ],
      en: [
        'Upper GI bleeding (peptic ulcer bleed)',
        'Acute gastritis, peptic ulcer, GERD flare',
        'Gastric mucosal protection during acute NSAID therapy',
      ],
    },
    erAdultDose: {
      tr: 'Rutin acil: 40 mg IV yavaş puşe (2-3 dk). Üst GİS Kanama Protokolü: 80 mg IV bolus ardından 8 mg/saat sürekli infüzyon (72 saat).',
      en: 'Routine ER: 40 mg IV slow push. Upper GI Bleed Protocol: 80 mg IV bolus followed by 8 mg/hr continuous infusion for 72 hours.',
    },
    administration: {
      route: ['IV', 'PO'],
      preparation: {
        tr: '40 mg liyofilize toz flakon, kutusundaki 10 ml %0.9 SF çözücü ile eritilir. Direkt yavaş IV (2-3 dk) veya 100 cc SF içinde 15 dk infüzyonla verilir.',
        en: 'Reconstitute 40 mg vial with 10 ml NS. Administer as slow IV push over 2-3 min or in 100 ml NS over 15 min.',
      },
    },
    contraindications: {
      tr: ['Pantoprazol veya diğer benzimidazol türevlerine aşırı duyarlılık'],
      en: ['Hypersensitivity to pantoprazole or benzimidazoles'],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Üst GİS kanamalı hastada (hematemez, melena) endoskopiyi geciktirmeden derhal 80 mg IV yükleme yapılmalıdır.',
      ],
      en: [
        'In upper GI bleed (hematemesis, melena), give 80 mg IV bolus immediately while organizing urgent endoscopy.',
      ],
    },
    pregnancyCategory: 'B',
    tags: ['Pantpas', 'Mide Koruyucu', 'GİS Kanama', 'Gastrit', 'Ülser'],
  },

  // --- RESPIRATORY & INHALERS & STEROIDS ---
  {
    id: 'salbutamol',
    genericName: {
      tr: 'Salbutamol (Albuterol)',
      en: 'Salbutamol (Albuterol)',
    },
    brandNamesTR: ['Ventolin Nebül', 'Ventolin İnhaler', 'Salbual', 'Ronkotol'],
    category: {
      tr: 'Kısa Etkili Beta-2 Agonist (SABA) Bronkodilatör',
      en: 'Short-Acting Beta-2 Agonist (SABA) Bronchodilator',
    },
    forms: [
      '2.5 mg / 2.5 ml Nebül',
      '100 mcg / Doz Ölçülü Doz İnhaler (100 mcg x 200 doz)',
      '2 mg / 5 ml Şurup',
    ],
    indications: {
      tr: [
        'Akut bronkospazm (Astım atağı, KOAH alevlenmesi)',
        'Akut hiperkalemi acil tedavisi (Potasyumu hücre içine sokmak için yüksek doz nebulizasyon)',
      ],
      en: [
        'Acute bronchospasm (Asthma attack, COPD exacerbation)',
        'Acute hyperkalemia management (drives potassium into cells with high-dose nebulization)',
      ],
    },
    erAdultDose: {
      tr: '2.5 - 5 mg (1-2 nebül) Oksijen (6-8 L/dk) ile nebulizatör haznesine konularak 10-15 dakikada inhale ettirilir. Şiddetli atakta ilk 1 saatte her 20 dakikada bir (3 kez) tekrarlanabilir.',
      en: '2.5 - 5 mg (1-2 ampoules) via nebulizer with 6-8 L/min O2 over 10-15 min. In severe flare, repeat every 20 min (up to 3 times in first hour).',
    },
    erPediatricDose: {
      tr: '0.15 mg/kg (minimum 1.25 mg - yarım nebül, maksimum 5 mg). Aralıklı veya sürekli nebulizasyon.',
      en: '0.15 mg/kg (min 1.25 mg, max 5 mg) via nebulizer.',
    },
    administration: {
      route: ['Inhalation'],
      preparation: {
        tr: 'Nebül solüsyonu nebülizatör haznesine boşaltılır. Genellikle 1 adet Combivent (İpratropiyum) veya Pulmicort (Budezonid) nebül ile kombine edilerek verilir.',
        en: 'Pour ampoule contents into nebulizer cup. Frequently combined with Ipratropium (Combivent/Atrovent) and Budesonide (Pulmicort).',
      },
    },
    contraindications: {
      tr: ['Ağır taşiaritmi', 'Salbutamole aşırı duyarlılık'],
      en: ['Severe tachyarrhythmia', 'Hypersensitivity to salbutamol'],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Taşikardi, tremor ve geçici hipokalemi yapabilir.',
        'Sessiz akciğer (Silent chest) varlığı bronkodilatör öncesi entübasyon hazırlığı gerektiren hayatı tehdit edici astım atağı bulgusudur!',
      ],
      en: [
        'Can induce sinus tachycardia, skeletal muscle tremor, and transient hypokalemia.',
        'Silent chest is a sign of life-threatening respiratory fatigue requiring immediate intubation readiness!',
      ],
    },
    pregnancyCategory: 'C',
    tags: ['Ventolin', 'Astım', 'KOAH', 'Nefes Darlığı', 'Bronkodilatör'],
  },
  {
    id: 'budesonide',
    genericName: {
      tr: 'Budezonid',
      en: 'Budesonide',
    },
    brandNamesTR: ['Pulmicort Nebül', 'Budecort', 'Miflonide', 'Cortair'],
    category: {
      tr: 'İnhale Kortikosteroid (İKS)',
      en: 'Inhaled Corticosteroid (ICS)',
    },
    forms: [
      '0.25 mg / 2 ml & 0.5 mg / 2 ml Nebül Solüsyonu',
      '100 mcg & 200 mcg / Doz Turbuhaler / İnhaler',
    ],
    indications: {
      tr: [
        'Akut astım ve KOAH alevlenmelerinde havayolu enflamasyonunu baskılama',
        'Pediatrik Krup (Laringotrakeobronşit) acil tedavisi',
      ],
      en: [
        'Airway inflammation in acute asthma and COPD exacerbations',
        'Emergency management of pediatric Croup (Laryngotracheobronchitis)',
      ],
    },
    erAdultDose: {
      tr: '0.5 mg - 1 mg (1-2 nebül) Nebulizatör ile 12 saatte bir veya akut atakta Ventolin ile kombine.',
      en: '0.5 mg - 1 mg via nebulizer q12h or combined with Ventolin during acute attack.',
    },
    erPediatricDose: {
      tr: 'Krup tedavisinde: 2 mg tek doz nebül (0.5 mg/2ml formundan 4 nebül veya 1mg/ml formundan 2 nebül) oksijen ile inhale ettirilir.',
      en: 'In Croup: 2 mg single dose nebulized via mask.',
    },
    administration: {
      route: ['Inhalation'],
      preparation: {
        tr: 'Nebulizatör haznesine Ventolin ile birlikte konularak verilebilir. Uygulama sonrası ağız içi suyla çalkalanmalıdır (oral kandidiyazisi önlemek için).',
        en: 'Can be mixed with Ventolin in nebulizer cup. Rinse mouth with water after use to prevent oral candidiasis.',
      },
    },
    contraindications: {
      tr: ['Budezonide aşırı duyarlılık'],
      en: ['Hypersensitivity to budesonide'],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Krup vakasında stridor ve havayolu obstrüksiyonunu hızla rahatlatır. Çocukta ajitasyondan kaçının.',
      ],
      en: [
        'Rapidly resolves stridor and subglottic edema in croup. Keep the child calm and avoid distress.',
      ],
    },
    pregnancyCategory: 'B',
    tags: ['Pulmicort', 'Krup', 'Astım', 'İnhale Steroid', 'Pediatri'],
  },
  {
    id: 'methylprednisolone',
    genericName: {
      tr: 'Metilprednizolon',
      en: 'Methylprednisolone',
    },
    brandNamesTR: ['Prednol-L', 'Prednol', 'Prednisolon', 'Solu-Medrol'],
    category: {
      tr: 'Sistemik Glukokortikoid (Kortizon)',
      en: 'Systemic Glucocorticoid (Corticosteroid)',
    },
    forms: [
      '16 mg, 40 mg, 250 mg IM/IV Flakon / Ampul',
      '4 mg & 16 mg Tablet',
    ],
    indications: {
      tr: [
        'Akut astım ve KOAH atağı',
        'Anafilaksi ve şiddetli ürtiker / anjioödem',
        'Akut alerjik reaksiyonlar',
        'Spinal kord travması ve nöroenflamasyon (yüksek doz)',
      ],
      en: [
        'Acute asthma and COPD exacerbation',
        'Anaphylaxis, severe urticaria / angioedema',
        'Acute allergic drug reactions',
        'Spinal cord trauma / severe neuroinflammation',
      ],
    },
    erAdultDose: {
      tr: 'Astım/KOAH/Alerji: 40-80 mg IV yavaş puşe (1-2 mg/kg). Şiddetli anafilaksi/atağında 1-2 mg/kg IV.',
      en: 'Asthma/COPD/Allergy: 40-80 mg IV slow push (1-2 mg/kg). Severe anaphylaxis: 1-2 mg/kg IV.',
    },
    erPediatricDose: {
      tr: '1-2 mg/kg/doz IV yavaş (Maksimum 60 mg).',
      en: '1-2 mg/kg/dose IV slow push (Max 60 mg).',
    },
    administration: {
      route: ['IV', 'IM', 'PO'],
      preparation: {
        tr: 'Flakon içindeki toz, ampuldeki çözücüsüyle karıştırılarak eritilir. Yavaş IV puşe (2-3 dakika) veya 100 cc SF içinde infüzyonla verilir.',
        en: 'Reconstitute powder with provided diluent. Administer slow IV push over 2-3 min or in 100 ml NS.',
      },
    },
    contraindications: {
      tr: ['Sistemik kontrolsüz mantar enfeksiyonları', 'Canlı virüs aşıları'],
      en: ['Systemic untreated fungal infections', 'Live viral vaccines'],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Diyabetik hastalarda kan şekerini (AKŞ) hızla yükseltir, glukoz takibi yapın!',
        'Tek doz acil uygulamada belirgin immünsüpresyon yapmaz; anafilaksi ve astımda gecikmeden verilmelidir.',
        'Anafilakside Adrenalin\'in yerini tutmaz; steroidlerin etkisi 4-6 saat sonra başlar (geç faz reaksiyonları önler).',
      ],
      en: [
        'Causes acute hyperglycemia; monitor blood glucose in diabetics!',
        'Single emergency dose does not cause immunosuppression; do not withhold in severe asthma or allergy.',
        'Does NOT replace Epinephrine in anaphylaxis; onset is 4-6 hours (prevents biphasic reaction).',
      ],
    },
    pregnancyCategory: 'C',
    tags: ['Prednol', 'Kortizon', 'Alerji', 'Anafilaksi', 'Astım', 'KOAH'],
  },
  {
    id: 'pheniramine',
    genericName: {
      tr: 'Feniramin Maleat',
      en: 'Pheniramine Maleate',
    },
    brandNamesTR: ['Avil', 'Feniramin'],
    category: {
      tr: '1. Kuşak Antihistaminik (H1 Blokeri)',
      en: 'First-Generation Antihistamine (H1 Blocker)',
    },
    forms: [
      '45.5 mg / 2 ml IM/IV Ampul',
      '25 mg Tablet',
      '15 mg / 5 ml Şurup',
    ],
    indications: {
      tr: [
        'Akut ürtiker, anjioödem, kaşıntı',
        'Böcek sokması, ilaç ve besin alerjileri',
        'Akut distoni tedavisi (Metpamid yan etkisinde)',
      ],
      en: [
        'Acute urticaria, angioedema, pruritus',
        'Insect stings, drug and food allergies',
        'Acute dystonic reaction treatment (e.g. from Metoclopramide)',
      ],
    },
    erAdultDose: {
      tr: '45.5 mg (1 ampul) Yavaş IV veya IM. Gerekirse günde 2-3 kez.',
      en: '45.5 mg (1 ampoule) slow IV or IM. May repeat 2-3 times daily.',
    },
    erPediatricDose: {
      tr: '1 mg/kg/doz IM veya yavaş IV (Maksimum 45 mg). 1 yaş altı çocuklarda önerilmez.',
      en: '1 mg/kg/dose IM or slow IV (Max 45 mg). Not recommended in infants <1 year.',
    },
    administration: {
      route: ['IV', 'IM', 'PO'],
      preparation: {
        tr: 'Yavaş IV (en az 3-5 dakika) veya 100 cc SF içinde verilmelidir. Hızlı verilmesi kan basıncında düşme ve sedasyona yol açar.',
        en: 'Administer slow IV push over 3-5 min or in 100 ml NS. Fast injection causes hypotension and sedation.',
      },
    },
    contraindications: {
      tr: ['Dar açılı glokom', 'Prostat hipertrofisi ve idrar retansiyonu', 'Ağır astım atağı'],
      en: ['Narrow-angle glaucoma', 'Prostatic hypertrophy with urinary retention', 'Severe acute asthma attack'],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Belirgin sedasyon ve uyku hali yapar; taburcu olan hastaya araç kullanmaması tembihlenmelidir.',
        'Yaşlılarda konfüzyon, ajitasyon ve antikolinerjik deliryum yapabilir.',
      ],
      en: [
        'Causes marked drowsiness; warn patients against driving or operating machinery.',
        'May cause paradoxical agitation, confusion, or anticholinergic delirium in elderly.',
      ],
    },
    pregnancyCategory: 'C',
    tags: ['Avil', 'Alerji', 'Ürtiker', 'Kaşıntı', 'Sedasyon'],
  },

  // --- CARDIOVASCULAR & RESUSCITATION ---
  {
    id: 'epinephrine',
    genericName: {
      tr: 'Adrenalin (Epinefrin)',
      en: 'Adrenaline (Epinephrine)',
    },
    brandNamesTR: ['Adrenalin Biofarma', 'Adrenalin Drogsan'],
    category: {
      tr: 'Sempatomimetik / Alfa & Beta Agonist / Resüsitasyon İlacı',
      en: 'Sympathomimetic / Alpha & Beta Agonist / Resuscitation Drug',
    },
    forms: [
      '0.5 mg / 1 ml Ampul (1:2000 konsantrasyon)',
      '1 mg / 1 ml Ampul (1:1000 konsantrasyon)',
    ],
    indications: {
      tr: [
        'Kardiyak Arrest (VF/pVT, Asistoli, PEA)',
        'Anafilaksi (1. basamak hayat kurtarıcı tedavi)',
        'Şiddetli refrakter krup / bronkospazm (Nebül)',
        'Septik ve kardiyojenik şokta inotropik/vazopressör infüzyon',
      ],
      en: [
        'Cardiac Arrest (VF/pVT, Asystole, PEA)',
        'Anaphylaxis (First-line life-saving treatment)',
        'Severe croup with stridor at rest (Nebulized)',
        'Vasopressor/inotropic support in refractory shock',
      ],
    },
    erAdultDose: {
      tr: 'KARDİYAK ARREST: 1 mg IV/IO puşe (1:10.000 sulandırılarak veya 1 mg 1:1000 puşe arkasından 20 ml SF bolus), her 3-5 dakikada bir tekrarlanır.\nANAFİLAKSİ: 0.5 mg (0.5 ml 1:1000 ampul) Uyluk anterolateraline (Vastus lateralis) DERİN İNTRAMÜSKÜLER (IM). Gerekirse 5-15 dakikada bir tekrarlanır. (IV verilmez!)',
      en: 'CARDIAC ARREST: 1 mg IV/IO push followed by 20 ml NS flush, repeated q3-5 min.\nANAPHYLAXIS: 0.5 mg (0.5 ml of 1:1000) DEEP INTRAMUSCULAR (IM) in anterolateral thigh. Repeat q5-15 min if needed. (Do NOT push IV 1:1000!)',
    },
    erPediatricDose: {
      tr: 'Arrest: 0.01 mg/kg IV/IO (1:10.000 formundan 0.1 ml/kg). Anafilaksi: 0.01 mg/kg IM (1:1000 formundan 0.01 ml/kg, maks 0.3-0.5 mg).',
      en: 'Arrest: 0.01 mg/kg IV/IO (0.1 ml/kg of 1:10,000). Anaphylaxis: 0.01 mg/kg IM (0.01 ml/kg of 1:1000, max 0.3-0.5 mg).',
    },
    administration: {
      route: ['IM (Anafilaksi)', 'IV/IO (Arrest)', 'Inhaler'],
      preparation: {
        tr: 'Anafilakside SADECE IM (Uyluktan) yapılır! Arrestte 1 mg ampul 9 ml SF ile 10 ml\'ye tamamlanırsa 1:10.000 konsantrasyon elde edilir.',
        en: 'In anaphylaxis, ONLY give IM in thigh! For arrest IV, 1 mg ampoule diluted with 9 ml NS yields 1:10,000 solution.',
      },
    },
    contraindications: {
      tr: ['Kardiyak arrest ve anafilakside MUTLAK KONTRENDİKASYONU YOKTUR! Hayat kurtarıcıdır.'],
      en: ['NO ABSOLUTE CONTRAINDICATION in cardiac arrest and anaphylaxis! Life saving.'],
    },
    redFlagsAndPrecautions: {
      tr: [
        'ÖLÜMCÜL HATA: Anafilakside 1:1000 adrenalini asla hızlı IV puşe yapmayın (ölümcül aritmilere ve miyokard enfarktüsüne yol açar). Yalnızca IM yapın!',
        'Anafilaksi hastasında steroid ve antihistaminikten ÖNCE ilk yapılacak işlem IM Adrenalin yapmaktır!',
      ],
      en: [
        'FATAL ERROR: Never push 1:1000 epinephrine IV bolus in anaphylaxis (causes ventricular fibrillation and MI). Administer IM into thigh only!',
        'In anaphylaxis, IM Epinephrine is ALWAYS the first step before steroids or antihistamines!',
      ],
    },
    pregnancyCategory: 'C (Arrest ve anafilakside tereddütsüz verilir)',
    tags: ['Adrenalin', 'Anafilaksi', 'Kardiyak Arrest', 'Resüsitasyon', 'Acil Kırmızı Alan'],
  },
  {
    id: 'atropine',
    genericName: {
      tr: 'Atropin Sülfat',
      en: 'Atropine Sulfate',
    },
    brandNamesTR: ['Atropin Sülfat Ampul'],
    category: {
      tr: 'Antikolinerjik / Parasempatolitik / Bradikardi İlacı',
      en: 'Anticholinergic / Parasympatholytic / Bradycardia Drug',
    },
    forms: [
      '0.5 mg / 1 ml & 1 mg / 1 ml IM/IV Ampul',
    ],
    indications: {
      tr: [
        'Semptomatik sinüs bradikardisi (Hipotansiyon, şok, göğüs ağrısı, senkop eşlik eden)',
        'Organofosfat ve karbamat (tarım ilacı) zehirlenmesi (Antidot yüksek doz)',
      ],
      en: [
        'Symptomatic sinus bradycardia (associated with hypotension, shock, angina, syncope)',
        'Organophosphate and carbamate insecticide poisoning (Antidote - high dose)',
      ],
    },
    erAdultDose: {
      tr: 'Semptomatik Bradikardi: 1 mg IV puşe. Gerekirse her 3-5 dakikada bir tekrarlanır. Maksimum toplam doz 3 mg (Vagal tonusu tamamen bloke eden doz).\nOrganofosfat Zehirlenmesi: Atropinizasyon sağlanana kadar (sekresyonlar kuruyana dek) her 5-10 dk\'da 2-5 mg IV puşe (üst sınır yoktur).',
      en: 'Symptomatic Bradycardia: 1 mg IV push. Repeat q3-5 min up to max 3 mg total.\nOrganophosphate toxicity: 2-5 mg IV bolus every 5-10 min until full atropinization (clearing of respiratory secretions).',
    },
    erPediatricDose: {
      tr: '0.02 mg/kg IV/IO (Minimum tek doz 0.1 mg - paradoksal bradikardiyi önlemek için, maksimum tek doz çocukta 0.5 mg).',
      en: '0.02 mg/kg IV/IO (Minimum single dose 0.1 mg to prevent paradoxical bradycardia, max single dose 0.5 mg).',
    },
    administration: {
      route: ['IV', 'IO', 'IM'],
      preparation: {
        tr: 'Hızlı IV puşe yapılır arkasından 10-20 ml SF bolus verilir. Düşük doz (<0.5 mg erişkinde) verilirse santral vagal uyarıyla paradoksal bradikardiye yol açabilir.',
        en: 'Rapid IV push followed by NS flush. Doses <0.5 mg in adults may cause paradoxical bradycardia due to central vagal stimulation.',
      },
    },
    contraindications: {
      tr: ['Acil bradikardi ve zehirlenmede mutlak kontrendikasyon yoktur. Mobitz Tip II AV blok ve 3. derece AV blokta genelde etkisizdir (Pil/Transkutanöz pacing gerekir).'],
      en: ['No absolute contraindications in acute emergency. Often ineffective in Mobitz Type II or 3rd degree AV block (requires transcutaneous pacing).'],
    },
    redFlagsAndPrecautions: {
      tr: [
        'İskemik kalp hastasında kalp hızını aşırı artırıp enfarkt alanını genişletebilir.',
        'Organofosfat zehirlenmesinde hedef taşikardi değil, akciğer seslerinin açılması ve bronşiyal sekresyonların kurumasıdır.',
      ],
      en: [
        'Excessive tachycardia can worsen myocardial ischemia in acute coronary syndromes.',
        'In organophosphate poisoning, end-point of atropinization is dry secretions and clear lung sounds, not just tachycardia.',
      ],
    },
    pregnancyCategory: 'C',
    tags: ['Atropin', 'Bradikardi', 'Zehirlenme', 'Organofosfat', 'Kırmızı Alan'],
  },
  {
    id: 'amiodarone',
    genericName: {
      tr: 'Amiodaron Hidroklorür',
      en: 'Amiodarone Hydrochloride',
    },
    brandNamesTR: ['Cordarone', 'Amiovin'],
    category: {
      tr: 'Sınıf III Antiaritmik',
      en: 'Class III Antiarrhythmic',
    },
    forms: [
      '150 mg / 3 ml IV Ampul',
      '200 mg Tablet',
    ],
    indications: {
      tr: [
        'Defibrilasyona dirençli Nabızsız VT / VF (Kardiyak arrest)',
        'Hemodinamik olarak stabil Geniş QRS Taşikardi (VT)',
        'Hemodinamik stabil Hızlı Yanıtlı Atriyal Fibrilasyon / Flutter (Hız ve ritim kontrolü)',
      ],
      en: [
        'Shock-refractory Pulseless VT / VF (Cardiac Arrest)',
        'Hemodynamically stable wide-complex tachycardia (VT)',
        'Hemodynamically stable rapid atrial fibrillation / flutter',
      ],
    },
    erAdultDose: {
      tr: 'ARREST (VF/pVT): 300 mg IV/IO hızlı puşe (3. şoktan sonra). Dirençli ise 5. şoktan sonra 150 mg ek doz.\nSTABİL VT / AF: 150 mg IV (100 ml %5 Dekstroz içinde 10-15 dakikada infüzyon). Ardından 1 mg/dk (6 saat), sonra 0.5 mg/dk (18 saat) idame infüzyonu (Maks 2.2 g/24 saat).',
      en: 'ARREST (VF/pVT): 300 mg IV/IO rapid push after 3rd shock. Additional 150 mg after 5th shock if refractory.\nSTABLE VT / AF: 150 mg IV in 100 ml 5% Dextrose over 10-15 min, followed by 1 mg/min for 6h, then 0.5 mg/min for 18h.',
    },
    administration: {
      route: ['IV', 'IO'],
      preparation: {
        tr: 'DİKKAT: Amiodaron SADECE %5 DEKSTROZ (D5W) içinde sulandırılmalıdır! %0.9 SF içinde çöker ve stabilitesi bozulur. Stabil hastada asla hızlı IV puşe yapılmaz (ağır hipotansiyon ve bradikardi yapar).',
        en: 'CAUTION: Amiodarone MUST BE DILUTED ONLY IN 5% DEXTROSE (D5W)! Incompatible with NS. In non-arrest patients, never push bolus rapidly (causes profound hypotension).',
      },
    },
    contraindications: {
      tr: [
        'Kardiyak arrest dışında: Ağır sinüs bradikardisi, 2. ve 3. derece AV blok',
        'Uzun QT ve Torsades de Pointes',
        'Kardiyojenik şok ve ağır hipotansiyon',
      ],
      en: [
        'Non-arrest: Severe sinus bradycardia, 2nd/3rd degree AV block',
        'Long QT syndrome and Torsades de Pointes',
        'Cardiogenic shock and severe hypotension',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'İnfüzyon sırasında kan basıncını ve EKG monitorizasyonunu sürekli takip edin.',
        'Damar endotelini irrite edip flebit yapabileceğinden tercihen santral venden veya geniş çaplı antekübital venden verilmelidir.',
      ],
      en: [
        'Continuously monitor ECG and blood pressure during infusion.',
        'High risk of phlebitis; infuse through a large-bore peripheral vein or central line.',
      ],
    },
    pregnancyCategory: 'D',
    tags: ['Cordarone', 'Amiodaron', 'VT', 'VF', 'Atriyal Fibrilasyon', 'Antiaritmik'],
  },
  {
    id: 'furosemide',
    genericName: {
      tr: 'Furosemid',
      en: 'Furosemide',
    },
    brandNamesTR: ['Lasix', 'Desal', 'Furomid'],
    category: {
      tr: 'Kıvrım (Loop) Diüretiği',
      en: 'Loop Diuretic',
    },
    forms: [
      '20 mg / 2 ml IM/IV Ampul',
      '40 mg Tablet',
    ],
    indications: {
      tr: [
        'Akut Akciğer Ödemi (Kalp yetersizliğine bağlı solunum sıkıntısı ve hipervolemi)',
        'Hipertansif acillerde hipervolemi tedavisi',
        'Akut böbrek yetmezliğinde oligüri yönetimi ve hiperkalemi',
      ],
      en: [
        'Acute Pulmonary Edema (Heart failure related fluid overload)',
        'Hypertensive emergency with volume overload',
        'Hyperkalemia and fluid management in acute renal failure',
      ],
    },
    erAdultDose: {
      tr: 'Akut Akciğer Ödemi: 40-80 mg IV yavaş puşe (Kronik oral Lasix kullananlarda hastanın evde aldığı günlük oral dozun 1-2.5 katı kadar IV doz verilir). Gerekirse 1 saat sonra doz katlanabilir.',
      en: 'Acute Pulmonary Edema: 40-80 mg slow IV push. In chronic oral users, give 1-2.5 times their daily oral dose IV.',
    },
    administration: {
      route: ['IV', 'IM', 'PO'],
      preparation: {
        tr: 'Yavaş IV puşe (en az 20 mg/dakika hızında). Çok hızlı yüksek doz verilmesi geçici veya kalıcı OTOTOKSİSİTEYE (işitme kaybı ve kulak çınlaması) yol açabilir.',
        en: 'Slow IV push (rate not exceeding 20 mg/min). Rapid high-dose IV push causes ototoxicity (tinnitus/hearing loss).',
      },
    },
    contraindications: {
      tr: [
        'Hipovolemi veya dehidratasyon',
        'Ağır hipokalemi ve hiponatremi',
        'Sülfonamid alerjisi',
        'Anürik renal yetmezlik',
      ],
      en: [
        'Hypovolemia or dehydration',
        'Severe hypokalemia and hyponatremia',
        'Sulfonamide allergy',
        'Anuric renal failure non-responsive to test dose',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Hipotansif hastada (SAB < 90 mmHg) furosemid vermeyin, önce kardiyojenik şok / iskemi ayrımını yapın.',
        'Verildikten sonra idrar çıkışı ve elektrolitler (K+, Na+) yakından takip edilmelidir.',
      ],
      en: [
        'Do not give furosemide in hypotensive patients (SBP < 90 mmHg); evaluate for cardiogenic shock.',
        'Monitor urine output and serum electrolytes (potassium, sodium) post-administration.',
      ],
    },
    pregnancyCategory: 'C',
    tags: ['Lasix', 'Akciğer Ödemi', 'Kalp Yetersizliği', 'Diüretik', 'Hipertansiyon'],
  },
  {
    id: 'enoxaparin',
    genericName: {
      tr: 'Enoksaparin Sodyum (Düşük Molekül Ağırlıklı Heparin - DMAH)',
      en: 'Enoxaparin Sodium (Low Molecular Weight Heparin - LMWH)',
    },
    brandNamesTR: ['Clexane', 'Oparon', 'Enox', 'Oxapar'],
    category: {
      tr: 'Antikoagülan (Faktör Xa İnhibitörü)',
      en: 'Anticoagulant (Factor Xa Inhibitor)',
    },
    forms: [
      '2000 IU (20 mg / 0.2 ml) Kullanıma Hazır Enjektör',
      '4000 IU (40 mg / 0.4 ml) Enjektör',
      '6000 IU (60 mg / 0.6 ml) Enjektör',
      '8000 IU (80 mg / 0.8 ml) Enjektör',
      '10000 IU (100 mg / 1.0 ml) Enjektör',
    ],
    indications: {
      tr: [
        'Akut Koroner Sendrom (STEMI ve NSTEMI / Kararsız Angina)',
        'Akut Derin Ven Trombozu (DVT) ve Pulmoner Emboli (PE) tedavisi',
        'İmmobil hastalarda venöz tromboemboli (VTE) profilaksisi',
      ],
      en: [
        'Acute Coronary Syndrome (STEMI and NSTEMI / Unstable Angina)',
        'Acute Deep Vein Thrombosis (DVT) and Pulmonary Embolism (PE) treatment',
        'Venous thromboembolism (VTE) prophylaxis in immobilized patients',
      ],
    },
    erAdultDose: {
      tr: 'DVT / PE / NSTEMI Tedavi Dozu: 1 mg/kg (veya 100 IU/kg) 12 saatte bir Subkutan (SC).\nSTEMI Tedavi Dozu: <75 yaş: 30 mg IV bolus + 1 mg/kg SC (maks 100 mg). >75 yaş: IV bolus verilmez, 0.75 mg/kg SC 12 saatte bir.\nVTE Profilaksi: 40 mg (0.4 ml) günde 1 kez SC.',
      en: 'DVT / PE / NSTEMI Treatment: 1 mg/kg (100 IU/kg) Subcutaneously (SC) every 12 hours.\nSTEMI Treatment: <75 years: 30 mg IV bolus + 1 mg/kg SC. >75 years: No IV bolus, 0.75 mg/kg SC q12h.\nVTE Prophylaxis: 40 mg (0.4 ml) SC once daily.',
    },
    administration: {
      route: ['SC (Subkutan)', 'IV (Yalnızca STEMI yüklemesinde)'],
      preparation: {
        tr: 'Karın ön-yan duvarı (göbek çevresi 5 cm dışı) deri kıvrımı tutularak 90 derece dik açıyla subkutan enjekte edilir. İğne ucu çekilene kadar piston tutulur, uygulama yerine masaj YAPILMAZ (hematomu önlemek için).',
        en: 'Inject SC into anterolateral abdominal wall holding skin fold. Do not rub injection site to avoid hematoma.',
      },
    },
    contraindications: {
      tr: [
        'Aktif majör kanama',
        'Heparine bağlı trombositopeni (HIT) öyküsü',
        'Şiddetli böbrek yetmezliği (GFR < 15 ml/dk)',
        'Akut hemorajik inme veya son 3 ayda intrakraniyal kanama',
      ],
      en: [
        'Active major bleeding',
        'History of Heparin-Induced Thrombocytopenia (HIT)',
        'Severe renal impairment (GFR < 15 ml/min - adjust dose for GFR 15-30)',
        'Acute hemorrhagic stroke or recent intracranial bleed',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Böbrek fonksiyonu bozuksa (GFR 15-30 ml/dk): Doz günde 1 kez 1 mg/kg SC\'ye düşürülmelidir.',
        'Kanama durumunda spesifik antidotu Protamin Sülfattır (DMAH etkisini kısmen %60-70 nötralize eder).',
      ],
      en: [
        'If GFR 15-30 ml/min: Adjust treatment dose to 1 mg/kg SC ONCE daily.',
        'In major bleeding, Protamine Sulfate is the reversal agent (partially reverses LMWH ~60-70%).',
      ],
    },
    pregnancyCategory: 'B (Gebelikte DVT/PE tedavisinde en güvenli antikoagülandır)',
    tags: ['Clexane', 'DMAH', 'Pulmoner Emboli', 'DVT', 'Kalp Krizi', 'Antikoagülan'],
  },

  // --- SEDATION / ANTICONVULSANTS ---
  {
    id: 'diazepam',
    genericName: {
      tr: 'Diazepam',
      en: 'Diazepam',
    },
    brandNamesTR: ['Diazem', 'Nervium', 'Diapam'],
    category: {
      tr: 'Benzodiazepin / Antikonvülzan / Anksiyolitik (Yeşil Reçete)',
      en: 'Benzodiazepine / Anticonvulsant / Anxiolytic (Scheduled)',
    },
    forms: [
      '10 mg / 2 ml IM/IV Ampul',
      '2 mg, 5 mg, 10 mg Kapsül / Tablet',
      '5 mg & 10 mg Rektal Tüp',
    ],
    indications: {
      tr: [
        'Status Epileptikus ve uzamış epileptik nöbetler (>5 dk)',
        'Şiddetli ajitasyon ve akut panik / anksiyete krizi',
        'Alkol yoksunluğu (Deliryum tremens profilaksisi ve tedavisi)',
        'Şiddetli akut kas spazmı',
      ],
      en: [
        'Status Epilepticus and prolonged seizures (>5 min)',
        'Severe acute agitation and panic crisis',
        'Alcohol withdrawal syndrome and Delirium Tremens',
        'Severe acute muscle spasm',
      ],
    },
    erAdultDose: {
      tr: 'Akut Nöbet: 5-10 mg Yavaş IV puşe (dakikada 2-5 mg hızında). Nöbet durmazsa 5-10 dakika sonra tekrarlanabilir (Maksimum 30 mg).\nAjitasyon/Alkol Yoksunluğu: 5-10 mg IV veya PO.',
      en: 'Acute Seizure: 5-10 mg slow IV push (at 2-5 mg/min). May repeat after 5-10 min if seizure persists (Max 30 mg).\nAgitation/Alcohol withdrawal: 5-10 mg IV or PO.',
    },
    erPediatricDose: {
      tr: '0.2-0.3 mg/kg IV yavaş (Maks 5-10 mg) veya Rektal tüp (Desitin): <10 kg: 5 mg, >10 kg: 10 mg rektal.',
      en: '0.2-0.3 mg/kg slow IV or Rectal solution (5 mg if <10 kg, 10 mg if >10 kg).',
    },
    administration: {
      route: ['IV', 'PR (Rektal)', 'PO'],
      preparation: {
        tr: 'Doğrudan yavaş IV puşe yapılır. IM emilimi düzensiz ve ağrılıdır; IV yol yoksa rektal formu veya Midazolam IM tercih edilmelidir. SF ile karıştırıldığında bulanıklaşır (çöker).',
        en: 'Administer slow direct IV push. IM absorption is erratic; use Rectal Diazepam or IM Midazolam if no IV access. Incompatible with NS (precipitates).',
      },
    },
    contraindications: {
      tr: [
        'Ağır solunum yetmezliği ve solunum depresyonu',
        'Myastenia gravis',
        'Ağır uyku apnesi sendromu',
        'Koma ve akut intoksikasyon durumları',
      ],
      en: [
        'Severe respiratory depression',
        'Myasthenia gravis',
        'Severe sleep apnea syndrome',
        'Coma and acute CNS depression',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'SOLUNUM ARRESTİ: Hızlı IV verilirse solunumu durdurabilir! Balon-Valf-Maske (Ambu) ve aspiratör başucunda hazır olmalıdır.',
        'Benzodiazepin intoksikasyonu ve aşırı sedasyonunda antidotu Flumazenil (Anexate 0.2-0.5 mg IV)\'dir (Ancak kronik kullanıcılarda nöbet tetikleyebileceği için dikkatli olunmalıdır).',
      ],
      en: [
        'RESPIRATORY ARREST: Rapid IV injection causes apnea. Always have Bag-Valve-Mask (Ambu) and suction ready.',
        'Antidote for overdose is Flumazenil (Anexate 0.2-0.5 mg IV) (use cautiously in chronic users to prevent withdrawal seizures).',
      ],
    },
    pregnancyCategory: 'D',
    tags: ['Diazem', 'Nöbet', 'Epilepsi', 'Sakinleştirici', 'Yeşil Reçete'],
  },
  {
    id: 'midazolam',
    genericName: {
      tr: 'Midazolam',
      en: 'Midazolam',
    },
    brandNamesTR: ['Dormicum', 'Zolamid', 'Demizalam'],
    category: {
      tr: 'Kısa Etkili Benzodiazepin / Prosedürel Sedasyon (Kırmızı Reçete)',
      en: 'Short-Acting Benzodiazepine / Procedural Sedation (Restricted)',
    },
    forms: [
      '5 mg / 5 ml (1 mg/ml) & 15 mg / 3 ml (5 mg/ml) IM/IV Ampul',
    ],
    indications: {
      tr: [
        'Acilde prosedürel sedasyon ve analjezi (Kardiyoversiyon, omuz/kalça çıkığı redüksiyonu, kırık repozisyonu)',
        'Hızlı Seri Entübasyon (RSI) sedasyonu',
        'Status epileptikus (Özellikle damar yolu olmayan hastada IM/İntranazal uygulama)',
      ],
      en: [
        'Procedural sedation in ER (Electrical cardioversion, joint reduction, fracture repositioning)',
        'Rapid Sequence Intubation (RSI) induction',
        'Status epilepticus (especially IM/intranasal route when no IV access)',
      ],
    },
    erAdultDose: {
      tr: 'Sedasyon: 1-2.5 mg IV yavaş (2 dakikada titre edilerek verilir, gerekirse 2 dk sonra 1 mg eklenir).\nEntübasyon (RSI): 0.2 - 0.3 mg/kg IV bolus.\nNöbet (Damar yolu yoksa): 10 mg IM (Tek doz).',
      en: 'Procedural Sedation: 1-2.5 mg slow IV titrated q2min.\nRSI Induction: 0.2-0.3 mg/kg IV bolus.\nSeizure without IV access: 10 mg IM.',
    },
    administration: {
      route: ['IV', 'IM', 'IN (İntranazal)', 'IO'],
      preparation: {
        tr: 'Titrasyon için 5 mg/5 ml formu tercih edilir (1 ml = 1 mg). 1-2 mg verilip hastanın konuşması ve sedasyon derinliği kontrol edilir.',
        en: 'Use 1 mg/ml formulation for careful titration. Titrate in 1-2 mg increments.',
      },
    },
    contraindications: {
      tr: ['Şiddetli solunum depresyonu', 'Dar açılı glokom', 'Şok ve ağır hipotansiyon'],
      en: ['Severe respiratory depression', 'Narrow-angle glaucoma', 'Uncorrected shock/hypotension'],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Kısa sürede derin sedasyon ve hipoventilasyon yapar. Mutlaka monitörize odada, SpO2 ve hava yolu ekipmanı hazırda tutularak uygulanmalıdır.',
      ],
      en: [
        'Rapid onset of deep sedation and apnea. Mandatory continuous SpO2/ECG monitoring and airway equipment at bedside.',
      ],
    },
    pregnancyCategory: 'D',
    tags: ['Dormicum', 'Sedasyon', 'Kardiyoversiyon', 'Redüksiyon', 'Kırmızı Reçete'],
  },

  // --- ANTIBIOTICS & OUTPATIENT INFECTION ---
  {
    id: 'ceftriaxone',
    genericName: {
      tr: 'Seftriakson',
      en: 'Ceftriaxone',
    },
    brandNamesTR: ['Rocephin', 'Novosef', 'Unacefin', 'Ceftinex', 'Desefin', 'Forsef'],
    category: {
      tr: '3. Kuşak Sefalosporin Antibiyotik',
      en: '3rd Generation Cephalosporin Antibiotic',
    },
    forms: [
      '500 mg & 1000 mg (1 g) IM / IV Flakon',
    ],
    indications: {
      tr: [
        'Piyelonefrit ve komplike idrar yolu enfeksiyonları',
        'Toplum kökenli pnömoni (Yatış gereken orta-ağır vakalar)',
        'Akut bakteriyel menenjit (Yüksek doz 2x2g)',
        'Pelvik Enflamatuar Hastalık (PID) ve Gonokokkal enfeksiyonlar',
        'Akut kolesistit ve intraabdominal enfeksiyonlar (Metronidazol ile kombine)',
      ],
      en: [
        'Pyelonephritis and complicated UTIs',
        'Community-acquired pneumonia requiring hospital admission',
        'Acute bacterial meningitis (High dose 2x2g)',
        'Pelvic Inflammatory Disease (PID) and Gonococcal infections',
        'Acute cholecystitis and intra-abdominal infections (with Metronidazole)',
      ],
    },
    erAdultDose: {
      tr: 'Standart Enfeksiyonlar: 1-2 g günde 1 kez IV veya IM.\nMenenjit Protokolü: 2 g IV 12 saatte bir (2x2g/gün).\nKomplike olmayan Gonore: 500 mg IM Tek Doz.',
      en: 'Standard Infections: 1-2 g once daily IV or IM.\nMeningitis: 2 g IV every 12 hours (4 g/day total).\nUncomplicated Gonorrhea: 500 mg IM single dose.',
    },
    erPediatricDose: {
      tr: '50-75 mg/kg/gün tek doz veya ikiye bölünerek (Menenjitte 100 mg/kg/gün, maks 4 g).',
      en: '50-75 mg/kg/day once daily or divided q12h (Meningitis 100 mg/kg/day, max 4 g).',
    },
    administration: {
      route: ['IV', 'IM'],
      preparation: {
        tr: 'IV kullanım: 1 g flakon 10 ml enjeksiyonluk su ile çözülüp 100 ml %0.9 SF içinde en az 30 dakikada infüzyonla verilir.\nIM kullanım: Ağrıyı azaltmak için kutusundan çıkan %1 Lidokain çözücüsü ile eritilip derin gluteal IM yapılır. (LİDOKAİNLİ ÇÖZÜCÜ ASLA IV VERİLMEZ!).',
        en: 'IV use: Dissolve 1 g in 10 ml sterile water, dilute in 100 ml NS and infuse over 30 min.\nIM use: Reconstitute with provided 1% Lidocaine diluent for deep IM injection (NEVER GIVE LIDOCAINE DILUENT IV!).',
      },
    },
    contraindications: {
      tr: [
        'Sefalosporin veya penisiline şiddetli anafilaktik aşırı duyarlılık',
        'Kalsiyum içeren IV solüsyonlar (Ringer Laktat vb.) ile birlikte verilmesi kontrendikedir (Kalsiyum-seftriakson çökeltisi riski)',
        'Yenidoğanlarda hiperbilirubinemi (Kernikterus riski)',
      ],
      en: [
        'Severe anaphylactic hypersensitivity to cephalosporins or penicillins',
        'Co-administration with Calcium-containing IV solutions (Ringer Lactate) precipitates in lungs/kidneys',
        'Hyperbilirubinemic neonates (risk of kernicterus)',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Acilde menenjit şüphesinde Lomber Ponksiyon (LP) gecikecekse antibiyotik tedavisini bekletmeyin, ilk dozu derhal gönderin!',
      ],
      en: [
        'In suspected bacterial meningitis, do not delay antibiotics if Lumbar Puncture is delayed; give the first 2g IV dose immediately!',
      ],
    },
    pregnancyCategory: 'B',
    tags: ['Rocephin', 'Seftriakson', 'Antibiyotik', 'Pnömoni', 'Piyelonefrit', 'Menenjit'],
  },
  {
    id: 'amoxicillin_clavulanate',
    genericName: {
      tr: 'Amoksisilin + Klavulanik Asit',
      en: 'Amoxicillin + Clavulanic Acid',
    },
    brandNamesTR: ['Augmentin', 'Klavunat', 'Klamoks', 'Amoklavin', 'Bioment', 'Croxilex'],
    category: {
      tr: 'Geniş Spektrumlu Penisilin / Beta-laktamaz İnhibitörlü',
      en: 'Broad-Spectrum Penicillin with Beta-lactamase Inhibitor',
    },
    forms: [
      '1000 mg (1 g) Film Tablet (875 mg Amoksisilin + 125 mg Klavulanat)',
      '625 mg Film Tablet',
      '1.2 g IV Flakon',
      'BID 200/28 mg & BID 400/57 mg Oral Süspansiyon (Şurup)',
      'ES 600/42.9 mg Oral Süspansiyon',
    ],
    indications: {
      tr: [
        'Akut bakteriyel tonsillofarenjit (A grubu beta hemolitik streptokok)',
        'Akut bakteriyel rinosinüzit ve akut otitis media',
        'Toplum kökenli hafif pnömoni ve KOAH alevlenmesi',
        'Deri ve yumuşak doku enfeksiyonları (Selülit, kedi/köpek ısırıkları)',
      ],
      en: [
        'Acute bacterial tonsillopharyngitis (Group A Strep)',
        'Acute bacterial rhinosinusitis and acute otitis media',
        'Mild community-acquired pneumonia and acute bronchitis/COPD',
        'Skin and soft tissue infections (Cellulitis, animal bites)',
      ],
    },
    erAdultDose: {
      tr: '1000 mg Film Tablet: Günde 2 kez (2x1) Tok karnına 7-10 gün. (Yemek başlangıcında alınması GİS toleransını artırır).',
      en: '1000 mg Film Tablet: 1 tablet twice daily (q12h) with meals for 7-10 days.',
    },
    erPediatricDose: {
      tr: 'Standart doz: 40-50 mg/kg/gün (amoksisilin bazı üzerinden) 2 eşit doza bölünerek (BID formülasyon).\nYüksek doz (Otitis media / Dirençli pnömokok): 80-90 mg/kg/gün (ES 600 formülasyonu ile).',
      en: 'Standard dose: 40-50 mg/kg/day divided BID. High dose (AOM/Pneumococcal resistance): 80-90 mg/kg/day divided BID.',
    },
    administration: {
      route: ['PO', 'IV'],
      preparation: {
        tr: 'Tabletler yemeklerin başında çiğnenmeden yutulmalıdır. Şurup hazırlanırken kaynatılıp soğutulmuş su çizgiye kadar eklenip iyice çalkalanmalı ve buzdolabında saklanmalıdır (7-10 gün geçerli).',
        en: 'Take tablets at the start of a meal to minimize GI upset. Reconstituted suspension must be refrigerated and used within 7-10 days.',
      },
    },
    contraindications: {
      tr: [
        'Penisilin veya beta-laktam antibiyotik alerjisi (Anafilaksi öyküsü)',
        'Amoksisilin/klavulanat ilişkili kolestatik sarılık veya karaciğer fonksiyon bozukluğu öyküsü',
        'İnfeksiyöz Mononükleoz (EBV) - Ampisilin döküntüsüne yol açar!',
      ],
      en: [
        'Penicillin or beta-lactam hypersensitivity',
        'Previous history of amoxicillin-clavulanate associated cholestatic jaundice/hepatic dysfunction',
        'Infectious Mononucleosis (EBV) - causes severe maculopapular rash!',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'En sık yan etkisi ishal ve karın ağrısıdır (Klavulanik aside bağlı). Probiyotik veya yoğurt tüketimi önerilebilir.',
        'Hastaya penisilin alerjisi mutlaka sorulmalıdır (Döküntü, nefes darlığı, dudak şişmesi oldu mu?).',
      ],
      en: [
        'Most common side effect is diarrhea and abdominal cramps. Suggest taking with meals or taking probiotics.',
        'Always screen for penicillin allergy before prescribing.',
      ],
    },
    pregnancyCategory: 'B',
    tags: ['Augmentin', 'Antibiyotik', 'Boğaz Ağrısı', 'Sinüzit', 'Otitis Media', 'Reçete'],
  },
  {
    id: 'ciprofloxacin',
    genericName: {
      tr: 'Siprofloksasin',
      en: 'Ciprofloxacin',
    },
    brandNamesTR: ['Cipro', 'Ciproxin', 'Siprosan', 'Ciprasid', 'Roxacin'],
    category: {
      tr: 'Florokinolon Grubu Antibiyotik',
      en: 'Fluoroquinolone Antibiotic',
    },
    forms: [
      '500 mg & 750 mg Film Tablet',
      '200 mg / 100 ml & 400 mg / 200 ml IV İnfüzyon Şişesi',
      '%0.3 Göz ve Kulak Damlası',
    ],
    indications: {
      tr: [
        'Komplike İdrar Yolu Enfeksiyonları ve Akut Piyelonefrit',
        'Akut Bakteriyel Prostatit',
        'İnvaziv bakteriyel gastroenterit (Şiddetli kanlı ishal / Shigella, Salmonella, Kampilobakter)',
      ],
      en: [
        'Complicated Urinary Tract Infections and Acute Pyelonephritis',
        'Acute Bacterial Prostatitis',
        'Severe invasive bacterial diarrhea (dysentery)',
      ],
    },
    erAdultDose: {
      tr: 'Oral: 500 mg Tablet 12 saatte bir (2x1) 7-14 gün (Prostatitte 2-4 hafta).\nIV İnfüzyon: 200-400 mg IV 12 saatte bir (60 dakikada infüzyon).',
      en: 'Oral: 500 mg Tablet twice daily (q12h) for 7-14 days (2-4 weeks for prostatitis).\nIV Infusion: 200-400 mg IV q12h infused over 60 min.',
    },
    administration: {
      route: ['PO', 'IV', 'Topikal (Göz/Kulak)'],
      preparation: {
        tr: 'IV infüzyon en az 60 dakikada gönderilmelidir. Oral form antiasitler, demir, kalsiyum veya süt ürünleri ile en az 2 saat arayla alınmalıdır (emilimi bozulur).',
        en: 'Infuse IV over at least 60 min. Separate oral dose from dairy, antacids, and iron supplements by at least 2 hours.',
      },
    },
    contraindications: {
      tr: [
        'Florokinolon alerjisi',
        'Tizanidin ile eşzamanlı kullanım (şiddetli hipotansiyon ve sedasyon)',
        'Tendonit veya tendon rüptürü öyküsü',
        'Myastenia gravis (Kas güçsüzlüğünü alevlendirir)',
        'Gebelik ve emzirme dönemi (Kıkırdak hasarı riski)',
      ],
      en: [
        'Fluoroquinolone hypersensitivity',
        'Concomitant tizanidine use',
        'History of tendonitis or tendon rupture',
        'Myasthenia gravis exacerbation',
        'Pregnancy and breastfeeding (arthropathy risk)',
      ],
    },
    redFlagsAndPrecautions: {
      tr: [
        'AŞİL TENDON RÜPTÜRÜ: Özellikle yaşlı ve steroid kullananlarda tendonit ve kopma riski oluşturur; ayak bileğinde ağrı olursa ilaç derhal kesilmelidir.',
        'AORT ANEVRİZMASI / DİSEKSİYONU RİSKİ: Anevrizma riski olan hastalarda zorunlu olmadıkça kinolonlardan kaçınılmalıdır.',
        'QT aralığını uzatabilir.',
      ],
      en: [
        'ACHILLES TENDON RUPTURE risk, especially in elderly and patients on steroids.',
        'AORTIC ANEURYSM / DISSECTION risk: Avoid in patients with known aneurysm unless no alternative.',
        'Prolongs QT interval.',
      ],
    },
    pregnancyCategory: 'C',
    tags: ['Cipro', 'Piyelonefrit', 'Prostatit', 'İdrar Yolu', 'Kinolon'],
  },
  {
    id: 'fosfomycin',
    genericName: {
      tr: 'Fosfomisin Trometamol',
      en: 'Fosfomycin Trometamol',
    },
    brandNamesTR: ['Monurol Saşe', 'Uromisin', 'Monural', 'Fosfomed'],
    category: {
      tr: 'Üriner Antibakteriyel (Tek Doz Sistit İlacı)',
      en: 'Urinary Antibacterial (Single-Dose Cystitis Drug)',
    },
    forms: [
      '3 g Granül İçeren Saşe',
    ],
    indications: {
      tr: [
        'Kadınlarda komplike olmayan akut sistit (Alt üriner sistem enfeksiyonu)',
        'Gebelikte asemptomatik bakteriüri veya akut sistit',
      ],
      en: [
        'Uncomplicated acute cystitis in adult females',
        'Asymptomatic bacteriuria or acute cystitis in pregnancy',
      ],
    },
    erAdultDose: {
      tr: '3 g Saşe: TEK DOZ (1x1). Gece yatmadan önce, mesane boşaltıldıktan sonra 1 bardak suda eritilerek içilir.',
      en: '3 g Sachet: SINGLE DOSE. Dissolve in one glass of water and drink at bedtime after emptying bladder.',
    },
    administration: {
      route: ['PO'],
      preparation: {
        tr: '1 saşe soğuk veya ılık 1 bardak (yaklaşık 150-200 ml) suda karıştırılarak tamamen eritilir ve hemen içilir. Aç karnına veya yemeklerden 2-3 saat sonra alınmalıdır.',
        en: 'Dissolve in 150-200 ml water and drink immediately. Take on an empty stomach (or 2-3 hours after meal) at night.',
      },
    },
    contraindications: {
      tr: ['Ağır böbrek yetmezliği (GFR < 10 ml/dk)', 'Fosfomisine aşırı duyarlılık'],
      en: ['Severe renal impairment (GFR < 10 ml/min)', 'Hypersensitivity to fosfomycin'],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Eğer hastada yan ağrısı (kostovertebral açı hassasiyeti - KVAH), ateş (>38°C) veya bulantı/kusma varsa bu basit sistit değil PİYELONEFRİT\'tir; tek doz fosfomisin yetersiz kalır, sistemik seftriakson/siprofloksasin gerekir!',
      ],
      en: [
        'If flank pain (CVA tenderness), fever (>38°C), or nausea is present, this is PYELONEPHRITIS, not simple cystitis. Single-dose fosfomycin is insufficient; initiate systemic Ceftriaxone or Ciprofloxacin!',
      ],
    },
    pregnancyCategory: 'B (Gebelikte sistit tedavisinde çok güvenli ve ilk seçeneklerdendir)',
    tags: ['Monurol', 'Sistit', 'İdrar Yolu Enfeksiyonu', 'Tek Doz', 'Yeşil Alan Reçetesi'],
  },
  {
    id: 'naloxone',
    genericName: {
      tr: 'Nalokson Hidroklorür',
      en: 'Naloxone Hydrochloride',
    },
    brandNamesTR: ['Narcan', 'Nalokson Ampul'],
    category: {
      tr: 'Saf Opioid Reseptör Antagonisti / Antidot',
      en: 'Pure Opioid Receptor Antagonist / Antidote',
    },
    forms: [
      '0.4 mg / 1 ml IM/IV Ampul',
      '4 mg İntranazal Sprey',
    ],
    indications: {
      tr: [
        'Akut opioid aşırı dozu / toksisitesi (Solunum depresyonu, miyotik pupiller, koma)',
        'Acilde aşırı sedatize olmuş opioid hastalarında solunumun geri döndürülmesi',
      ],
      en: [
        'Acute opioid overdose (Respiratory depression, pinpoint pupils, altered mental status)',
        'Reversal of opioid-induced respiratory depression',
      ],
    },
    erAdultDose: {
      tr: '0.04 - 0.4 mg IV yavaş (Solunum sayısını > 10-12/dk yapana kadar küçük dozlarla titre edilir). Solunum düzelmezse her 2-3 dakikada bir 0.4 mg artırılarak tekrarlanır (Maks 10 mg).',
      en: '0.04 - 0.4 mg slow IV titrated to restore adequate spontaneous respiration (RR > 10-12/min). Repeat q2-3min if no response (up to 10 mg).',
    },
    administration: {
      route: ['IV', 'IM', 'IN (İntranazal)', 'SC', 'Endotrakeal'],
      preparation: {
        tr: '1 ampul (0.4 mg) 9 ml SF içine çekilerek 10 ml yapılır (0.04 mg/ml). Her seferinde 1-2 ml (0.04-0.08 mg) yavaşça verilerek hastanın aniden şiddetli yoksunluk krizine ve ajitasyona girmesi engellenir.',
        en: 'Dilute 0.4 mg with 9 ml NS (0.04 mg/ml). Titrate in 1-2 ml increments to avoid precipitating acute explosive opioid withdrawal.',
      },
    },
    contraindications: {
      tr: ['Naloksona aşırı duyarlılık (Acil opioid toksisitesinde mutlak kontrendikasyonu yoktur)'],
      en: ['Hypersensitivity (No absolute contraindication in life-threatening opioid overdose)'],
    },
    redFlagsAndPrecautions: {
      tr: [
        'DİKKAT YARI ÖMÜR: Naloksonun etki süresi (30-60 dakika) çoğu opioidden (özellikle Metadon ve yavaş salınımlı morfin/fentanil) daha kısadır! Hasta uyanıp iyileşse bile etkisi geçince TEKRAR SOLUNUM DEPRESYONUNA ve KOMAYA girebilir. En az 4-6 saat yakın gözlemde tutulmalıdır.',
      ],
      en: [
        'HALF-LIFE WARNING: Naloxone duration (30-60 min) is shorter than most opioids (Methadone, Morphine SR). Patient may resedate and stop breathing after naloxone wears off! Monitor in ER for at least 4-6 hours.',
      ],
    },
    pregnancyCategory: 'B',
    tags: ['Nalokson', 'Narcan', 'Opioid Antidotu', 'Morfin Zehirlenmesi', 'Kırmızı Alan'],
  },
  {
    id: 'acetylcysteine',
    genericName: {
      tr: 'Asetilsistein (N-Asetilsistein / NAC)',
      en: 'Acetylcysteine (N-Acetylcysteine / NAC)',
    },
    brandNamesTR: ['Asist', 'Mukolyx', 'Mentopin', 'Cisteil', 'Fluimucil'],
    category: {
      tr: 'Parasetamol Antidotu / Mukolitik',
      en: 'Paracetamol Antidote / Mucolytic',
    },
    forms: [
      '300 mg / 3 ml (%10) IM/IV Ampul',
      '600 mg & 1200 mg Efervesan Tablet / Saşe',
      '200 mg / 5 ml Şurup',
    ],
    indications: {
      tr: [
        'Akut parasetamol (asetaminofen) intoksikasyonu ve karaciğer yetmezliğini önleme',
        'Yoğun mukuslu solunum yolu hastalıklarında mukolitik',
      ],
      en: [
        'Acute paracetamol (acetaminophen) overdose & hepatotoxicity prevention',
        'Mucolytic in acute and chronic bronchopulmonary diseases',
      ],
    },
    erAdultDose: {
      tr: 'Parasetamol Antidot 21 Saatlik IV Protokolü:\n1. Yükleme: 150 mg/kg (200 ml %5 Dekstroz içinde 60 dakikada)\n2. İkinci Doz: 50 mg/kg (500 ml D5W içinde 4 saatte)\n3. Üçüncü Doz: 100 mg/kg (1000 ml D5W içinde 16 saatte)',
      en: 'Paracetamol 21-Hour IV Protocol:\n1. Loading: 150 mg/kg in 200 ml D5W over 60 min\n2. 2nd Dose: 50 mg/kg in 500 ml D5W over 4 hours\n3. 3rd Dose: 100 mg/kg in 1000 ml D5W over 16 hours',
    },
    administration: {
      route: ['IV', 'PO'],
      preparation: {
        tr: 'Antidot protokolünde mutlaka %5 Dekstroz içinde infüzyonla verilir. Mukolitik olarak 600-1200 mg/gün oral efervesan.',
        en: 'For toxicity, infuse IV diluted in 5% Dextrose. As mucolytic, 600-1200 mg/day orally.',
      },
    },
    contraindications: {
      tr: ['Asetilsisteine aşırı duyarlılık (Hayati toksisitede antihistaminik premedikasyonu ile devam edilir)'],
      en: ['Hypersensitivity (In toxicity, treat mild anaphylactoid reactions with antihistamines and continue)'],
    },
    redFlagsAndPrecautions: {
      tr: [
        'Parasetamol alımından sonraki ilk 8 saat içinde başlandığında hepatotoksisiteyi neredeyse %100 önler. 8 saat geçmiş olsa bile şüpheli yüksek dozda tedaviye derhal başlanmalıdır.',
        'İnfüzyon sırasında anafilaktoid reaksiyon (kaşıntı, kızarıklık, bronkospazm) gelişebilir; infüzyon hızı yavaşlatılıp Avil/Prednol verilebilir.',
      ],
      en: [
        'Almost 100% hepatoprotective when initiated within 8 hours of ingestion. Start immediately even if presentation is delayed.',
        'Anaphylactoid reactions (flushing, rash, bronchospasm) can occur during IV infusion; manage with slowing rate and antihistamines.',
      ],
    },
    pregnancyCategory: 'B',
    tags: ['Asist', 'Parasetamol Antidotu', 'Toksikoloji', 'Karaciğer Koruma', 'Zehirlenme'],
  },
];
