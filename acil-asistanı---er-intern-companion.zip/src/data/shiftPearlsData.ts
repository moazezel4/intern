import { ShiftPearl } from '../types';

export const SHIFT_PEARLS_DATABASE: ShiftPearl[] = [
  {
    id: 'triage_system_tr',
    title: {
      tr: 'Türkiye Acil Triyaj Renk Kodları (Yeşil - Sarı - Kırmızı)',
      en: 'Turkey ER Triage Color System (Green - Yellow - Red)',
    },
    category: {
      tr: 'Triyaj & Nöbet Yönetimi',
      en: 'Triage & Shift Management',
    },
    iconName: 'ShieldAlert',
    isHighYield: true,
    content: {
      tr: 'Acil serviste hastaların öncelik sırası başvuru sırasına göre DEĞİL, klinik aciliyetine ve hayati tehlikesine göre belirlenir. Sağlık Bakanlığı renk kodlama sistemi esastır.',
      en: 'Patient priority in the emergency department is strictly governed by clinical urgency and life threat, not arrival order.',
    },
    bulletPoints: {
      tr: [
        '🔴 KIRMIZI ALAN (Öncelik 1 - Bekleme Süresi 0 Dakika): Hayatı tehdit eden durumlar. Kardiyak arrest, majör politravma, anafilaksi, status epileptikus, koma (GKS <8), STEMI, masif kanama/şok, solunum yetmezliği. Doğrudan Resüsitasyon Odasına alınır.',
        '🟡 SARI ALAN (Öncelik 2 - İdeal Değerlendirme <30-60 Dakika): Potansiyel hayati tehlikesi olan veya acil tetkik/tedavi gerektiren durumlar. Akut karın şüphesi, stabil göğüs ağrısı, renal kolik, orta dereceli astım atağı, yüksek ateşli çocuk, kırık/çıkıklar, GİS kanama şüphesi.',
        '🟢 YEŞİL ALAN (Öncelik 3 - Ayaktan Hastalar): Hayati tehlikesi ve acil organ kaybı riski olmayan hafif vakalar. Tonsillofarenjit, basit idrar yolu enfeksiyonu, hafif kas spazmı/lumbago, hafif gastroenterit, kronik reçete tekrarı, minör sıyrık/pansuman.',
      ],
      en: [
        '🔴 RED ZONE (Priority 1 - 0 min wait): Immediate life threat. Cardiac arrest, polytrauma, anaphylaxis, status epilepticus, coma (GCS <8), STEMI, hemorrhagic shock. Straight to Resuscitation Room.',
        '🟡 YELLOW ZONE (Priority 2 - <30-60 min): Potentially unstable. Acute abdomen, stable chest pain, renal colic, moderate asthma, high pediatric fever, fractures, GI bleeding.',
        '🟢 GREEN ZONE (Priority 3 - Ambulatory): Non-urgent minor ailments. Pharyngitis, uncomplicated cystitis, mild lumbago/spasm, mild viral gastroenteritis, minor abrasions.',
      ],
    },
  },
  {
    id: 'ecg_6_step_algorithm',
    title: {
      tr: 'Acil EKG Okuma 6-Adım Algoritması',
      en: 'Emergency ECG 6-Step Fast Interpretation',
    },
    category: {
      tr: 'Kardiyoloji & EKG',
      en: 'Cardiology & ECG',
    },
    iconName: 'Activity',
    isHighYield: true,
    content: {
      tr: 'Nöbet sırasında EKG incelerken sistematik 6 adımı asla atlamayın:',
      en: 'Systematic 6-step interpretation to avoid missing critical ischemic and rhythm emergencies:',
    },
    bulletPoints: {
      tr: [
        '1. HIZ & RİTİM: Düzenli mi? P dalgası var mı? (Her P\'yi QRS izliyor mu?). Hız = 300 / iki R arası büyük kare sayısı (veya 1500 / küçük kare sayısı).',
        '2. AKS DEĞERLENDİRMESİ: DI (+) ve aVF (+) ise NORMAL AKS (0° ile +90°). DI (+) aVF (-) ise SOL AKS. DI (-) aVF (+) ise SAĞ AKS.',
        '3. İSKEMİ & STEMI KONTROLÜ (Ardışık derivasyon kuralı):\n - İnferior: DII, DIII, aVF (Sağ Koroner - RCA)\n - Anterior: V1-V4 (Sol Ön İnen - LAD)\n - Lateral: DI, aVL, V5, V6 (Sirkumfleks - Cx)\n - Posterior: V7-V9 ST elevasyonu ve V1-V3\'te ayna ST depresyonu + uzun R.',
        '4. QRS GENİŞLİĞİ & DAL BLOKLARI: QRS > 120 ms (3 küçük kare) ise geniş. V1\'de rSR\' (tavşan kulağı) = Sağ Dal Bloğu (RBBB). V5-V6\'da geniş çentikli R, V1\'de derin QS = Sol Dal Bloğu (LBBB).',
        '5. QTc ARALIĞI: Bazett formülü QTc = QT / √RR. Erkeklerde >450 ms, Kadınlarda >470 ms UZUN QT kabul edilir (>500 ms Torsades de Pointes riski!).',
        '6. KANSER/ÖLÜMCÜL EKG İŞARETLERİ: De Winter T dalgaları (LAD proksimal oklüzyonu), Wellens Sendromu (V2-V3 bifazik/derin ters T), Brugada paterni (V1-V2 kubbe ST ve RBBB), S1Q3T3 (Pulmoner Emboli).',
      ],
      en: [
        '1. Rate & Rhythm: Regular? P before every QRS? Rate = 300 / large squares between R-R.',
        '2. Axis: Lead I (+) & aVF (+) = Normal. I (+) & aVF (-) = Left Axis. I (-) & aVF (+) = Right Axis.',
        '3. Ischemia & STEMI: Contiguous leads rule (Inferior: II, III, aVF; Anterior: V1-V4; Lateral: I, aVL, V5-V6; Posterior: V7-V9).',
        '4. QRS Duration: >120 ms is wide. V1 rSR\' = RBBB. V6 broad notched R / V1 QS = LBBB.',
        '5. QTc Interval: Normal <450ms (males), <470ms (females). >500ms is high risk for Torsades de Pointes.',
        '6. STEMI Equivalents: de Winter T waves, Wellens Syndrome, Brugada Pattern, S1Q3T3.',
      ],
    },
  },
  {
    id: 'abg_solver_4_steps',
    title: {
      tr: 'Kan Gazı (AKG / VİKG) 4 Adımda Hızlı Çözüm',
      en: 'Blood Gas (ABG/VBG) 4-Step Quick Solver',
    },
    category: {
      tr: 'Yoğun Bakım & İç Hastalıkları',
      en: 'Critical Care & Internal Medicine',
    },
    iconName: 'Zap',
    isHighYield: true,
    content: {
      tr: 'Arteriyel veya venöz kan gazını 30 saniyede doğru yorumlamak için 4 altın kural:',
      en: 'Rapid 30-second blood gas interpretation algorithm:',
    },
    bulletPoints: {
      tr: [
        '1. pH Kontrolü: Normal: 7.35 - 7.45. pH < 7.35 ise ASİDOZ. pH > 7.45 ise ALKALOZ.',
        '2. Primer Bozukluğu Belirle (pCO2 ve HCO3):\n - pCO2 yönü pH ile ters ise SOLUNUMSALDIR (Örn: pH düşük, pCO2 > 45 -> Solunumsal Asidoz).\n - HCO3 yönü pH ile aynı ise METABOLİKTİR (Örn: pH düşük, HCO3 < 22 -> Metabolik Asidoz).',
        '3. Metabolik Asidozda ANYON AÇIĞINI Hesapla: Anyon Açığı (AG) = Na - (Cl + HCO3). Normal değer: 10-12 mEq/L. AG > 12 ise YÜKSEK ANYON AÇIKLI ASİDOZ (GOLDMARK / MUDPILES: Metanol, Üremi/ABH, DKA - Diyabetik Ketoasidoz, L-Laktat - Sepsis/Şok, İlaçlar).',
        '4. Solunum Yetmezliği Tipi: Tip 1 (Hipoksemik): PaO2 < 60 mmHg, pCO2 normal/düşük. Tip 2 (Hiperkapnik): PaO2 < 60 mmHg VE pCO2 > 50 mmHg (KOAH alevlenme, hipoventilasyon, yorgunluk -> Non-invaziv BiPAP veya entübasyon adayı).',
      ],
      en: [
        '1. Check pH: 7.35-7.45. pH <7.35 = Acidosis, pH >7.45 = Alkalosis.',
        '2. Identify Primary Driver: If pCO2 opposes pH -> Respiratory. If HCO3 aligns with pH -> Metabolic.',
        '3. If Metabolic Acidosis, calculate Anion Gap: AG = Na - (Cl + HCO3). AG >12 = High Anion Gap Metabolic Acidosis (Ketoacidosis, Lactic acidosis, Uremia, Toxins).',
        '4. Respiratory Failure Type: Type 1 Hypoxemic (PaO2 <60, pCO2 low/normal). Type 2 Hypercapnic (PaO2 <60 AND pCO2 >50 -> consider BiPAP/NIV or intubation).',
      ],
    },
  },
  {
    id: 'intern_medicolegal_rules',
    title: {
      tr: 'İntörn Hekimin Hayat Kurtaran 5 Medikolegal Kuralı',
      en: 'Top 5 Medicolegal Rules for Intern Doctors in Turkey',
    },
    category: {
      tr: 'Medikolegal & Klinik Pratik',
      en: 'Medicolegal & Clinical Practice',
    },
    iconName: 'FileCheck2',
    isHighYield: true,
    content: {
      tr: 'Acil nöbetlerinde yasal ve mesleki olarak kendinizi ve hastayı korumak için vazgeçilmez kurallar:',
      en: 'Essential legal and safety pearls for emergency rotation in Turkey:',
    },
    bulletPoints: {
      tr: [
        '1. "YAZILMAYAN ŞEY YAPILMAMIŞTIR": Hastaya sorduğunuz negatif soruları (Örn: "Göğüs ağrısı yok, nefes darlığı yok, batında defans/rebound yok") mutlaka acil epikrizine ve dosyasında fizik muayene bölümüne açıkça kaydedin.',
        '2. KIRMIZI ALAN & YATIRILAN HASTALARI KIDEMLİYE DANIŞIN: Şüphelendiğiniz her EKG değişikliğini, akut batın şüphesini veya yatış gerektiren durumu kıdemli asistana veya acil uzmanına mutlaka gösterip onayını alın.',
        '3. ADLİ VAKA BİLDİRİMİ: Trafik kazası, darp, ateşli/kesici delici alet yaralanması, intihar girişimi, şüpheli zehirlenme, iş kazası ve düşmeler YASAL OLARAK ADLİ VAKADIR. Mutlaka "Adli Muayene Formu" doldurulmalı ve hastane polisine bildirilmelidir.',
        '4. İLAÇ ALERJİSİ VE GEBELİK SORGULAMASI: Her antibiyotik (özellikle Penisilin/Sefalosporin) ve NSAİİ öncesi alerji öyküsü, doğurganlık çağındaki her kadın hastada son adet tarihi ve gebelik ihtimali sorulmalıdır.',
        '5. İZİNSİZ TABURCULUK (Kendi İsteğiyle Ayrılma): Hasta tedaviyi veya yatışı reddedip gitmek isterse olası riskler (ölüm, felç, organ kaybı vb.) kendisine açıkça anlatılmalı ve "Tedaviyi Red / Kendi İsteğiyle Taburculuk Formu" (Gerektiğinde şahitler huzurunda) imzalatılmalıdır.',
      ],
      en: [
        '1. "If it wasn\'t documented, it wasn\'t done": Always record relevant pertinent negatives in the chart.',
        '2. Always discuss Red Zone, abnormal ECGs, and surgical abdomen cases with senior resident/attending.',
        '3. Forensic Case Reporting: Traffic accidents, assaults, penetrating wounds, suicide attempts, and occupational injuries require mandatory forensic medical reporting.',
        '4. Screen for drug allergies and pregnancy before ordering medications.',
        '5. Against Medical Advice (AMA): If patient refuses treatment/admission, clearly explain risks and obtain signed AMA form.',
      ],
    },
  },
];
