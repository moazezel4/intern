import { MinorDisease } from '../types';

export const MINOR_DISEASES_DATABASE: MinorDisease[] = [
  {
    id: 'tonsillopharyngitis',
    title: {
      tr: 'Akut Tonsillofarenjit (Boğaz Enfeksiyonu)',
      en: 'Acute Tonsillopharyngitis (Sore Throat)',
    },
    category: {
      tr: 'Üst Solunum Yolu Enfeksiyonları',
      en: 'Upper Respiratory Tract Infections',
    },
    triageColor: 'green',
    summary: {
      tr: 'Acil Yeşil Alanda en sık görülen şikayetlerden biridir. Olguların %70-80\'i viraldir (Rinovirüs, Adenovirüs, EBV). Bakteriyel etkenlerin en önemlisi A Grubu Beta-Hemolitik Streptokoktur (GAS). Modifiye Centor Kriterleri (Ateş >38°C, Tonsiller eksüda, Hassas ön servikal LAP, Öksürük yokluğu, Yaş) ile antibiyotik gereksinimi belirlenir (Skor ≥3 ise antibiyotik endikedir).',
      en: 'One of the most frequent Green Zone complaints. 70-80% are viral. Group A Beta-Hemolytic Streptococcus (GAS) is the primary bacterial etiology. Use Modified Centor Criteria (Fever >38°C, Tonsillar exudates, Tender anterior cervical adenopathy, Absence of cough, Age) to guide antibiotic prescribing (Score ≥3 indicates antibiotics).',
    },
    clinicalKeys: {
      tr: [
        'Öksürük ve burun akıntısı varlığı viral kökeni güçlü destekler (Gereksiz antibiyotikten kaçının!).',
        'Centor Skoru: Ateş (+1), Tonsiller Eksüda (+1), Ön Servikal LAP (+1), Öksürük Yokluğu (+1), Yaş 3-14 (+1), Yaş 15-44 (0), Yaş ≥45 (-1).',
        'EBV (Mononükleoz) şüphesinde (yaygın LAP, splenomegali, belirgin halsizlik) Aminopenisilin (Augmentin) VERMEYİN, yaygın kaşıntılı makülopapüler döküntü yapar!',
      ],
      en: [
        'Presence of cough and rhinorrhea strongly suggests viral etiology (avoid unnecessary antibiotics).',
        'Centor Score: Fever (+1), Tonsillar exudate (+1), Anterior cervical LAD (+1), No cough (+1), Age 3-14 (+1), Age 15-44 (0), Age ≥45 (-1).',
        'In suspected Infectious Mononucleosis (EBV), NEVER prescribe aminopenicillins (Augmentin) due to severe maculopapular rash reaction.',
      ],
    },
    redFlagsForConsultation: {
      tr: [
        'Peritonsiller Apse bulguları: Tek taraflı şiddetli boğaz ağrısı, uvulanın karşıya deviasyonu, trismus (çene açmada kısıtlılık), "sıcak patates" sesi -> KBB KONSÜLTASYONU!',
        'Epiglottit bulguları: Hızlı ilerleyen nefes darlığı, yutkunamama / salya akması (drooling), "tripod" pozisyonunda oturma -> ACİL HAVAYOLU GÜVENLİĞİ!',
        'Retrofarengiyal apse veya derin boyun enfeksiyonu (Boyunda yaygın ödem, tortikolis).',
      ],
      en: [
        'Peritonsillar abscess: Unilateral severe pain, uvular deviation to opposite side, trismus, "hot potato" muffled voice -> Urgent ENT Consultation!',
        'Epiglottitis: Rapid stridor, drooling, inability to swallow, tripod posture -> Immediate airway emergency!',
        'Deep neck space infection / Retropharyngeal abscess (neck swelling, torticollis).',
      ],
    },
    erOrder: {
      ivAccess: false,
      medications: {
        tr: [
          'Şiddetli odinofaji ve ateş varsa acil serviste: Parol 1000 mg IV infüzyon veya Arveles 50 mg IM/IV.',
          'Şiddetli yutma güçlüğü ve ödemde tek doz: Dekort 8 mg (Deksametazon) veya Prednol 40 mg IV/IM (ağrıyı hızla azaltır).',
        ],
        en: [
          'For severe odynophagia/fever in ER: Paracetamol 1000 mg IV infusion or Dexketoprofen 50 mg IM/IV.',
          'Single-dose anti-inflammatory steroid: Dexamethasone 8 mg (Dekort) or Methylprednisolone 40 mg IV/IM.',
        ],
      },
    },
    outpatientPrescription: {
      diagnosisCode: 'J03.9 - Akut Tonsillit, Tanımlanmamış',
      diagnosisName: {
        tr: 'Akut Bakteriyel Tonsillofarenjit Reçetesi (Centor ≥ 3)',
        en: 'Acute Bacterial Tonsillitis Prescription (Centor ≥ 3)',
      },
      items: [
        {
          drugName: 'AUGMENTIN-BID 1000 mg 14 Film Tablet',
          activeIngredient: 'Amoksisilin + Klavulanik Asit 1000 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 2 x 1 (12 saatte bir, yemek başında tok karnına) - 7-10 gün',
            en: 'S: 2 x 1 (every 12 hours with meals) - 7-10 days',
          },
          notes: {
            tr: 'Penisilin alerjisi varsa yerine: KLACID 500 mg 14 Film Tablet (Klaritromisin) 2x1 veya AZITRO 500 mg 3 Tablet (Azitromisin) 1x1.',
            en: 'If penicillin allergy: Clarithromycin 500 mg (Klacid) 2x1 or Azithromycin 500 mg (Azitro) 1x1 for 3-5 days.',
          },
        },
        {
          drugName: 'ARVELES 25 mg 20 Film Tablet',
          activeIngredient: 'Deksketoprofen Trometamol 25 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 2 x 1 veya 3 x 1 (Ağrı ve ateş durumunda tok karnına)',
            en: 'S: 2 x 1 or 3 x 1 (with food as needed for pain/fever)',
          },
        },
        {
          drugName: 'TANTUM VERDE Oral Sprey 30 ml',
          activeIngredient: 'Benzidamin Hidroklorür',
          boxCount: 'DİB: 1 (Bir) Şişe',
          dosageInstructions: {
            tr: 'S: 3 x 4 Püskürtme (Boğaza püskürtülüp yutulmadan beklenir)',
            en: 'S: 3 x 4 sprays topically into throat',
          },
        },
      ],
      nonPharmacologicalAdvice: {
        tr: [
          'Bol ılık sıvı tüketimi (ıhlamur, nane-limon, bal).',
          'Ilık tuzlu su ile günde 3-4 kez boğaz gargarası yapılması.',
          'Baharatlı, asitli ve sert gıdalardan kaçınma.',
          'Diş fırçasının tedavi bitiminde yenisiyle değiştirilmesi (tekrar kolonizasyonu önler).',
        ],
        en: [
          'Warm fluids and adequate hydration.',
          'Warm salt water gargling 3-4 times daily.',
          'Avoid irritant/spicy foods.',
          'Replace toothbrush after antibiotic course to prevent reinfection.',
        ],
      },
    },
    returnToERCriteria: {
      tr: [
        'Ağzı açmakta zorlanma (çene kilitlenmesi) veya tek taraflı boğazda şişlik artışı',
        'Nefes almada zorlanma veya hırıltı (stridor)',
        '3 gün antibiyotiğe rağmen düşmeyen dirençli ateş (>39°C)',
        'Sıvı dahi yutamama ve beslenememe',
      ],
      en: [
        'Difficulty opening mouth (trismus) or unilateral bulging of throat',
        'Shortness of breath or stridor',
        'Persistent high fever (>39°C) after 3 days of antibiotics',
        'Inability to swallow liquids or maintain hydration',
      ],
    },
  },
  {
    id: 'acute_gastroenteritis',
    title: {
      tr: 'Akut Gastroenterit (AGE / İshal & Kusma)',
      en: 'Acute Gastroenteritis (Diarrhea & Vomiting)',
    },
    category: {
      tr: 'Gastrointestinal Aciller',
      en: 'Gastrointestinal Emergencies',
    },
    triageColor: 'yellow',
    summary: {
      tr: 'Günde 3\'ten fazla sulu dışkılama ve/veya kusma ile seyreder. Vakaların çoğunluğu viraldir (Norovirüs, Rotavirüs). Tedavinin 1 numaralı esası DEHİDRATASYONUN ÖNLENMESİ ve ELEKTROLİT DENGESİNİN SAĞLANMASIDIR. Rutin ampirik antibiyotik ÖNERİLMEZ (Yalnızca kanlı ishal / dizanteri, yüksek ateş, ağır sepsis veya immünsüpresyonda endikedir).',
      en: 'Frequent loose stools and emesis. Predominantly viral (Norovirus, Rotavirus). Rehydration and electrolyte replacement are the cornerstone of management. Routine empirical antibiotics are NOT recommended unless fever, bloody stools (dysentery), sepsis, or immunocompromised status is present.',
    },
    clinicalKeys: {
      tr: [
        'Dehidratasyon derecesini değerlendirin: Mukozal kuruluk, turgor-tonus azalması, ortostatik hipotansiyon, kapiller dolum zamanı, idrar miktarı.',
        'Kanlı-mukuslu dışkılama, yüksek ateş (>38.5°C) ve tenesmus varsa bakteriyel invaziv AGE (Shigella, Salmonella, Campylobacter) veya E. histolytica düşünün.',
        'Anti-motilite ilaçları (Loperamid vb.) kanlı ishal ve bakteriyel toksin şüphesinde KESİNLİKLE KONTRENDİKEDİR (Toksik megakolon riski!).',
      ],
      en: [
        'Assess dehydration: Dry mucus membranes, skin turgor, orthostatic hypotension, delayed capillary refill, oliguria.',
        'Bloody/mucoid stools, high fever, and tenesmus indicate invasive bacterial gastroenteritis or amebiasis.',
        'Anti-motility drugs (Loperamide) are STRICTLY CONTRAINDICATED in bloody diarrhea / bacterial colitis due to toxic megacolon risk.',
      ],
    },
    redFlagsForConsultation: {
      tr: [
        'Ağır hemodinamik şok ve bilinç bulanıklığı',
        'Akut batın bulguları (Defans, rebound, tahta karın) -> Apandisit/İskemik Kolit ayrımı!',
        'Akut böbrek hasarı (Belirgin üre/kreatinin artışı ve oligüri/anüri)',
        'Düzeltilemeyen ağır hipokalemi / metabolik asidoz',
      ],
      en: [
        'Severe hypovolemic shock / altered mental status',
        'Peritoneal signs (defend, rebound tenderness) -> rule out acute surgical abdomen / ischemic colitis',
        'Acute kidney injury (marked azotemia / oliguria)',
        'Refractory electrolyte collapse / severe metabolic acidosis',
      ],
    },
    erOrder: {
      ivAccess: true,
      fluids: {
        tr: '1000 cc %0.9 İzotonik SF veya Dengeli Elektrolit Solüsyonu (Isolyte-S) IV serbest damla / 1-2 saatte hızlı hidrasyon.',
        en: '1000 cc Normal Saline 0.9% or Balanced Crystalloid (Isolyte-S) IV rapid infusion over 1-2 hours.',
      },
      medications: {
        tr: [
          'Zofran 4-8 mg IV yavaş puşe (Bulantıyı kesip oral alımı başlatmak için ilk tercih) VEYA Metpamid 10 mg IV (100 cc SF içinde).',
          'Spazmodik kramplar için: Buscopan 20 mg IV yavaş (100 cc SF içinde).',
          'Gereğinde: Pantpas 40 mg IV puşe.',
        ],
        en: [
          'Ondansetron 4-8 mg slow IV push (1st choice to facilitate oral rehydration) OR Metoclopramide 10 mg IV.',
          'For cramping colic: Hyoscine Butylbromide 20 mg IV slow push in 100 cc NS.',
          'Pantoprazole 40 mg IV push as needed.',
        ],
      },
      monitoring: {
        tr: 'Serum elektrolitleri (Na, K, Cl), Böbrek Fonksiyon Testleri (Üre, Kreatinin), Hemogram ve Tit takibi.',
        en: 'Check Serum Electrolytes (Na, K, Cl), BUN/Creatinine, CBC, and Urinalysis.',
      },
    },
    outpatientPrescription: {
      diagnosisCode: 'A09 - Enfeksiyöz Kökenli Olduğu Tahmin Edilen İshal ve Gastroenterit',
      diagnosisName: {
        tr: 'Akut Gastroenterit Standart Taburculuk Reçetesi',
        en: 'Acute Gastroenteritis Outpatient Prescription',
      },
      items: [
        {
          drugName: 'REFLLOR 250 mg 10 Kapsül / Saşe',
          activeIngredient: 'Saccharomyces boulardii (Probiyotik)',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 2 x 1 (Sabah-akşam yemekle birlikte 5-7 gün)',
            en: 'S: 2 x 1 with meals for 5-7 days',
          },
          notes: {
            tr: 'Barsak florasını hızla toparlar ve ishal süresini kısaltır.',
            en: 'Restores gut microbiome and shortens diarrheal duration.',
          },
        },
        {
          drugName: 'METPAMID 10 mg 30 Tablet',
          activeIngredient: 'Metoklopramid 10 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 3 x 1 (Yemeklerden 30 dakika önce aç karnına, bulantı oldukça)',
            en: 'S: 3 x 1 30 min before meals PRN for nausea',
          },
        },
        {
          drugName: 'BUSCOPAN PLUS 20 Film Tablet',
          activeIngredient: 'Hiyosin-N-butilbromür 10 mg + Parasetamol 500 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 3 x 1 (Karın krampları ve ateş/ağrı oldukça tok karnına)',
            en: 'S: 3 x 1 PRN for abdominal cramps and pain',
          },
        },
        {
          drugName: 'CIPRO 500 mg 14 Film Tablet *(YALNIZCA KANLI/BAKTERİYEL İSHALDE)*',
          activeIngredient: 'Siprofloksasin 500 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 2 x 1 (12 saatte bir tok karnına 5 gün) - Sadece kanlı mukuslu dışkıda!',
            en: 'S: 2 x 1 every 12 hours for 5 days - ONLY if bloody/bacterial dysentery!',
          },
          notes: {
            tr: 'Amip şüphesinde (kanlı-mukuslu taze dışkı) yerine: BITERAL 500 mg 10 Tablet (Ornidazol) 2x1 5 gün.',
            en: 'If Amebiasis suspected: Ornidazole 500 mg (Biteral) 2x1 for 5 days.',
          },
        },
      ],
      nonPharmacologicalAdvice: {
        tr: [
          'BRAT Diyeti: Muz (Banana), Pirinç lapası (Rice), Elma püresi (Applesauce), Kızarmış ekmek / Etimek (Toast).',
          'Yoğurt, ayran, patates haşlaması, haşlanmış yağsız tavuk tüketimi.',
          'Yağlı, kızartma, baharatlı, süt ve gazlı içeceklerden kesinlikle kaçınma.',
          'Oral Rehidrasyon Sıvısı (ORS) veya her dışkılama sonrası 1 bardak mineralli su/ayran içilmesi.',
        ],
        en: [
          'BRAT Diet (Bananas, Rice, Applesauce, Toast).',
          'Consume boiled potatoes, lean boiled chicken, salted yogurt drinks (Ayran).',
          'Strictly avoid fatty, spicy foods, dairy milk, and sodas.',
          'Oral rehydration therapy after each loose stool.',
        ],
      },
    },
    returnToERCriteria: {
      tr: [
        'Ağızdan hiçbir sıvı alamama ve sürekli kusma',
        'Dışkıda belirgin taze kan ve katran rengi dışkı görülmesi',
        'Göz kararması, ayakta duramama, bayılma hissi (ortostatik senkop)',
        '24 saattir idrara çıkamama',
      ],
      en: [
        'Complete inability to tolerate oral liquids with persistent emesis',
        'Overt bloody stools or black tarry stools',
        'Dizziness, syncope, inability to stand upright',
        'Anuria or no urination for >24 hours',
      ],
    },
  },
  {
    id: 'renal_colic',
    title: {
      tr: 'Renal Kolik & Ürolitiyazis (Böbrek Taşı Ağrısı)',
      en: 'Renal Colic & Urolithiasis (Kidney Stone Pain)',
    },
    category: {
      tr: 'Ürolojik Aciller',
      en: 'Urological Emergencies',
    },
    triageColor: 'yellow',
    summary: {
      tr: 'Acilin en ızdıraplı ağrılarından biridir. Üreterde taş obstrüksiyonu sonucu lümen içi basınç artışı ve prostaglandin salınımı ile tetiklenir. Tipik olarak ani başlayan, kasığa/genital bölgeye vuran dalgalı (kolik) yan ağrısı, bulantı-kusma ve hematüri ile karakterizedir. 1. basamak analjezi tercihi NSAİİ\'lerdir (Deksketoprofen/Diklofenak; prostaglandin sentezini baskılayarak üreter içi basıncı doğrudan düşürür).',
      en: 'Excruciating colicky flank pain radiating to groin/genitalia caused by ureteral obstruction. NSAIDs (Dexketoprofen/Diclofenac) are the 1st line analgesics because they inhibit renal prostaglandin synthesis, reducing renal blood flow and intraluminal pressure.',
    },
    clinicalKeys: {
      tr: [
        'Kostovertebral açı hassasiyeti (KVAH - Giordano pozitifliği) tipiktir.',
        'Hastalar ağrı nedeniyle yerinde duramaz, sürekli kıvranır (Peritonit hastasının aksine hareketsiz kalamazlar!).',
        'İdrar tetkikinde (TİT) mikroskopik veya makroskopik hematüri (%85-90) izlenir.',
        'ATEŞ + RENAL KOLİK = TIKAYICI ÜROSEPSİS ACİLİDİR! Derhal Üroloji konsültasyonu ve acil drenaj (JJ stent / nefrostomi) gerekir!',
      ],
      en: [
        'Costovertebral angle (CVA) tenderness (Giordano sign) is hallmark.',
        'Patients are characteristically restless and unable to find a comfortable position.',
        'Urinalysis reveals micro/gross hematuria in 85-90%.',
        'FEVER + OBSTRUCTING STONE = UROSEPSIS EMERGENCY! Immediate urology consult and urgent decompression (JJ stent/nephrostomy).',
      ],
    },
    redFlagsForConsultation: {
      tr: [
        'Tıkayıcı taş + Ateş / İYE (Ürosepsis riski -> Acil JJ Stent / Nefrostomi)',
        'Tek böbrekli hastada tıkanıklık veya bilateral taş tıkanıklığı (Anüri ve akut böbrek hasarı)',
        'Maksimal medikal tedaviye (IV NSAİİ + Opioid) rağmen dindirilemeyen inatçı ağrı',
        'Büyük taş (>7-10 mm; kendiliğinden düşme olasılığı çok düşüktür)',
      ],
      en: [
        'Obstructing stone with fever/pyuria (Urosepsis danger -> Emergency decompression)',
        'Obstructing stone in a solitary kidney or bilateral obstruction (anuria/AKI)',
        'Intractable pain refractory to multimodal IV NSAIDs and Opioids',
        'Large stone (>7-10 mm; very low spontaneous passage rate)',
      ],
    },
    erOrder: {
      ivAccess: true,
      fluids: {
        tr: '500-1000 cc %0.9 SF IV infüzyon.',
        en: '500-1000 cc 0.9% Normal Saline IV infusion.',
      },
      medications: {
        tr: [
          '1. Basamak Analjezik: ARVELES 50 mg ampul (100 cc SF içinde 15 dk infüzyon) VEYA DİKLORON 75 mg IM.',
          'Spazmolitik: BUSCOPAN 20 mg ampul IV yavaş.',
          'Bulantı eşlik ediyorsa: ZOFRAN 4-8 mg IV puşe veya METPAMİD 10 mg IV.',
          'Dirençli şiddetli ağrıda 2. Basamak: TRAMAL 50-100 mg IV (100 cc SF içinde 20-30 dk infüzyon) veya ALDOLAN 50 mg IM/IV.',
        ],
        en: [
          '1st-line Analgesic: Dexketoprofen 50 mg IV in 100 cc NS over 15 min OR Diclofenac 75 mg IM.',
          'Spasmolytic: Hyoscine Butylbromide 20 mg slow IV.',
          'Antiemetic: Ondansetron 4-8 mg IV or Metoclopramide 10 mg IV.',
          '2nd-line for refractory pain: Tramadol 50-100 mg IV in 100 cc NS over 30 min.',
        ],
      },
      monitoring: {
        tr: 'Böbrek Fonksiyon Testleri (Üre, Kreatinin), Hemogram, TİT ve Üriner Sistem USG veya Kontrastsız Düşük Doz Taş BT protokolü.',
        en: 'Check BUN/Cr, CBC, Urinalysis, and Renal USG or Non-contrast Stone CT protocol.',
      },
    },
    outpatientPrescription: {
      diagnosisCode: 'N20.1 - Üreter Taşı',
      diagnosisName: {
        tr: 'Renal Kolik & Taş Düşürme Taburculuk Reçetesi (MET Protokolü)',
        en: 'Renal Colic Outpatient Discharge Prescription (Medical Expulsive Therapy)',
      },
      items: [
        {
          drugName: 'ARVELES 25 mg 20 Film Tablet',
          activeIngredient: 'Deksketoprofen Trometamol 25 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 2 x 1 veya 3 x 1 (Ağrı oldukça tok karnına)',
            en: 'S: 2 x 1 or 3 x 1 with food PRN pain',
          },
        },
        {
          drugName: 'FLOMAX MR 0.4 mg 30 Kapsül (veya TAMPROST / TAMSULOSİN)',
          activeIngredient: 'Tamsulosin Hidroklorür 0.4 mg (Alfa Bloker)',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 1 x 1 (Günde 1 kez akşam yatmadan önce tok karnına) - Medikal ekspulsif tedavi (Taş düşürmeyi kolaylaştırır)',
            en: 'S: 1 x 1 at bedtime (Medical Expulsive Therapy - relaxes distal ureter)',
          },
          notes: {
            tr: 'Distal üreter düz kaslarını gevşeterek taşın düşmesini belirgin hızlandırır ve ağrı krizlerini azaltır.',
            en: 'Relaxes ureteral smooth muscle, accelerating stone passage and decreasing colic episodes.',
          },
        },
        {
          drugName: 'BUSCOPAN PLUS 20 Film Tablet',
          activeIngredient: 'Hiyosin-N-butilbromür 10 mg + Parasetamol 500 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 3 x 1 (Spazm ve ağrı oldukça tok karnına)',
            en: 'S: 3 x 1 PRN for spasms',
          },
        },
        {
          drugName: 'PANTPAS 40 mg 28 Enterik Tablet',
          activeIngredient: 'Pantoprazol 40 mg (Mide Koruyucu)',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 1 x 1 (Sabah aç karnına)',
            en: 'S: 1 x 1 once daily before breakfast',
          },
        },
      ],
      nonPharmacologicalAdvice: {
        tr: [
          'Günde en az 2.5 - 3 litre bol su tüketilmesi (Ağrı atağı yatıştıktan sonra).',
          'İdrarın süzülmesi (Taş düştüğünde yakalanıp analiz için saklanması).',
          'Hafif yürüyüş ve merdiven inip çıkma hareketleri.',
          'Üroloji poliklinik kontrolü (1-2 hafta içinde).',
        ],
        en: [
          'Drink 2.5 - 3 liters of water daily once acute colic subsides.',
          'Strain urine to catch and analyze passed stone fragments.',
          'Moderate physical activity/walking.',
          'Follow up with Urology clinic in 1-2 weeks.',
        ],
      },
    },
    returnToERCriteria: {
      tr: [
        'Ateş yüksekliği (>38°C) ve titreme başlarsa (Acil ürosepsis şüphesi!)',
        'İdrar yapamama veya idrar miktarında belirgin azalma',
        'Evdeki ağrı kesicilerle dindirilemeyen şiddetli ağrı krizi',
        'Sürekli kusma ve ağızdan ilaç alamama',
      ],
      en: [
        'Fever (>38°C) or chills (Urosepsis warning!)',
        'Inability to pass urine (acute urinary retention)',
        'Unbearable pain refractory to oral analgesics',
        'Intractable vomiting',
      ],
    },
  },
  {
    id: 'acute_cystitis',
    title: {
      tr: 'Akut Basit Sistit (İdrar Yolu Enfeksiyonu)',
      en: 'Acute Uncomplicated Cystitis (UTI)',
    },
    category: {
      tr: 'Ürolojik Enfeksiyonlar',
      en: 'Urological Infections',
    },
    triageColor: 'green',
    summary: {
      tr: 'Özellikle kadınlarda çok sık görülen alt üriner sistem enfeksiyonudur. En sık etken %80-85 oranında E. coli\'dir. Dizüri (idrar yaparken yanma), pollaküri (sık idrara çıkma), sıkışma hissi (urgency) ve suprapubik hassasiyet ile seyreder. Ateş ve yan ağrısı OLMAMALIDIR (varsa piyelonefrit kabul edilir).',
      en: 'Common lower urinary tract infection primarily in women, 80-85% caused by E. coli. Characterized by dysuria, frequency, urgency, and suprapubik discomfort. Fever and flank pain must be ABSENT (otherwise classified as acute pyelonephritis).',
    },
    clinicalKeys: {
      tr: [
        'İdrar stik testinde Lökosit Esteraz (+) ve Nitrit (+) olması tanıyı destekler.',
        'Hastaya mutlaka kostovertebral açı hassasiyeti (KVAH) muayenesi yapın (Piyelonefriti dışlamak için).',
        'Gebelikte asemptomatik bakteriüri bile olsa mutlaka tedavi edilmelidir (Erken doğum ve piyelonefrit riski!).',
      ],
      en: [
        'Positive leukocyte esterase and nitrite on dipstick support diagnosis.',
        'Always check for CVA tenderness to rule out upper tract involvement.',
        'Asymptomatic bacteriuria in pregnancy MUST be treated to prevent preterm labor and pyelonephritis.',
      ],
    },
    redFlagsForConsultation: {
      tr: [
        'Ateş (>38°C), titreme, bulantı/kusma, yan ağrısı -> PİYELONEFRİT DÜŞÜNÜN (Yatış / IV Seftriakson gereksinimi).',
        'Erkek hastada sistit semptomları (Prostatit, üretral darlık veya taş obstrüksiyonu araştırılmalıdır).',
        'Dirençli hematüri ve pelvik kitle şüphesi.',
      ],
      en: [
        'Fever, rigors, flank pain, nausea -> Treat as ACUTE PYELONEPHRITIS (IV Ceftriaxone/admission).',
        'Cystitis in males (always considered complicated; investigate prostatitis/calculus).',
        'Gross persistent hematuria or bladder mass suspicion.',
      ],
    },
    erOrder: {
      ivAccess: false,
      medications: {
        tr: [
          'Şiddetli dizüri ve spazmda: Parol 1000 mg IV veya Buscopan Plus 1 tb PO.',
        ],
        en: [
          'For severe dysuria/spasm in ER: Paracetamol 1000 mg IV or Hyoscine/Paracetamol 1 tab PO.',
        ],
      },
    },
    outpatientPrescription: {
      diagnosisCode: 'N30.0 - Akut Sistit',
      diagnosisName: {
        tr: 'Akut Komplike Olmayan Sistit Reçetesi (Tek Doz veya Kısa Süreli)',
        en: 'Acute Uncomplicated Cystitis Outpatient Prescription',
      },
      items: [
        {
          drugName: 'MONUROL 3 g 1 Saşe (veya UROMİSİN 3g Saşe)',
          activeIngredient: 'Fosfomisin Trometamol 3 g',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 1 x 1 (TEK DOZ: Gece yatmadan önce mesane boşaltıldıktan sonra 1 bardak suda eritilerek içilecek)',
            en: 'S: 1 x 1 (SINGLE DOSE: Dissolve in 1 glass of water at bedtime after voiding)',
          },
          notes: {
            tr: 'Alternatif seçenek (Örn: Piyeloseptyl 50 mg Kapsül 4x1 5 gün veya Biteral 500 mg).',
            en: 'Alternative: Nitrofurantoin (Piyeloseptyl) 100 mg BID for 5 days.',
          },
        },
        {
          drugName: 'PIYELOSEPTYL 100 mg 30 Kapsül *(Fosfomisin yerine alternatif)*',
          activeIngredient: 'Nitrofurantoin 100 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 2 x 1 (12 saatte bir yemekle birlikte 5 gün)',
            en: 'S: 2 x 1 with meals for 5 days',
          },
        },
        {
          drugName: 'BUSCOPAN PLUS 20 Film Tablet',
          activeIngredient: 'Hiyosin-N-butilbromür + Parasetamol',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 3 x 1 (Mesane spazmı ve yanma için 3 gün)',
            en: 'S: 3 x 1 for bladder spasms for 3 days',
          },
        },
      ],
      nonPharmacologicalAdvice: {
        tr: [
          'Günde en az 2.5 - 3 litre bol su tüketimi.',
          'İdrarı ertelememek ve mesaneyi tam boşaltmak.',
          'Genital bölge temizliğini önden arkaya doğru yapmak.',
          'Pamuklu iç çamaşırı giyilmesi.',
        ],
        en: [
          'Drink at least 2.5-3 liters of water daily.',
          'Void frequently and do not hold urine.',
          'Wipe from front to back.',
          'Wear breathable cotton underwear.',
        ],
      },
    },
    returnToERCriteria: {
      tr: [
        'Ateş yükselmesi veya şiddetli bel/yan ağrısı gelişmesi',
        'İdrardan belirgin pıhtılı kan gelmesi',
        'Tedaviye rağmen 3 günde semptomların hiç gerilememesi',
      ],
      en: [
        'Development of fever, chills, or flank pain',
        'Gross hematuria with clots',
        'No symptom relief after 3 days of therapy',
      ],
    },
  },
  {
    id: 'acute_lumbago',
    title: {
      tr: 'Akut Lomber Ağrı & Kas Spazmı (Lumbago / Bel Tutulması)',
      en: 'Acute Low Back Pain & Muscle Spasm (Lumbago)',
    },
    category: {
      tr: 'Kas İskelet Sistemi Acilleri',
      en: 'Musculoskeletal Emergencies',
    },
    triageColor: 'green',
    summary: {
      tr: 'Acil servise bel ağrısı ile başvuran hastaların %90\'dan fazlası mekanik/musküloskeletal kökenlidir (ağır kaldırma, ani hareket, paraspinal kas spazmı). İntörn hekimin acildeki 1 numaralı görevi KIRMIZI BAYRAKLARI (Kauda Ekuina Sendromu, Spinal Epidural Apse/Hematom, Malignite metastazı, Vertebra Kırığı, Abdominal Aort Anevrizması) dışlamaktır.',
      en: '>90% of ER low back pain is mechanical or muscular. The intern doctor\'s primary duty is to rule out RED FLAGS: Cauda Equina Syndrome, Spinal Epidural Abscess/Hematoma, Malignancy metastasis, Vertebral Fracture, and Abdominal Aortic Aneurysm (AAA).',
    },
    clinicalKeys: {
      tr: [
        'Kauda Ekuina Kırmızı Bayrakları: Eyer tarzı anestezi (perineal uyuşma), yeni gelişen idrar/gaita inkontinansı veya retansiyonu, progresif bilateral bacak güçsüzlüğü -> ACİL BEYİN CERRAHİSİ / MRG!',
        'Düz Bacak Kaldırma (Lasegue) Testi: Bacak 30-70 derece kaldırıldığında diz altına yayılan radiküler elektriklenme/ağrı disk hernisini (L4-L5 / L5-S1) düşündürür.',
        'Yatak istirahati önerilmez! Hastaya tolere edebildiği ölçüde aktif kalması ve günlük hareketlerine devam etmesi söylenmelidir.',
      ],
      en: [
        'Cauda Equina Red Flags: Saddle anesthesia, new urinary/bowel incontinence or urinary retention, progressive bilateral leg weakness -> Emergency MRI / Neurosurgery!',
        'Straight Leg Raise (SLR / Lasegue): Radicular pain radiating below knee at 30-70° indicates disc herniation.',
        'Prolonged bed rest is HARMFUL. Advise early mobilization and gentle activity as tolerated.',
      ],
    },
    redFlagsForConsultation: {
      tr: [
        'Kauda Ekuina Sendromu şüphesi (Sfinkter kusuru, eyer anestezi)',
        'Akut motor kayıp (Düşük ayak, başparmak ekstansiyonunda güçsüzlük <3/5)',
        'Ateş + Bel ağrısı + IV ilaç kullanımı / İmmünsüpresyon (Epidural Apse şüphesi)',
        'Malignite öyküsü olan hastada yeni başlayan inatçı gece ağrısı',
        'Yaşlı hastada yırtılır tarzda bel ağrısı + pulsatif batın kitlesi (Aort Anevrizması / Diseksiyonu)',
      ],
      en: [
        'Suspected Cauda Equina Syndrome (sphincter loss, saddle anesthesia)',
        'Acute motor deficit (Foot drop, motor power <3/5)',
        'Fever + back pain + IV drug use / immunosuppression (Epidural Abscess)',
        'History of malignancy with unremitting nocturnal pain',
        'Tearing back/flank pain in elderly + pulsatile mass (Rupturing AAA)',
      ],
    },
    erOrder: {
      ivAccess: false,
      medications: {
        tr: [
          'Acil Servis İçi Kas Gevşetici + NSAİİ Enjeksiyonu:\nDİKLORON 75 mg IM (1 ampul) + MUSCORIL 4 mg IM (Tiyokolşikozid 1 ampul) ayrı enjektörlerde derin gluteal IM VEYA ARVELES 50 mg IV infüzyon.',
        ],
        en: [
          'ER Analgesic + Muscle Relaxant Protocol:\nDiclofenac 75 mg IM + Thiocolchicoside 4 mg IM (separate syringes) OR Dexketoprofen 50 mg IV infusion.',
        ],
      },
    },
    outpatientPrescription: {
      diagnosisCode: 'M54.5 - Bel Ağrısı (Lumbago)',
      diagnosisName: {
        tr: 'Akut Lumbago & Kas Spazmı Standart Reçetesi',
        en: 'Acute Mechanical Lumbago Outpatient Prescription',
      },
      items: [
        {
          drugName: 'ARVELES 25 mg 20 Film Tablet (veya DİKLORON 50 mg)',
          activeIngredient: 'Deksketoprofen Trometamol 25 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 2 x 1 (Sabah-akşam tok karnına 5-7 gün)',
            en: 'S: 2 x 1 with meals for 5-7 days',
          },
        },
        {
          drugName: 'MUSCORIL 8 mg 14 Kapsül (veya TİYOZİT / TİYO-RELAX)',
          activeIngredient: 'Tiyokolşikozid 8 mg (Kas Gevşetici)',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 2 x 1 (12 saatte bir tok karnına maksimum 7 gün)',
            en: 'S: 2 x 1 with meals (Max 7 days)',
          },
          notes: {
            tr: 'Tiyokolşikozid anöploidi riski nedeniyle maksimum 7 gün kullanılmalıdır.',
            en: 'Limit thiocolchicoside use to max 7 days.',
          },
        },
        {
          drugName: 'VOLTAREN EMULGEX %1 Jel 50 g (veya DİCLOMEC Jel)',
          activeIngredient: 'Diklofenak Dietilamonyum',
          boxCount: 'DİB: 1 (Bir) Tüp',
          dosageInstructions: {
            tr: 'S: 3 x 1 (Bel bölgesine hafifçe masaj yaparak sürülür)',
            en: 'S: 3 x 1 apply topically to lumbar region with gentle massage',
          },
        },
        {
          drugName: 'PANTPAS 40 mg 28 Tablet',
          activeIngredient: 'Pantoprazol 40 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 1 x 1 (Sabah aç karnına)',
            en: 'S: 1 x 1 once daily before breakfast',
          },
        },
      ],
      nonPharmacologicalAdvice: {
        tr: [
          'Ağrılı bölgeye ilk 48 saatten sonra günde 3 kez 15-20 dakika sıcak uygulama (sıcak su torbası/havlu).',
          'Uzun süreli yatak istirahatinden kaçınılmalı, hafif yürüyüşler yapılmalıdır.',
          'Yerden bir şey alırken beli bükmeden dizleri kırarak çömelme kuralı.',
          'Ağır yük kaldırmaktan kaçınma.',
        ],
        en: [
          'Apply local heat packs 15-20 min 3 times daily after first 48 hours.',
          'Avoid bed rest; maintain gentle walking and activities.',
          'Proper lifting ergonomics (bend knees, keep load close to body).',
          'Avoid heavy lifting.',
        ],
      },
    },
    returnToERCriteria: {
      tr: [
        'Bacaklarda aniden ilerleyen his kaybı veya güçsüzlük (düşük ayak)',
        'İdrar kaçırma veya idrar yapamama (mesaneyi hissedememe)',
        'Makat çevresinde ve cinsel organda hissizlik (eyer tarzı anestezi)',
        'Ateş ve bacaklara vuran şiddetli gece ağrısı',
      ],
      en: [
        'Sudden progressive leg weakness or foot drop',
        'Loss of bowel/bladder control or urinary retention',
        'Numbness around groin/perineum (saddle anesthesia)',
        'Fever with intractable nocturnal back pain',
      ],
    },
  },
  {
    id: 'acute_migraine_headache',
    title: {
      tr: 'Akut Migren & Gerilim Tipi Baş Ağrısı',
      en: 'Acute Migraine & Tension-Type Headache',
    },
    category: {
      tr: 'Nörolojik Aciller',
      en: 'Neurological Emergencies',
    },
    triageColor: 'yellow',
    summary: {
      tr: 'Acile baş ağrısı ile gelen her hastada birincil amaç SAK (Subaraknoid Kanama), Menenjit, İntrakraniyal Kitle ve Temporal Arterit gibi sekonder ölümcül nedenleri dışlamaktır. Migren tipik olarak tek taraflı, zonklayıcı, fotofobi/fonofobi ve bulantı ile seyreden orta-şiddetli ağrıdır. Acilde opioidlerden (bağımlılık ve rebound ağrı riski nedeniyle) KESİNLİKLE KAÇINILMALIDIR.',
      en: 'Primary goal is excluding secondary life-threatening headaches (SAH, Meningitis, Mass, Temporal Arteritis). Migraine is typically unilateral, pulsating, moderate-severe pain with nausea, photophobia, and phonophobia. STRICTLY AVOID OPIOIDS in ER migraine due to medication-overuse headache and lack of efficacy.',
    },
    clinicalKeys: {
      tr: [
        'SNOOP10 Kırmızı Bayrakları: Sistemik semptomlar (Ateş), Nörolojik defisit, Onset (Ani şimşek çakar gibi başlayan - Thunderclap), Older (>50 yaş yeni ağrı), Pattern change (Karakter değişimi).',
        'Acil Migren Kokteyli (ER Migraine Cocktail): IV Mayi + NSAİİ (Arveles) + Dopamin Antagonisti Antiemetik (Metpamid) + Steroid (Dekort/Prednol).',
        'Metpamid (Metoklopramid) hem bulantıyı keser, hem dopaminerjik nöromülatör olarak migren ağrısını doğrudan dindirir.',
      ],
      en: [
        'SNOOP10 Red Flags: Systemic signs/fever, Neurological deficits, Onset sudden (Thunderclap), Older (>50 yrs), Pattern change.',
        'ER Migraine Cocktail: IV Hydration + IV NSAID (Dexketoprofen) + IV Dopamine antagonist (Metoclopramide) + IV Corticosteroid (Dexamethasone/Prednisolone).',
        'Metoclopramide treats nausea and aborts migraine pain via central dopamine receptor antagonism.',
      ],
    },
    redFlagsForConsultation: {
      tr: [
        'Şimşek çakar gibi saniyeler içinde pik yapan en şiddetli baş ağrısı (Thunderclap Headache) -> ACİL BEYİN BT ve SAK DIŞLAMA!',
        'Ense sertliği, ateş ve mental konfüzyon (Menenjit şüphesi -> Acil LP / Seftriakson)',
        'Fokal nörolojik defisit (asimetrik pupil, parezi, konuşma bozukluğu)',
        '>50 yaş hastada şakak bölgesinde hassasiyet ve görme kaybı (Temporal Arterit)',
      ],
      en: [
        'Thunderclap headache peaking within 1 minute -> EMERGENCY NON-CONTRAST HEAD CT to rule out Subarachnoid Hemorrhage (SAH)!',
        'Meningismus, fever, altered mental status (Meningitis suspicion -> urgent LP/antibiotics)',
        'Focal neurological deficits',
        'Temporal scalp tenderness and vision changes in >50 years (Temporal Arteritis)',
      ],
    },
    erOrder: {
      ivAccess: true,
      fluids: {
        tr: '500-1000 cc %0.9 İzotonik SF IV infüzyon (Karanlık ve sessiz odaya alınır).',
        en: '500-1000 cc Normal Saline 0.9% IV in a dark, quiet room.',
      },
      medications: {
        tr: [
          '1. ARVELES 50 mg IV (100 cc SF içinde 15 dk) VEYA PAROL 1000 mg IV.',
          '2. METPAMİD 10 mg IV (100 cc SF içinde 15 dk) - Hızlı puşe yapmayın.',
          '3. DEKORT 8 mg (Deksametazon) IV yavaş puşe (Ağrının nüksetmesini / rebound atağı önler).',
          'Dirençli krizde 2. basamak: MAGNEZYUM SÜLFAT 1-2 g IV (100 cc SF içinde 20 dk) veya Klorpromazin.',
        ],
        en: [
          '1. Dexketoprofen 50 mg IV in 100 cc NS OR Paracetamol 1000 mg IV.',
          '2. Metoclopramide 10 mg IV in 100 cc NS.',
          '3. Dexamethasone 8 mg (Dekort) IV push (prevents headache recurrence).',
          '2nd line for refractory status migrainosus: Magnesium Sulfate 1-2 g IV in 100 cc NS over 20 min.',
        ],
      },
    },
    outpatientPrescription: {
      diagnosisCode: 'G43.9 - Migren, Tanımlanmamış',
      diagnosisName: {
        tr: 'Akut Migren Kriz ve Taburculuk Reçetesi',
        en: 'Acute Migraine Outpatient Prescription',
      },
      items: [
        {
          drugName: 'RELPAX 40 mg 6 Film Tablet (veya ZOMIG 2.5 mg / ELETRİPTAN)',
          activeIngredient: 'Eletriptan 40 mg (Triptan / 5-HT1B/1D Agonisti)',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 1 x 1 (Ağrı başlar başlamaz 1 tablet alınır. 2 saat sonra geçmezse 2. tablet alınabilir. 24 saatte maksimum 2 tablet!)',
            en: 'S: 1 x 1 at immediate onset of migraine. May repeat once after 2h if needed (Max 2 tabs/24h).',
          },
          notes: {
            tr: 'Koroner arter hastalığı, kontrolsüz hipertansiyon ve serebrovasküler hastalıkta triptanlar KONTRENDİKEDİR!',
            en: 'Contraindicated in coronary artery disease, uncontrolled hypertension, and prior stroke.',
          },
        },
        {
          drugName: 'ARVELES 25 mg 20 Film Tablet',
          activeIngredient: 'Deksketoprofen Trometamol 25 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 2 x 1 (Ağrı atağında tok karnına)',
            en: 'S: 2 x 1 with food during attack',
          },
        },
        {
          drugName: 'METPAMID 10 mg 30 Tablet',
          activeIngredient: 'Metoklopramid 10 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 1 x 1 (Ağrı başlangıcında analjez}})\n          }',
            en: 'S: 1 x 1 with acute analgesic to enhance absorption and resolve nausea',
          },
        },
      ],
      nonPharmacologicalAdvice: {
        tr: [
          'Karanlık, sessiz ve serin bir odada dinlenme.',
          'Şakak ve alın bölgesine soğuk kompres uygulanması.',
          'Migren tetikleyicilerinden kaçınma (uykusuzluk, açlık, stres, eski peynir, çikolata, alkol, monosodyum glutamat).',
          'Ayda 3\'ten fazla atak oluyorsa Nöroloji polikliniğinde profilaktik tedavi (Beta-bloker, Topiramat, Flunarizin) başlanması.',
        ],
        en: [
          'Rest in a dark, quiet, cool room.',
          'Cold compress to forehead/temples.',
          'Avoid known dietary and lifestyle triggers (sleep deprivation, hunger, aged cheese, chocolate, alcohol).',
          'Follow up with Neurology for prophylactic therapy if >3 disabling attacks per month.',
        ],
      },
    },
    returnToERCriteria: {
      tr: [
        'Baş ağrısının aniden "hayatımın en şiddetli ağrısı" şeklinde patlaması',
        'Ateş, boyun tutulması, çift görme veya vücudun bir yarısında uyuşma/güçsüzlük eklenmesi',
        'Kusmanın durdurulamaması ve bilinç bulanıklığı',
      ],
      en: [
        'Sudden explosive "worst headache of life"',
        'Development of fever, stiff neck, double vision, or focal numbness/weakness',
        'Intractable vomiting or altered mental status',
      ],
    },
  },
  {
    id: 'acute_urticaria_allergy',
    title: {
      tr: 'Akut Ürtiker & Alerjik Reaksiyon (Kurdeşen)',
      en: 'Acute Urticaria & Allergic Reaction',
    },
    category: {
      tr: 'Dermatolojik & Alerjik Aciller',
      en: 'Dermatological & Allergic Emergencies',
    },
    triageColor: 'yellow',
    summary: {
      tr: 'Deride aniden ortaya çıkan, kaşıntılı, eritemli, basmakla solan ve genellikle 24 saat içinde iz bırakmadan kaybolup başka yerde çıkan ödemli plaklar (plak/papül). İntörn hekimin acildeki EN KRİTİK GÖREVİ: Basit ürtiker ile hayatı tehdit eden ANAFİLAKSİ (Havayolu tutulumu, bronkospazm, hipotansiyon, anjioödem) ayrımını derhal yapmaktır!',
      en: 'Transient pruritic, erythematous, edematous wheals that blanch with pressure and resolve within 24 hours. The intern\'s critical priority is distinguishing simple benign urticaria from life-threatening ANAPHYLAXIS (airway compromise, bronchospasm, hypotension, stridor, anaphylactic shock).',
    },
    clinicalKeys: {
      tr: [
        'ANAFİLAKSİ KRİTERİ: Cilt bulgularına (ürtiker/anjioödem) ek olarak SOLUNUM SIKINTISI (stridor, wheezing, dispne) VEYA HİPOTANSİYON (SAB < 90 mmHg / senkop) VEYA ŞİDDETLİ GİS KRAMP/KUSMA varsa derhal İNTRAMÜSKÜLER ADRENALİN (0.5 mg IM Uyluk) YAPIN!',
        'Steroidler ve antihistaminikler anafilakside İKİNCİLDİR; acil havayolu ve dolaşım çöküşünü YALNIZCA ADRENALİN düzeltir.',
        'Basit ürtikerde 2. kuşak antihistaminikler (Setirizin, Levosetirizin, Desloratadin) ilk tercihtir.',
      ],
      en: [
        'ANAPHYLAXIS CRITERIA: Skin/mucosal involvement PLUS Respiratory distress (stridor/wheezing) OR Hypotension/shock OR Severe GI cramping -> IMMEDIATELY ADMINISTER INTRAMUSCULAR EPINEPHRINE (0.5 mg IM in thigh)!',
        'Steroids and antihistamines are SECOND-LINE adjuncts; only Epinephrine reverses acute airway obstruction and vascular collapse.',
        'For simple urticaria, 2nd-generation H1-antihistamines are 1st line.',
      ],
    },
    redFlagsForConsultation: {
      tr: [
        'Dudak, dil, uvula ve laringeal anjioödem (Ses kısıklığı, yutkunamama, stridor) -> ACİL ADRENALİN + ENTÜBASYON HAZIRLIĞI!',
        'Hipotansiyon (SAB < 90 mmHg) ve taşikardi ile seyreden anafilaktik şok',
        'Bifazik reaksiyon riski nedeniyle anafilaksi geçiren tüm hastalar acilde en az 6-8 saat gözlenmelidir.',
      ],
      en: [
        'Angioedema of tongue/uvula/larynx (stridor, hoarseness, inability to swallow) -> IMMEDIATE IM EPINEPHRINE + AIRWAY READINESS!',
        'Hypotension / Anaphylactic Shock',
        'Observe all anaphylaxis patients in ER for at least 6-8 hours due to risk of biphasic reaction.',
      ],
    },
    erOrder: {
      ivAccess: true,
      fluids: {
        tr: 'Basit ürtikerde gerekmez; anafilakside 1000-2000 cc %0.9 SF hızlı IV yükleme.',
        en: 'Not required in simple urticaria; in anaphylaxis rapid 1000-2000 cc NS bolus.',
      },
      medications: {
        tr: [
          'ANAFİLAKSİ VARSA: ADRENALİN 0.5 mg (0.5 ml 1:1000 ampul) Uyluk anterolateraline DERİN IM (Gerekirse 5-10 dk sonra tekrar).',
          'Acil Servis Standart Ürtiker Protokolü:\n1. AVİL 45.5 mg (1 ampul) IV yavaş puşe\n2. PREDNOL 40-80 mg IV puşe\n3. PANTPAS veya FAMODİN IV (H2 blokajı sinerji sağlar).',
        ],
        en: [
          'IF ANAPHYLAXIS: EPINEPHRINE 0.5 mg IM into anterolateral thigh immediately.',
          'Standard ER Urticaria Protocol:\n1. Pheniramine (Avil) 45.5 mg slow IV\n2. Methylprednisolone (Prednol) 40-80 mg IV\n3. H2 blocker (Famotidine/Pantoprazole) IV for synergy.',
        ],
      },
    },
    outpatientPrescription: {
      diagnosisCode: 'L50.0 - Alerjik Ürtiker',
      diagnosisName: {
        tr: 'Akut Ürtiker & Alerji Taburculuk Reçetesi',
        en: 'Acute Urticaria Outpatient Prescription',
      },
      items: [
        {
          drugName: 'CREBROS 5 mg 20 Film Tablet (veya LEVOMONT / XYZAL / LEVOSETİRİZİN)',
          activeIngredient: 'Levosetirizin Dihidroklorür 5 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 1 x 1 (Günde 1 kez akşam yatmadan önce tok karnına 10 gün)',
            en: 'S: 1 x 1 at bedtime with food for 10 days',
          },
          notes: {
            tr: '2. kuşak antihistaminikler Avil gibi sersemlik ve uyku yapmaz, günlük hayatta çok daha konforludur.',
            en: '2nd-generation antihistamine with minimal sedation.',
          },
        },
        {
          drugName: 'PREDNOL 16 mg 20 Tablet (veya KORTOS / METİLPREDNİZOLON)',
          activeIngredient: 'Metilprednizolon 16 mg',
          boxCount: 'DİB: 1 (Bir) Kutu',
          dosageInstructions: {
            tr: 'S: 1 x 1 (Sabah tok karnına 3 gün, sonra kesilecek - kısa süreli steroid)',
            en: 'S: 1 x 1 with breakfast for 3 days only then stop',
          },
          notes: {
            tr: 'Yaygın ve inatçı ürtikerde 3-5 günlük kısa süreli oral steroid nüksü engeller.',
            en: 'Short 3-5 day oral steroid burst prevents urticarial relapse.',
          },
        },
        {
          drugName: 'STILEZ Jel 30 g (veya FENİSTİL Jel)',
          activeIngredient: 'Mepiramin maleat + Lidokain + Dekspantenol',
          boxCount: 'DİB: 1 (Bir) Tüp',
          dosageInstructions: {
            tr: 'S: 3 x 1 (Kaşıntılı lezyonların üzerine ince tabaka halinde sürülür)',
            en: 'S: 3 x 1 apply topically to itchy skin lesions',
          },
        },
      ],
      nonPharmacologicalAdvice: {
        tr: [
          'Alerjiye neden olabilecek şüpheli yeni ilaç, besin (çilek, deniz ürünü, kuruyemiş), deterjan veya kimyasal temasını kesin.',
          'Ilık duş alınması (Sıcak su histamin salınımını artırıp kaşıntıyı şiddetlendirir!).',
          'Cildi tahriş edecek dar ve sentetik kıyafetlerden kaçınma.',
        ],
        en: [
          'Identify and eliminate triggering culprit (new medication, seafood, nuts, detergent).',
          'Take cool or lukewarm baths (hot water increases histamine release and worsens itching!).',
          'Wear loose, soft cotton clothing.',
        ],
      },
    },
    returnToERCriteria: {
      tr: [
        'Dudaklarda, dilde, boğazda şişme veya ses kısıklığı başlarsa DERHAL 112 / ACİLE BAŞVURUN!',
        'Nefes darlığı, hırıltılı solunum veya göğüste sıkışma hissi',
        'Göz kararması, baş dönmesi veya bayılma hissi',
      ],
      en: [
        'Immediate emergency return if lip/tongue/throat swelling or hoarseness occurs!',
        'Shortness of breath, wheezing, or chest tightness',
        'Dizziness, lightheadedness, or syncope',
      ],
    },
  },
];
