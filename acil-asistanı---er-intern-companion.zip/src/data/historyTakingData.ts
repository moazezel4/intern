import { ClinicalHistoryProtocol } from '../types';

export const CLINICAL_HISTORY_PROTOCOLS: ClinicalHistoryProtocol[] = [
  {
    id: 'pulmonary_embolism',
    condition: {
      tr: 'Pulmoner Emboli (PE) - Akciğere Pıhtı Atması',
      en: 'Pulmonary Embolism (PE)',
    },
    chiefComplaint: {
      tr: 'Ani Başlayan Nefes Darlığı, Plöritik Göğüs Ağrısı, Senkop veya Hemoptizi',
      en: 'Sudden Onset Dyspnea, Pleuritic Chest Pain, Syncope or Hemoptysis',
    },
    triagePriority: 'red',
    overview: {
      tr: 'Pulmoner Emboli (PE), acilde atlanması durumunda mortalitesi %30\'lara varan hayatı tehdit edici kardiyovasküler bir acildir. Çoğunlukla alt ekstremite derin ven trombozundan (DVT) köken alır. Klinik semptomlar çok silik olabileceğinden yüksek şüphe indeksi, risk faktörlerinin sorgulanması ve Wells / PERC skorlaması hayati önem taşır.',
      en: 'Pulmonary Embolism is a life-threatening emergency with high untreated mortality. Most cases originate from lower extremity DVT. Symptoms can range from mild dyspnea to sudden cardiac arrest. Clinical scoring (Wells/PERC) and targeted history taking are vital.',
    },
    mustAskQuestions: [
      {
        id: 'pe_onset',
        question: {
          tr: 'Nefes darlığı veya göğüs ağrısı ne zaman ve nasıl başladı?',
          en: 'When and how did the shortness of breath or chest pain start?',
        },
        patientFriendlyPhraseTR: '"Nefes darlığınız veya ağrınız aniden mi başladı, yoksa günlerdir yavaş yavaş mı artıyordu?"',
        rationale: {
          tr: 'PE\'de semptomlar tipik olarak saniyeler veya dakikalar içinde ANİDEN başlar.',
          en: 'PE typically presents with abrupt, sudden-onset symptoms.',
        },
        isRedFlagAlert: true,
      },
      {
        id: 'pe_pleuritic_pain',
        question: {
          tr: 'Göğüs ağrısı nefes alıp verirken veya öksürürken batıyor mu?',
          en: 'Does the chest pain worsen with deep inspiration or coughing?',
        },
        patientFriendlyPhraseTR: '"Derin bir nefes aldığınızda veya öksürdüğünüzde göğsünüzün yan tarafında bıçak saplanır gibi batma hissediyor musunuz?"',
        rationale: {
          tr: 'Distal pulmoner embolilerde plevral irritasyona bağlı plöritik (batıcı) göğüs ağrısı görülür.',
          en: 'Peripheral emboli induce pleuritic inflammation causing sharp inspiratory pain.',
        },
        isRedFlagAlert: false,
      },
      {
        id: 'pe_surgery_immobilization',
        question: {
          tr: 'Son 4 hafta içinde ameliyat oldunuz mu veya uzun süre yatakta kaldınız mı?',
          en: 'Have you had surgery or been bedridden in the last 4 weeks?',
        },
        patientFriendlyPhraseTR: '"Son 1 ay içinde herhangi bir ameliyat geçirdiniz mi? Veya alçı, kırık, hastalık yüzünden 3 günden uzun süre yataktan kalkamadığınız oldu mu?"',
        rationale: {
          tr: 'Wells Skoru: Son 4 haftada cerrahi veya immobilizasyon (+1.5 puan). Venöz staz en büyük tetikleyicidir.',
          en: 'Wells Criterion: Surgery or bed rest in last 4 weeks (+1.5 pts). Venous stasis is a major trigger.',
        },
        isRedFlagAlert: true,
        scoreContribution: {
          scoreName: 'Wells PE',
          points: 1.5,
        },
      },
      {
        id: 'pe_travel',
        question: {
          tr: 'Son 4 hafta içinde uzun süreli yolculuk yaptınız mı?',
          en: 'Have you taken a long-distance trip in the last 4 weeks?',
        },
        patientFriendlyPhraseTR: '"Son 4 haftada 4 saatten uzun süren uçak, otobüs veya araba yolculuğu yaptınız mı?"',
        rationale: {
          tr: 'Ekonomi sınıfı sendromu: Uzun süreli oturma alt ekstremitede venöz staz ve pıhtı oluşumunu tetikler.',
          en: 'Long-haul travel (>4 hours) causes lower limb venous stasis and thrombosis.',
        },
        isRedFlagAlert: false,
      },
      {
        id: 'pe_dvt_signs',
        question: {
          tr: 'Bacaklarınızdan birinde şişlik, ağrı, sıcaklık artışı veya baldırda sertlik var mı?',
          en: 'Do you have swelling, pain, or warmth in one of your legs?',
        },
        patientFriendlyPhraseTR: '"Bacaklarınızdan birinde diğerine göre belirgin bir şişme, baldırınızda dokununca ağrı veya sertlik fark ettiniz mi?"',
        rationale: {
          tr: 'Wells Skoru: DVT klinik bulgusu ve semptomu (+3.0 puan). En yüksek risk faktörüdür.',
          en: 'Wells Criterion: Clinical signs/symptoms of DVT (+3.0 pts). Highest weighted predictor.',
        },
        isRedFlagAlert: true,
        scoreContribution: {
          scoreName: 'Wells PE',
          points: 3.0,
        },
      },
      {
        id: 'pe_prior_vte',
        question: {
          tr: 'Daha önce sizde veya 1. derece ailenizde bacak damarında pıhtı (DVT) veya akciğere pıhtı atması (PE) oldu mu?',
          en: 'Have you or a 1st degree relative ever had a DVT or PE before?',
        },
        patientFriendlyPhraseTR: '"Geçmişte bacağınızda pıhtı tıkanıklığı veya akciğerinize pıhtı atması teşhisi aldınız mı? Kan sulandırıcı kullandınız mı?"',
        rationale: {
          tr: 'Wells Skoru: Geçirilmiş DVT/PE öyküsü (+1.5 puan). Trombofili şüphesini güçlendirir.',
          en: 'Wells Criterion: Previous documented DVT/PE (+1.5 pts).',
        },
        isRedFlagAlert: true,
        scoreContribution: {
          scoreName: 'Wells PE',
          points: 1.5,
        },
      },
      {
        id: 'pe_hemoptysis',
        question: {
          tr: 'Öksürürken ağzınızdan kan veya pembe köpüklü balgam geldi mi?',
          en: 'Have you coughed up blood (hemoptysis)?',
        },
        patientFriendlyPhraseTR: '"Öksürüğünüz oldu mu? Öksürürken balgamınızda çizgi şeklinde kan veya doğrudan kırmızı kan geldi mi?"',
        rationale: {
          tr: 'Wells Skoru: Hemoptizi (+1.0 puan). Pulmoner enfarktüs bulgusudur.',
          en: 'Wells Criterion: Hemoptysis (+1.0 pt). Reflects pulmonary infarction.',
        },
        isRedFlagAlert: true,
        scoreContribution: {
          scoreName: 'Wells PE',
          points: 1.0,
        },
      },
      {
        id: 'pe_malignancy',
        question: {
          tr: 'Aktif kanser teşhisiniz var mı veya son 6 ayda kemoterapi/radyoterapi aldınız mı?',
          en: 'Do you have active cancer or received treatment in the last 6 months?',
        },
        patientFriendlyPhraseTR: '"Herhangi bir kanser veya tümör tedavisi görüyor musunuz? Son 6 ayda kemoterapi aldınız mı?"',
        rationale: {
          tr: 'Wells Skoru: Aktif Malignite (+1.0 puan). Trousseau hiperkoagülabilite durumu.',
          en: 'Wells Criterion: Active Malignancy (+1.0 pt). Hypercoagulable state.',
        },
        isRedFlagAlert: false,
        scoreContribution: {
          scoreName: 'Wells PE',
          points: 1.0,
        },
      },
      {
        id: 'pe_hormones',
        question: {
          tr: 'Doğum kontrol hapı (OKS), hormon tedavisi veya gebelik durumu var mı?',
          en: 'Are you using oral contraceptives, hormone replacement, or are you pregnant?',
        },
        patientFriendlyPhraseTR: '"Doğum kontrol hapı veya östrojen içeren hormon ilacı kullanıyor musunuz? Gebelik veya yeni doğum şüphesi var mı?"',
        rationale: {
          tr: 'Östrojen içeren ilaçlar hiperkoagülabiliteyi ve tromboz riskini 4-8 kat artırır.',
          en: 'Estrogen therapies and pregnancy significantly elevate thromboembolism risk.',
        },
        isRedFlagAlert: false,
      },
      {
        id: 'pe_syncope',
        question: {
          tr: 'Ani bayılma, göz kararması veya yere yığılma oldu mu?',
          en: 'Did you experience syncope or collapse?',
        },
        patientFriendlyPhraseTR: '"Nefesiniz daraldığında aniden kendinizden geçip bayıldınız mı veya yere yığıldınız mı?"',
        rationale: {
          tr: 'Masif Semer (Saddle) PE bulgusudur: Sağ ventrikül akut yüklenmesi ve kardiyak debi çöküşüne işaret eder (Yüksek riskli PE).',
          en: 'Syncope suggests massive saddle PE with acute RV failure and obstructive shock.',
        },
        isRedFlagAlert: true,
      },
    ],
    differentialDiagnoses: {
      tr: [
        'Akut Koroner Sendrom (STEMI / NSTEMI)',
        'Aort Diseksiyonu (Yırtılır tarzda sırta vuran ağrı)',
        'Tansiyon Pnömotoraks (Tek taraflı solunum sesi yokluğu, trakea deviasyonu)',
        'Pnömoni / Plörezi (Ateş, pürülan balgam, raller)',
        'Perikardit / Kardiyak Tamponad',
      ],
      en: [
        'Acute Coronary Syndrome (ACS / MI)',
        'Aortic Dissection (tearing back pain)',
        'Tension Pneumothorax (absent unilateral breath sounds)',
        'Pneumonia / Pleuritis (fever, productive cough, crackles)',
        'Acute Pericarditis / Cardiac Tamponade',
      ],
    },
    physicalExamMusts: {
      tr: [
        'Vital Bulgular: Taşikardi (KH > 100/dk), Hipoksi (SpO2 <%95), Hipotansiyon (SAB < 90 mmHg - Masif PE işareti), Taşıpne (SS > 20/dk).',
        'Alt Ekstremite: Bacak çapı asimetrisi (>3 cm fark), baldırda lokal hassasiyet ve Homans bulgusu.',
        'Kardiyovasküler: Juguler venöz dolgunluk (JVD), S3 safra ritmi, triküspit yetmezlik üfürümü (Sağ kalp yetmezliği bulguları).',
        'EKG Bulguları: En sık sinüs taşikardisidir. Klasik S1Q3T3 paterni (I\'de derin S, III\'te patolojik Q ve negatif T), V1-V4 prekordiyal T negatifliği, yeni gelişen Sağ Dal Bloğu (RBBB).',
      ],
      en: [
        'Vital Signs: Tachycardia (HR >100), Hypoxia (SpO2 <95%), Hypotension (SBP <90 mmHg = Massive PE), Tachypnea (RR >20).',
        'Lower Extremities: Calf circumference discrepancy (>3 cm), local calf tenderness/edema.',
        'Cardiovascular: Jugular venous distension (JVD), accentuated P2, right-sided S3 gallop.',
        'ECG findings: Sinus tachycardia (most common), S1Q3T3 pattern, V1-V4 T-wave inversions, new incomplete/complete RBBB.',
      ],
    },
    diagnosticPathway: [
      {
        step: 1,
        title: {
          tr: '1. Adım: Hemodinamik Stabiliteyi Değerlendir',
          en: 'Step 1: Assess Hemodynamic Stability',
        },
        description: {
          tr: 'Hasta İNSTABİL (Hipotansiyon SAB <90 mmHg veya kardiyak arrest) ise: YÜKSEK RİSKLİ MASİF PE! Yatak başı EKO yapın (Sağ ventrikül genişlemesi / McConnell işareti) ve kontrendikasyon yoksa derhal TROMBOLİTİK (Alteplase - tPA 100 mg IV) veya cerrahi embolektomi planlayın.',
          en: 'If patient is UNSTABLE (SBP <90 mmHg or shock): HIGH-RISK MASSIVE PE! Bedside echo (RV strain / McConnell sign) and immediate THROMBOLYSIS (Alteplase 100 mg IV) if no contraindications.',
        },
      },
      {
        step: 2,
        title: {
          tr: '2. Adım: Wells ve PERC Skorunu Hesapla',
          en: 'Step 2: Calculate Wells & PERC Score',
        },
        description: {
          tr: 'Stabil hastada Wells Skoru ≤4 (Düşük/Orta Olasılık) ise: PERC Kriterlerini kontrol edin. PERC 8/8 negatif ise PE dışlanır (Test gerekmez). PERC pozitif ise D-DİMER testi isteyin.',
          en: 'In stable patient with Wells ≤4 (Low/Intermediate): Check PERC rule. If PERC negative (all 8 criteria met), PE is ruled out. If PERC positive, order D-DIMER.',
        },
      },
      {
        step: 3,
        title: {
          tr: '3. Adım: D-Dimer vs BT Anjiyo Kararı',
          en: 'Step 3: D-Dimer vs CT Pulmonary Angiography (CTPA)',
        },
        description: {
          tr: 'Wells Skoru >4 (Yüksek Olasılık) ise D-Dimer beklemeden doğrudan TORAKS BT ANJİYO (CTPA) çekin.\nWells ≤4 ve D-Dimer normal (<500 mcg/L veya Yaş x 10) ise PE dışlanır.\nWells ≤4 ve D-Dimer (+) ise TORAKS BT ANJİYO çekilmelidir.',
          en: 'If Wells >4 (High Probability): Proceed directly to CTPA without D-dimer.\nIf Wells ≤4 and D-dimer is normal (<500 or Age-adjusted), PE is excluded.\nIf Wells ≤4 and D-dimer elevated, obtain CTPA.',
        },
      },
      {
        step: 4,
        title: {
          tr: '4. Adım: Tedavi Başlama (Antikoagülasyon)',
          en: 'Step 4: Initiate Anticoagulation',
        },
        description: {
          tr: 'PE tanısı doğrulanırsa veya yüksek klinik şüphede görüntüleme gecikecekse derhal CLEXANE (Enoksaparin) 1 mg/kg SC (12 saatte bir) veya Anfraksiyone Heparin başlayın.',
          en: 'If PE confirmed or high suspicion with imaging delays, immediately start Enoxaparin 1 mg/kg SC q12h or UFH infusion.',
        },
      },
    ],
    associatedScoreId: 'wells_pe',
  },
  {
    id: 'acute_chest_pain',
    condition: {
      tr: 'Akut Göğüs Ağrısı - Koroner Sendrom & Ayırıcı Tanı',
      en: 'Acute Chest Pain - ACS & Differential Diagnosis',
    },
    chiefComplaint: {
      tr: 'Göğüste Baskı, Sıkışma, Yanma veya Sol Kola/Çeneye Vuran Ağrı',
      en: 'Chest Pressure, Squeezing, Burning or Radiation to Arm/Jaw',
    },
    triagePriority: 'red',
    overview: {
      tr: 'Acil serviste göğüs ağrısı ile başvuran her hastada ilk 10 dakika içinde 12 derivasyonlu EKG çekilmeli ve ölümcül 5 göğüs ağrısı nedeni (STEMI/AKS, Aort Diseksiyonu, Pulmoner Emboli, Tansiyon Pnömotoraks, Özofagus Rüptürü/Boerhaave) derhal ekarte edilmelidir.',
      en: 'In every patient presenting with acute chest pain, a 12-lead ECG must be obtained within <10 minutes. The "Big 5" life threats (STEMI/ACS, Aortic Dissection, PE, Tension Pneumothorax, Esophageal Rupture) must be ruled out.',
    },
    mustAskQuestions: [
      {
        id: 'cp_onset_quality',
        question: {
          tr: 'Ağrının karakteri nasıl? (Baskı, sıkışma, yırtılma, batma, yanma?)',
          en: 'What is the quality of the pain? (Pressure, tearing, sharp, burning?)',
        },
        patientFriendlyPhraseTR: '"Göğsünüzdeki ağrı nasıl bir his? Üzerinize bir ağırlık oturmuş gibi baskı mı, bıçak batması gibi mi, yoksa göğsünüz yırtılıyor gibi mi?"',
        rationale: {
          tr: 'Baskı/fil oturması gibi: Tipik İskemi / AKS. Yırtılır tarzda sırta vuran: Aort Diseksiyonu. Nefesle batan: PE/Plevra/Perikardit.',
          en: 'Substernal heavy pressure: ACS. Tearing/ripping to interscapular back: Aortic Dissection. Pleuritic sharp: PE/Pericarditis.',
        },
        isRedFlagAlert: true,
      },
      {
        id: 'cp_radiation',
        question: {
          tr: 'Ağrı başka bir yere yayılıyor mu? (Sol kol, çene, boyun, sırt, epigastrium?)',
          en: 'Does the pain radiate anywhere? (Left arm, jaw, neck, back?)',
        },
        patientFriendlyPhraseTR: '"Bu ağrı sol omzunuza, kolunuza, çenenize, boynunuza veya iki kürek kemiğinizin arasına vuruyor mu?"',
        rationale: {
          tr: 'Her iki kola veya çeneye yayılan ağrıda AKS pozitif olabilirlik oranı (LR+) çok yüksektir.',
          en: 'Radiation to both shoulders/arms or jaw has highest positive likelihood ratio for acute MI.',
        },
        isRedFlagAlert: true,
      },
      {
        id: 'cp_associated_symptoms',
        question: {
          tr: 'Ağrıyla birlikte soğuk terleme, bulantı, kusma veya nefes darlığı oldu mu?',
          en: 'Do you have cold diaphoresis, nausea, vomiting, or dyspnea?',
        },
        patientFriendlyPhraseTR: '"Ağrıyla birlikte aniden sırılsıklam soğuk ter döktünüz mü? Midanız bulandı mı veya nefesiniz kesildi mi?"',
        rationale: {
          tr: 'Soğuk terleme (diyaforez) ve otonomik semptomlar akut transmural miyokard iskemisinin güçlü belirtisidir.',
          en: 'Cold diaphoresis is a strong independent predictor of acute myocardial infarction.',
        },
        isRedFlagAlert: true,
      },
      {
        id: 'cp_risk_factors',
        question: {
          tr: 'Şeker hastalığı, yüksek tansiyon, sigara veya ailede erken kalp krizi öyküsü var mı?',
          en: 'Do you have diabetes, hypertension, smoking, or family history of premature CAD?',
        },
        patientFriendlyPhraseTR: '"Diyabetiniz (şeker), tansiyonunuz var mı? Sigara kullanıyor musunuz? Ailenizde genç yaşta kalp krizi geçiren oldu mu?"',
        rationale: {
          tr: 'HEART Skoru Risk Faktörleri (≥3 risk faktörü veya bilinen KAH varlığı = +2 puan).',
          en: 'HEART Score Risk factor evaluation (≥3 risk factors or known CAD = +2 pts).',
        },
        isRedFlagAlert: false,
      },
      {
        id: 'cp_duration',
        question: {
          tr: 'Ağrı kaç dakikadır sürüyor? Dinlenmekle veya dilaltı ile geçiyor mu?',
          en: 'How long has the pain lasted? Does it resolve with rest or sublingual nitrates?',
        },
        patientFriendlyPhraseTR: '"Ağrı ne kadar süredir devam ediyor? Oturup dinlenince veya daha önce kalp ilacı aldıysanız azaldı mı?"',
        rationale: {
          tr: '>20 dakika süren istirahat anjinası Akut Koroner Sendromu (MI / Kararsız Angina) düşündürür.',
          en: 'Ischemic pain lasting >20 min at rest suggests Acute MI / Unstable Angina.',
        },
        isRedFlagAlert: true,
      },
    ],
    differentialDiagnoses: {
      tr: [
        'Akut ST Yükselmeli Miyokard Enfarktüsü (STEMI) / NSTEMI',
        'Akut Aort Diseksiyonu (Tip A / Tip B)',
        'Masif Pulmoner Emboli',
        'Tansiyon Pnömotoraks',
        'Akut Perikardit / Miyokardit',
        'Özofajit / Gastroözofageal Reflü / Spazm',
        'Kostokondrit (Tietze Sendromu - palpasyonla ağrılı)',
      ],
      en: [
        'STEMI / NSTEMI',
        'Acute Aortic Dissection',
        'Massive Pulmonary Embolism',
        'Tension Pneumothorax',
        'Acute Pericarditis',
        'GERD / Esophageal Spasm',
        'Costochondritis (Tietze Syndrome)',
      ],
    },
    physicalExamMusts: {
      tr: [
        'İlk 10 Dakika Kuralı: Hemen 12 derivasyonlu EKG çekilmeli (ST elevasyonu, ST depresyonu, hiperakut T, patolojik Q, yeni Sol Dal Bloğu aranmalı).',
        'Her İki Koldan Tansiyon Ölçümü: Kollar arası >20 mmHg fark Aort Diseksiyonu için yüksek şüphedir!',
        'Akciğer Oskültasyonu: Solunum sesleri simetrik mi? (Pnömotoraks dışlama), Ral/krepitan var mı? (Kalp yetmezliği / Killip sınıflandırması).',
        'Göğüs Duvarı Palpasyonu: Kostokondral bileşkeye basmakla ağrı tam olarak reprodüse olabiliyor mu?',
      ],
      en: [
        '10-Minute ECG Rule: 12-lead ECG immediately to identify STEMI, ST depressions, hyperacute T waves, or new LBBB.',
        'Bilateral Blood Pressure: >20 mmHg inter-arm difference raises high suspicion of Aortic Dissection.',
        'Lung Auscultation: Equal bilateral breath sounds (rules out pneumothorax), crackles/rales (Killip failure staging).',
        'Chest Wall Palpation: Reproducibility of pain with localized costochondral pressure.',
      ],
    },
    diagnosticPathway: [
      {
        step: 1,
        title: {
          tr: '1. EKG İncelemesi: STEMI Var mı?',
          en: '1. ECG Review: Is it STEMI?',
        },
        description: {
          tr: 'Ardışık en az 2 derivasyonda ST elevasyonu (V2-V3\'te erkeklerde ≥2 mm, kadınlarda ≥1.5 mm, diğer derivasyonlarda ≥1 mm) veya yeni LBBB varsa: STEMI ACİLİ! Derhal KORONER ANJİOGRAFİ (Kardiyoloji / Primer PKG) aktive edin. Kapı-Balon süresi <90 dk!',
          en: 'If ST elevation in ≥2 contiguous leads: STEMI EMERGENCY! Activate Primary PCI (Door-to-balloon <90 min).',
        },
      },
      {
        step: 2,
        title: {
          tr: '2. STEMI Tedavi Paketi',
          en: '2. Acute STEMI Medical Loading',
        },
        description: {
          tr: 'Aspirin 300 mg çiğnetme + Klopidogrel 300-600 mg (veya Tikagrelor 180 mg) + Clexane 30 mg IV bolus + 1 mg/kg SC + Oksijen (sadece SpO2 <%90 ise).',
          en: 'Aspirin 300 mg chewed + Clopidogrel 300-600 mg (or Ticagrelor 180 mg) + Enoxaparin 30 mg IV + 1 mg/kg SC + O2 if SpO2 <90%.',
        },
      },
      {
        step: 3,
        title: {
          tr: '3. EKG\'de ST Elevasyonu Yoksa (NSTE-AKS)',
          en: '3. If No ST Elevation (NSTE-ACS)',
        },
        description: {
          tr: 'Seri yüksek duyarlılıklı Kardiyak Troponin (0. saat ve 1-3. saat), seri EKG çekimleri ve HEART Skoru ile risk sınıflandırması yapın.',
          en: 'Serial high-sensitivity cardiac Troponin (0h, 1-3h), serial ECGs, and HEART Score risk stratification.',
        },
      },
    ],
    associatedScoreId: 'heart_score',
  },
  {
    id: 'acute_abdomen',
    condition: {
      tr: 'Akut Karın - Cerrahi Batın & Apandisit Ayrımı',
      en: 'Acute Abdomen & Appendicitis',
    },
    chiefComplaint: {
      tr: 'Şiddetli Karın Ağrısı, Bulantı/Kusma, İştahsızlık, Gaz-Gaita Çıkaramama',
      en: 'Severe Abdominal Pain, Nausea, Anorexia, Obstipation',
    },
    triagePriority: 'yellow',
    overview: {
      tr: 'Akut karın; acil cerrahi müdahale gerektirebilecek, genellikle 24-48 saatten kısa süreli karın ağrısı tablosudur. İntörn hekimin temel hedefi peritonit (defans, rebound, tahta karın) varlığını saptamak ve hastanın genel cerrahiye konsülte edilip edilmeyeceğine karar vermektir.',
      en: 'Acute abdominal syndrome requiring rapid differentiation between medical causes and surgical emergencies. Detecting signs of peritonitis (defense, rebound, rigidity) is paramount.',
    },
    mustAskQuestions: [
      {
        id: 'aa_migration',
        question: {
          tr: 'Ağrı ilk nerede başladı ve yer değiştirdi mi? (Ağrı göbek çevresinden sağ alt kadran kaydı mı?)',
          en: 'Where did the pain start and did it migrate? (Periumbilical to RLQ?)',
        },
        patientFriendlyPhraseTR: '"Ağrınız ilk olarak göbeğinizin etrafında veya midenizde başlayıp sonradan sağ alt kasığınıza doğru indi mi?"',
        rationale: {
          tr: 'Alvarado Skoru: Ağrının sağ alt kadrana göç etmesi (+1 puan). Akut Apandisitin klasik viseral-somatik ağrı geçişidir.',
          en: 'Alvarado Criterion: Pain migration to RLQ (+1 pt). Classic visceral to somatic shift in Acute Appendicitis.',
        },
        isRedFlagAlert: true,
        scoreContribution: {
          scoreName: 'Alvarado',
          points: 1,
        },
      },
      {
        id: 'aa_anorexia',
        question: {
          tr: 'İştahınız nasıl? En sevdiğiniz yemeği getirseydik yiyebilir miydiniz?',
          en: 'Do you have appetite loss (anorexia)?',
        },
        patientFriendlyPhraseTR: '"Şu an çok sevdiğiniz bir yemek olsa canınız çeker mi, yiyebilir misiniz?" (İştahsızlık var mı?)',
        rationale: {
          tr: 'Alvarado Skoru: İştahsızlık / Anoreksi (+1 puan). Apandisitte iştah kaybı %90\'ın üzerinde görülür.',
          en: 'Alvarado Criterion: Anorexia (+1 pt). Very sensitive for appendicitis.',
        },
        isRedFlagAlert: false,
        scoreContribution: {
          scoreName: 'Alvarado',
          points: 1,
        },
      },
      {
        id: 'aa_nausea_vomiting',
        question: {
          tr: 'Ağrıdan sonra bulantı veya kusma oldu mu?',
          en: 'Did nausea or vomiting occur after the pain started?',
        },
        patientFriendlyPhraseTR: '"Ağrı başladıktan sonra mideniz bulandı mı veya kustunuz mu?"',
        rationale: {
          tr: 'Alvarado Skoru: Bulantı/Kusma (+1 puan). Cerrahi batında ağrı ÖNCE başlar, bulantı/kusma SONRA gelir. Gastroenteritte ise kusma/ishal ağrıdan önce veya eşzamanlıdır.',
          en: 'In surgical abdomen, PAIN precedes vomiting. In gastroenteritis, vomiting precedes or coincides with pain.',
        },
        isRedFlagAlert: false,
        scoreContribution: {
          scoreName: 'Alvarado',
          points: 1,
        },
      },
      {
        id: 'aa_bowel_movements',
        question: {
          tr: 'En son ne zaman gaz ve büyük abdestinizi çıkardınız?',
          en: 'When did you last pass gas and bowel movements?',
        },
        patientFriendlyPhraseTR: '"En son ne zaman büyük tuvaletinizi yaptınız ve gaz çıkarabildiniz mi?"',
        rationale: {
          tr: 'Gaz-gaita çıkaramama (obstipasyon) ve karında şişkinlik MEKANİK İLEUS / BAĞIRSAK TIKANIKLIĞININ temel bulgusudur.',
          en: 'Complete obstipation with abdominal distension indicates mechanical bowel obstruction / ileus.',
        },
        isRedFlagAlert: true,
      },
      {
        id: 'aa_lup_last_period',
        question: {
          tr: 'Kadın hastalarda: Son adet tarihiniz (SAT) ne zamandı? Gebe olma ihtimaliniz var mı?',
          en: 'In females: When was your Last Menstrual Period (LMP)? Any chance of pregnancy?',
        },
        patientFriendlyPhraseTR: '"Son adetiniz ne zamandı? Adetinizde gecikme veya düzensizlik var mı? Gebelik şüphesi taşıyor musunuz?"',
        rationale: {
          tr: 'Doğurganlık çağındaki her kadın hastada akut karın tablosunda EKTOPİK GEBELİK RÜPTÜRÜ ve Over Torsiyonu beta-hCG ile dışlanmalıdır!',
          en: 'Ruptured Ectopic Pregnancy and Ovarian Torsion must be ruled out with urine/serum beta-hCG in all reproductive-age females.',
        },
        isRedFlagAlert: true,
      },
    ],
    differentialDiagnoses: {
      tr: [
        'Akut Apandisit',
        'Akut Kolesistit (Sağ üst kadran ağrısı, Murphy pozitifliği)',
        'Peptik Ülser Perforasyonu (Ani başlayan tahta karın, serbest hava)',
        'Mekanik Bağırsak Tıkanıklığı (İleus / Volvulus)',
        'Akut Pankreatit (Kuşak tarzı sırta vuran ağrı, lipaz yüksekliği)',
        'Ektopik Gebelik Rüptürü / Over Torsiyonu / PID',
        'Akut Mezenter İskemi (Muayene bulgusuyla orantısız şiddetli karın ağrısı - Yaşlı/AF hastası)',
      ],
      en: [
        'Acute Appendicitis',
        'Acute Cholecystitis',
        'Perforated Peptic Ulcer',
        'Bowel Obstruction / Ileus',
        'Acute Pancreatitis',
        'Ruptured Ectopic Pregnancy / Ovarian Torsion',
        'Acute Mesenteric Ischemia ("pain out of proportion to exam")',
      ],
    },
    physicalExamMusts: {
      tr: [
        'McBurney Noktası Hassasiyeti: Spina iliaca anterior superior ile göbek arasındaki hattın 1/3 dış kısmında hassasiyet (+2 puan).',
        'Rebound (Blumberg) Belirtisi: Karına yavaşça bastırılıp el aniden çekildiğinde şiddetli ağrı olması (Paryetal peritonit işareti, +1 puan).',
        'Defans (İstemli vs İstemsiz Guarding): Karın kaslarının tahta gibi sertleşmesi (Perforasyon/yaygın peritonit).',
        'Rovsing Belirtisi: Sol alt kadrana bastırıldığında sağ alt kadranda ağrı hissedilmesi.',
        'Murphy Belirtisi: Sağ hipokondriyuma derin palpasyon sırasında hastaya derin nefes aldırıldığında ağrıyla nefesin aniden kesilmesi (Kolesistit).',
      ],
      en: [
        'McBurney Point Tenderness (+2 pts in Alvarado).',
        'Rebound tenderness (+1 pt in Alvarado) indicating peritoneal irritation.',
        'Involuntary muscular rigidity/defense.',
        'Rovsing sign (left-sided pressure elicits RLQ pain).',
        'Murphy sign (inspiratory arrest on RUQ palpation in cholecystitis).',
      ],
    },
    diagnosticPathway: [
      {
        step: 1,
        title: {
          tr: '1. Acil Laboratuvar & Görüntüleme',
          en: '1. Urgent Labs & Imaging',
        },
        description: {
          tr: 'Hemogram (Lökositoz, sola kayma), CRP, Karaciğer/Böbrek testleri, Lipaz/Amilaz, TİT ve Kadınlarda mutlaka Beta-hCG bakın. Ayakta Direkt Batın Grafisi (ADBG) çekerek diyafram altı serbest hava (perforasyon) ve hava-sıvı seviyeleri (ileus) arayın.',
          en: 'CBC (leukocytosis), CRP, LFTs, Lipase, Urinalysis, and mandatory pregnancy test in females. Upright abdominal X-ray for free subdiaphragmatic air (perforation) or air-fluid levels (ileus).',
        },
      },
      {
        step: 2,
        title: {
          tr: '2. Ultrasonografi (USG) ve Kontrastlı Batın BT',
          en: '2. Abdominal USG & CT',
        },
        description: {
          tr: 'Genç ve zayıf hastalarda ilk tercih Batın USG\'dir (kompresyona dirençli >6 mm kör sonlanan aperistaltik apandiks). Yaşlı veya USG\'nin yetersiz kaldığı olgularda IV Kontrastlı Batın BT altın standarttır.',
          en: 'Abdominal USG is first-line in young/thin patients. IV-contrast Abdominal CT is gold standard for definitive diagnosis.',
        },
      },
    ],
    associatedScoreId: 'alvarado_score',
  },
];
