import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { CLINICAL_CALCULATORS_DATABASE } from '../data/calculatorsData';
import {
  Calculator,
  AlertTriangle,
  CheckCircle2,
  AlertOctagon,
  Droplets,
  RotateCcw,
  Sparkles,
  HeartPulse,
} from 'lucide-react';

export const CalculatorsView: React.FC = () => {
  const { language, t } = useLanguage();
  const [selectedCalcId, setSelectedCalcId] = useState<string>(
    CLINICAL_CALCULATORS_DATABASE[0].id
  );

  // Selected option state: { [calcId]: { [itemId]: number (points) } }
  const [calcState, setCalcState] = useState<Record<string, Record<string, number>>>({});

  // Infusion calculator state
  const [fluidVolume, setFluidVolume] = useState<number>(1000); // ml
  const [infusionHours, setInfusionHours] = useState<number>(8); // hours
  const [dropFactor, setDropFactor] = useState<number>(20); // 20 drops/ml (standard IV set)

  // Pediatric dose quick helper
  const [childWeight, setChildWeight] = useState<number>(15); // kg

  const activeCalc =
    CLINICAL_CALCULATORS_DATABASE.find((c) => c.id === selectedCalcId) ||
    CLINICAL_CALCULATORS_DATABASE[0];

  const currentSelection = calcState[activeCalc.id] || {};

  const handleSelectOption = (itemId: string, points: number) => {
    setCalcState((prev) => ({
      ...prev,
      [activeCalc.id]: {
        ...(prev[activeCalc.id] || {}),
        [itemId]: points,
      },
    }));
  };

  const handleResetCurrent = () => {
    setCalcState((prev) => ({
      ...prev,
      [activeCalc.id]: {},
    }));
  };

  // Calculate total score
  const totalScore: number = (Object.values(currentSelection) as number[]).reduce((a: number, b: number) => a + b, 0);

  // Find matching interpretation
  const interpretation = activeCalc.interpretations.find(
    (inter) => totalScore >= inter.minScore && totalScore <= inter.maxScore
  );

  // Infusion calculations
  const mlPerHour = infusionHours > 0 ? (fluidVolume / infusionHours).toFixed(1) : '0';
  const dropsPerMin =
    infusionHours > 0
      ? Math.round((fluidVolume * dropFactor) / (infusionHours * 60))
      : 0;

  const getRiskBadge = (risk: 'low' | 'moderate' | 'high') => {
    switch (risk) {
      case 'low':
        return (
          <span className="px-3 py-1 text-xs font-bold rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-700/60 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            {language === 'tr' ? 'Düşük Risk' : 'Low Risk'}
          </span>
        );
      case 'moderate':
        return (
          <span className="px-3 py-1 text-xs font-bold rounded-full bg-amber-950/80 text-amber-300 border border-amber-700/60 flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5" />
            {language === 'tr' ? 'Orta Risk' : 'Moderate Risk'}
          </span>
        );
      case 'high':
        return (
          <span className="px-3 py-1 text-xs font-bold rounded-full bg-rose-950/80 text-rose-300 border border-rose-700/60 flex items-center gap-1">
            <AlertOctagon className="w-3.5 h-3.5" />
            {language === 'tr' ? 'Yüksek Risk / Acil' : 'High Risk / Critical'}
          </span>
        );
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 shadow-md">
        <div className="flex items-center gap-2 mb-3">
          <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">
              {language === 'tr'
                ? 'Klinik Skorlar & Acil Hesaplama Araçları'
                : 'Clinical Risk Scores & Medical Calculators'}
            </h2>
            <p className="text-xs text-slate-400">
              {language === 'tr'
                ? 'Wells PE, HEART, Alvarado, GKS ve Acil Mayi/İnfüzyon Hızı Hesaplayıcı'
                : 'Wells PE, HEART, Alvarado, GCS, and IV Drip Rate Calculator'}
            </p>
          </div>
        </div>

        {/* Calc Selector Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pt-2 pb-1 scrollbar-none">
          {CLINICAL_CALCULATORS_DATABASE.map((calc) => {
            const isSelected = calc.id === activeCalc.id;
            return (
              <button
                key={calc.id}
                id={`calc-tab-${calc.id}`}
                onClick={() => setSelectedCalcId(calc.id)}
                className={`px-3.5 py-2 text-xs font-bold rounded-xl whitespace-nowrap transition ${
                  isSelected
                    ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {calc.shortName}
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Clinical Score Calculator */}
      <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-950/60 border border-amber-800/50 px-2 py-0.5 rounded">
              {activeCalc.category[language]}
            </span>
            <h3 className="text-base font-bold text-white mt-1">
              {activeCalc.name[language]}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {activeCalc.description[language]}
            </p>
          </div>
          <button
            onClick={handleResetCurrent}
            className="flex items-center gap-1 text-xs text-slate-400 hover:text-amber-400 p-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition"
            title="Sıfırla"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Sıfırla</span>
          </button>
        </div>

        {/* Items List */}
        <div className="space-y-3">
          {activeCalc.items.map((item) => (
            <div
              key={item.id}
              className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 space-y-2"
            >
              <label className="text-xs font-bold text-slate-200 block">
                {item.label[language]}
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                {item.options.map((opt, oIdx) => {
                  const isChosen = currentSelection[item.id] === opt.points;
                  return (
                    <button
                      key={oIdx}
                      onClick={() => handleSelectOption(item.id, opt.points)}
                      className={`p-2.5 rounded-lg text-xs font-medium border text-left transition flex items-center justify-between gap-2 ${
                        isChosen
                          ? 'bg-amber-950/60 border-amber-600 text-amber-200 font-bold shadow-sm'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                      }`}
                    >
                      <span className="line-clamp-1">{opt.label[language]}</span>
                      <span className="font-mono font-bold text-[11px] px-1.5 py-0.5 rounded bg-slate-950 text-slate-300">
                        +{opt.points}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Result & Interpretation Display */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-400">{t('totalScore')}</span>
              <span className="text-2xl font-black text-amber-400 font-mono">
                {totalScore.toFixed(activeCalc.id === 'wells_pe' ? 1 : 0)}
              </span>
            </div>

            {interpretation && getRiskBadge(interpretation.riskLevel)}
          </div>

          {interpretation && (
            <div className="space-y-2 border-t border-slate-800 pt-3 text-xs">
              <h4 className="font-bold text-white text-xs flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                {interpretation.title[language]}
              </h4>
              <p className="text-slate-300 leading-relaxed bg-slate-900/90 p-3 rounded-lg border border-slate-800">
                {interpretation.management[language]}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Secondary Tool: IV Fluid Infusion Rate Calculator */}
      <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2">
          <Droplets className="w-5 h-5 text-sky-400" />
          <div>
            <h3 className="text-sm font-bold text-white">
              {language === 'tr' ? 'IV Mayi & Damla Hızı Hesaplayıcı' : 'IV Fluid & Drip Rate Calculator'}
            </h3>
            <p className="text-xs text-slate-400">
              {language === 'tr' ? 'Saatlik ml ve dakikadaki damla sayısı hesabı' : 'Calculate ml/hour and drops/minute'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div>
            <label className="text-slate-400 block mb-1 font-semibold">Toplam Hacim (ml)</label>
            <input
              type="number"
              value={fluidVolume}
              onChange={(e) => setFluidVolume(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="text-slate-400 block mb-1 font-semibold">Süre (Saat)</label>
            <input
              type="number"
              value={infusionHours}
              onChange={(e) => setInfusionHours(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="text-slate-400 block mb-1 font-semibold">Set Damla Faktörü</label>
            <select
              value={dropFactor}
              onChange={(e) => setDropFactor(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
            >
              <option value={20}>Standart Set (20 damla/ml)</option>
              <option value={60}>Mikro-drip / Pediatrik (60 damla/ml)</option>
              <option value={15}>Kan Transfüzyon Seti (15 damla/ml)</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-2">
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
            <span className="text-xs text-slate-400 block font-semibold">İnfüzyon Hızı</span>
            <span className="text-xl font-bold text-sky-400 font-mono">{mlPerHour} ml/saat</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
            <span className="text-xs text-slate-400 block font-semibold">Damla Sayısı</span>
            <span className="text-xl font-bold text-emerald-400 font-mono">{dropsPerMin} damla/dk</span>
          </div>
        </div>
      </div>

      {/* Tertiary Tool: Pediatric Quick ER Dose Helper */}
      <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HeartPulse className="w-5 h-5 text-rose-400" />
            <div>
              <h3 className="text-sm font-bold text-white">
                {language === 'tr' ? 'Pediatrik Acil Doz Pratik Tablosu' : 'Pediatric Emergency Dose Guide'}
              </h3>
              <p className="text-xs text-slate-400">
                {language === 'tr' ? 'Çocuğun kilosuna göre tek doz hesaplayıcı' : 'Weight-based single dose calculator'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-slate-400 font-semibold">Kilo:</span>
            <input
              type="number"
              value={childWeight}
              onChange={(e) => setChildWeight(Math.max(1, Number(e.target.value)))}
              className="w-16 bg-slate-950 border border-slate-800 rounded-lg p-1 text-center text-white font-mono font-bold text-xs"
            />
            <span className="text-xs text-slate-400">kg</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          <div className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800 space-y-0.5">
            <span className="font-bold text-rose-300">Parasetamol (Calpol / Parol)</span>
            <p className="text-slate-300">
              10-15 mg/kg tek doz:{' '}
              <strong className="text-amber-300 font-mono">
                {(childWeight * 10).toFixed(0)} - {(childWeight * 15).toFixed(0)} mg
              </strong>
            </p>
            <p className="text-slate-500 text-[11px]">Calpol 120mg/5ml ise ~{((childWeight * 12.5) / 24).toFixed(1)} ml</p>
          </div>

          <div className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800 space-y-0.5">
            <span className="font-bold text-amber-300">İbuprofen (Dolven / İbufen)</span>
            <p className="text-slate-300">
              5-10 mg/kg tek doz:{' '}
              <strong className="text-amber-300 font-mono">
                {(childWeight * 5).toFixed(0)} - {(childWeight * 10).toFixed(0)} mg
              </strong>
            </p>
            <p className="text-slate-500 text-[11px]">Dolven 100mg/5ml ise ~{((childWeight * 7.5) / 20).toFixed(1)} ml</p>
          </div>

          <div className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800 space-y-0.5">
            <span className="font-bold text-sky-300">Amoksisilin-Klavulanat (Augmentin)</span>
            <p className="text-slate-300">
              Günlük 40-50 mg/kg (2 doza bölünür):{' '}
              <strong className="text-sky-300 font-mono">
                {((childWeight * 45) / 2).toFixed(0)} mg / doz (2x1)
              </strong>
            </p>
          </div>

          <div className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800 space-y-0.5">
            <span className="font-bold text-emerald-300">Seftriakson (Rocephin)</span>
            <p className="text-slate-300">
              50-75 mg/kg/gün IV/IM tek doz:{' '}
              <strong className="text-emerald-300 font-mono">
                {(childWeight * 50).toFixed(0)} - {(childWeight * 75).toFixed(0)} mg
              </strong>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
