import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { SHIFT_PEARLS_DATABASE } from '../data/shiftPearlsData';
import {
  BookOpen,
  ShieldAlert,
  Activity,
  Zap,
  FileCheck2,
  ChevronDown,
  ChevronUp,
  Sparkles,
} from 'lucide-react';

export const PearlsView: React.FC = () => {
  const { language } = useLanguage();
  const [expandedPearlId, setExpandedPearlId] = useState<string | null>(
    SHIFT_PEARLS_DATABASE[0]?.id || null
  );

  const getIcon = (name: string) => {
    switch (name) {
      case 'ShieldAlert':
        return <ShieldAlert className="w-5 h-5 text-rose-400" />;
      case 'Activity':
        return <Activity className="w-5 h-5 text-sky-400" />;
      case 'Zap':
        return <Zap className="w-5 h-5 text-amber-400" />;
      case 'FileCheck2':
        return <FileCheck2 className="w-5 h-5 text-emerald-400" />;
      default:
        return <BookOpen className="w-5 h-5 text-purple-400" />;
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 shadow-md">
        <div className="flex items-center gap-2 mb-2">
          <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">
              {language === 'tr'
                ? 'İntörn Hekim Acil Nöbet & Klinik İpuçları'
                : 'ER Intern Shift Survival Pearls'}
            </h2>
            <p className="text-xs text-slate-400">
              {language === 'tr'
                ? 'Triyaj renkleri, 6 adımda EKG okuma, 4 adımda kan gazı çözümü ve medikolegal kurallar'
                : 'Triage rules, 6-step ECG algorithm, 4-step ABG solver, and medicolegal rules'}
            </p>
          </div>
        </div>
      </div>

      {/* Pearls Accordion */}
      <div className="space-y-3">
        {SHIFT_PEARLS_DATABASE.map((pearl) => {
          const isExpanded = expandedPearlId === pearl.id;
          return (
            <div
              key={pearl.id}
              className="bg-slate-900/80 rounded-2xl border border-slate-800 overflow-hidden shadow-sm transition"
            >
              <div
                onClick={() => setExpandedPearlId(isExpanded ? null : pearl.id)}
                className="p-4 cursor-pointer flex items-center justify-between gap-3 hover:bg-slate-800/50 transition"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                    {getIcon(pearl.iconName)}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">
                      {pearl.title[language]}
                    </h3>
                    <p className="text-xs text-slate-400 font-medium">
                      {pearl.category[language]}
                    </p>
                  </div>
                </div>

                <div className="text-slate-400">
                  {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </div>
              </div>

              {isExpanded && (
                <div className="p-4 pt-0 border-t border-slate-800 space-y-3 text-xs">
                  <p className="text-slate-300 bg-slate-950/60 p-3 rounded-xl border border-slate-800/60 leading-relaxed">
                    {pearl.content[language]}
                  </p>

                  <div className="space-y-2">
                    {pearl.bulletPoints[language].map((bullet, idx) => (
                      <div
                        key={idx}
                        className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-slate-200 leading-relaxed whitespace-pre-line"
                      >
                        {bullet}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
