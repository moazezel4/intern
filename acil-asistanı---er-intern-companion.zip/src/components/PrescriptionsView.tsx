import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { MINOR_DISEASES_DATABASE } from '../data/prescriptionsData';
import { MinorDisease } from '../types';
import {
  FileText,
  Copy,
  Check,
  AlertOctagon,
  Syringe,
  Pill,
  ShieldAlert,
  ChevronDown,
  ChevronUp,
  HeartHandshake,
  Search,
} from 'lucide-react';

export const PrescriptionsView: React.FC = () => {
  const { language, t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(MINOR_DISEASES_DATABASE[0]?.id || null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredDiseases = MINOR_DISEASES_DATABASE.filter((item) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    const matchTitle = item.title[language].toLowerCase().includes(q);
    const matchCat = item.category[language].toLowerCase().includes(q);
    const matchSummary = item.summary[language].toLowerCase().includes(q);
    const matchDrugs = item.outpatientPrescription.items.some(
      (d) =>
        d.drugName.toLowerCase().includes(q) ||
        d.activeIngredient.toLowerCase().includes(q)
    );
    return matchTitle || matchCat || matchSummary || matchDrugs;
  });

  const handleCopyPrescription = (disease: MinorDisease) => {
    const prescriptionText = `=== E-REÇETE / AYAKTAN TABURCULUK ===
Tanı: ${disease.outpatientPrescription.diagnosisCode} - ${disease.outpatientPrescription.diagnosisName[language]}

İLAÇLAR:
${disease.outpatientPrescription.items
  .map(
    (item, idx) =>
      `${idx + 1}. ${item.drugName}
   Etken Madde: ${item.activeIngredient}
   Adet: ${item.boxCount}
   Kullanım: ${item.dosageInstructions[language]}${
        item.notes ? `\n   Not: ${item.notes[language]}` : ''
      }`
  )
  .join('\n\n')}

ÖNERİLER:
${disease.outpatientPrescription.nonPharmacologicalAdvice[language]
  .map((adv) => `- ${adv}`)
  .join('\n')}

ACİLE TEKRAR GELME ŞARTLARI:
${disease.returnToERCriteria[language].map((c) => `! ${c}`).join('\n')}
`;

    navigator.clipboard.writeText(prescriptionText);
    setCopiedId(disease.id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const getTriageBadge = (color: 'green' | 'yellow' | 'red') => {
    switch (color) {
      case 'green':
        return (
          <span className="px-2 py-0.5 text-[11px] font-bold rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-700/60">
            🟢 {t('greenZone')}
          </span>
        );
      case 'yellow':
        return (
          <span className="px-2 py-0.5 text-[11px] font-bold rounded-full bg-amber-950/80 text-amber-300 border border-amber-700/60">
            🟡 {t('yellowZone')}
          </span>
        );
      case 'red':
        return (
          <span className="px-2 py-0.5 text-[11px] font-bold rounded-full bg-rose-950/80 text-rose-300 border border-rose-700/60">
            🔴 {t('redZone')}
          </span>
        );
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header card */}
      <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 shadow-md">
        <div className="flex items-center gap-2 mb-3">
          <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">
              {language === 'tr'
                ? 'Acil Minör Hastalıklar & Tam e-Reçete Rehberi'
                : 'Minor Diseases & Full Prescriptions'}
            </h2>
            <p className="text-xs text-slate-400">
              {language === 'tr'
                ? 'SGK/Medula uyumlu tam reçete formatı (Kutu adedi, kullanım şeması, Türkiye ticari isimleri), acil orderı ve kırmızı bayraklar'
                : 'SGK/Medula-compliant prescriptions with full posology, bedside orders, and red flags'}
            </p>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            id="prescription-search-input"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              language === 'tr'
                ? 'Hastalık, ICD kodu, ilaç adı veya etken madde ara...'
                : 'Search disease, ICD code, drug name or active ingredient...'
            }
            className="w-full bg-slate-950/80 text-slate-100 placeholder-slate-500 text-sm rounded-xl pl-10 pr-4 py-2.5 border border-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition"
          />
        </div>
      </div>

      {/* Disease Accordion List */}
      <div className="space-y-3">
        {filteredDiseases.map((disease) => {
          const isExpanded = expandedId === disease.id;
          return (
            <div
              key={disease.id}
              id={`disease-card-${disease.id}`}
              className="bg-slate-900/80 rounded-2xl border border-slate-800 overflow-hidden shadow-sm transition"
            >
              {/* Card Header (Accordion Trigger) */}
              <div
                onClick={() => setExpandedId(isExpanded ? null : disease.id)}
                className="p-4 cursor-pointer flex items-center justify-between gap-3 hover:bg-slate-800/50 transition"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-base font-bold text-white">
                      {disease.title[language]}
                    </h3>
                    {getTriageBadge(disease.triageColor)}
                  </div>
                  <p className="text-xs text-slate-400 font-medium">
                    {disease.category[language]} • ICD: {disease.outpatientPrescription.diagnosisCode.split(' - ')[0]}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCopyPrescription(disease);
                    }}
                    id={`copy-btn-${disease.id}`}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition ${
                      copiedId === disease.id
                        ? 'bg-emerald-600 text-white border-emerald-500'
                        : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
                    }`}
                    title="e-Reçeteyi Panoya Kopyala"
                  >
                    {copiedId === disease.id ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">{t('copiedToClipboard')}</span>
                        <span className="sm:hidden">Kopyalandı</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="hidden sm:inline">{t('copyPrescription')}</span>
                        <span className="sm:hidden">Reçete</span>
                      </>
                    )}
                  </button>

                  <div className="p-1 text-slate-400">
                    {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                  </div>
                </div>
              </div>

              {/* Accordion Content */}
              {isExpanded && (
                <div className="p-4 pt-0 border-t border-slate-800/80 space-y-4 text-xs">
                  {/* Summary */}
                  <div className="mt-3 bg-slate-950/70 p-3 rounded-xl border border-slate-800 text-slate-300 leading-relaxed">
                    {disease.summary[language]}
                  </div>

                  {/* Clinical Keys & Must Knows */}
                  <div className="bg-sky-950/30 p-3.5 rounded-xl border border-sky-900/40 space-y-1.5">
                    <h4 className="font-bold text-sky-400 flex items-center gap-1.5">
                      <Pill className="w-4 h-4" />
                      {language === 'tr' ? 'İntörn İçin Klinik Püf Noktalar' : 'Clinical High-Yield Keys'}
                    </h4>
                    <ul className="list-disc list-inside space-y-1 text-slate-200">
                      {disease.clinicalKeys[language].map((key, i) => (
                        <li key={i}>{key}</li>
                      ))}
                    </ul>
                  </div>

                  {/* ER In-House Order */}
                  <div className="bg-slate-950/90 p-3.5 rounded-xl border border-slate-800 space-y-2">
                    <h4 className="font-bold text-amber-400 flex items-center gap-1.5">
                      <Syringe className="w-4 h-4" />
                      {t('erOrder')}
                    </h4>
                    {disease.erOrder.fluids && (
                      <div className="text-slate-300">
                        <strong className="text-slate-200">Mayi (IV Sıvı): </strong>
                        {disease.erOrder.fluids[language]}
                      </div>
                    )}
                    <div className="space-y-1">
                      <strong className="text-slate-200">Acil İlaç Uygulaması:</strong>
                      <ul className="list-disc list-inside space-y-1 text-slate-300">
                        {disease.erOrder.medications[language].map((med, idx) => (
                          <li key={idx} className="whitespace-pre-line">{med}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Red Flags For Consultation */}
                  <div className="bg-rose-950/40 p-3.5 rounded-xl border border-rose-900/60 space-y-1.5">
                    <h4 className="font-bold text-rose-400 flex items-center gap-1.5">
                      <AlertOctagon className="w-4 h-4" />
                      {t('redFlagsTitle')}
                    </h4>
                    <ul className="list-disc list-inside space-y-1 text-rose-200">
                      {disease.redFlagsForConsultation[language].map((rf, i) => (
                        <li key={i}>{rf}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Full Outpatient e-Prescription Box */}
                  <div className="bg-emerald-950/30 p-4 rounded-xl border border-emerald-800/60 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-emerald-400 flex items-center gap-1.5 text-sm">
                        <FileText className="w-4 h-4" />
                        {disease.outpatientPrescription.diagnosisName[language]}
                      </h4>
                      <span className="font-mono text-[11px] font-bold text-emerald-300 bg-emerald-900/60 px-2 py-0.5 rounded border border-emerald-700/50">
                        ICD-10: {disease.outpatientPrescription.diagnosisCode}
                      </span>
                    </div>

                    <div className="space-y-2">
                      {disease.outpatientPrescription.items.map((item, idx) => (
                        <div
                          key={idx}
                          className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 space-y-1"
                        >
                          <div className="flex items-center justify-between flex-wrap gap-1">
                            <span className="font-bold text-white text-xs">
                              {idx + 1}. {item.drugName}
                            </span>
                            <span className="text-[11px] font-mono font-bold text-amber-300 bg-amber-950/60 border border-amber-800/50 px-2 py-0.5 rounded">
                              {item.boxCount}
                            </span>
                          </div>
                          <p className="text-slate-400 text-[11px]">
                            Etken Madde: <span className="text-slate-300 font-medium">{item.activeIngredient}</span>
                          </p>
                          <p className="text-emerald-300 font-mono font-semibold text-xs">
                            {item.dosageInstructions[language]}
                          </p>
                          {item.notes && (
                            <p className="text-slate-400 italic text-[11px] mt-1 border-t border-slate-800 pt-1">
                              Not: {item.notes[language]}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Non-Pharmacological Advice */}
                  <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 space-y-1.5">
                    <h4 className="font-bold text-slate-300 flex items-center gap-1.5">
                      <HeartHandshake className="w-4 h-4 text-sky-400" />
                      {t('nonPharmAdvice')}
                    </h4>
                    <ul className="list-disc list-inside space-y-1 text-slate-300">
                      {disease.outpatientPrescription.nonPharmacologicalAdvice[language].map((adv, i) => (
                        <li key={i}>{adv}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Return Criteria */}
                  <div className="bg-amber-950/20 p-3.5 rounded-xl border border-amber-900/40 space-y-1.5">
                    <h4 className="font-bold text-amber-400 flex items-center gap-1.5">
                      <ShieldAlert className="w-4 h-4" />
                      {t('returnCriteria')}
                    </h4>
                    <ul className="list-disc list-inside space-y-1 text-amber-200">
                      {disease.returnToERCriteria[language].map((rc, i) => (
                        <li key={i}>{rc}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
