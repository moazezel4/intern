import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { CLINICAL_HISTORY_PROTOCOLS } from '../data/historyTakingData';
import { ClinicalHistoryProtocol } from '../types';
import {
  Stethoscope,
  MessageSquare,
  AlertCircle,
  HelpCircle,
  Activity,
  GitPullRequest,
  CheckSquare,
  Square,
  Sparkles,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';

export const HistoryTakingView: React.FC = () => {
  const { language, t } = useLanguage();
  const [selectedProtocolId, setSelectedProtocolId] = useState<string>(
    CLINICAL_HISTORY_PROTOCOLS[0].id
  );
  // Store answered questions per protocol: { [protocolId]: { [questionId]: boolean } }
  const [checkedAnswers, setCheckedAnswers] = useState<Record<string, Record<string, boolean>>>({});

  const activeProtocol =
    CLINICAL_HISTORY_PROTOCOLS.find((p) => p.id === selectedProtocolId) ||
    CLINICAL_HISTORY_PROTOCOLS[0];

  const handleToggleQuestion = (protocolId: string, qId: string) => {
    setCheckedAnswers((prev) => {
      const currentProtocolAnswers = prev[protocolId] || {};
      return {
        ...prev,
        [protocolId]: {
          ...currentProtocolAnswers,
          [qId]: !currentProtocolAnswers[qId],
        },
      };
    });
  };

  const handleClearProtocolAnswers = (protocolId: string) => {
    setCheckedAnswers((prev) => ({
      ...prev,
      [protocolId]: {},
    }));
  };

  // Calculate live score for questions that contribute to a score
  const currentAnswers = checkedAnswers[activeProtocol.id] || {};
  const totalCalculatedPoints = activeProtocol.mustAskQuestions.reduce((acc, q) => {
    if (currentAnswers[q.id] && q.scoreContribution) {
      return acc + q.scoreContribution.points;
    }
    return acc;
  }, 0);

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 shadow-md">
        <div className="flex items-center gap-2 mb-3">
          <div className="p-2 rounded-xl bg-sky-500/10 text-sky-400 border border-sky-500/20">
            <Stethoscope className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">
              {language === 'tr'
                ? 'Pratik Yatak Başı Anamnez & Hikaye Alma Rehberi'
                : 'Bedside Practical Clinical History Protocols'}
            </h2>
            <p className="text-xs text-slate-400">
              {language === 'tr'
                ? 'Hastaya doğrudan sorulacak Türkçe kalıp sorular, tanısal gerekçeler, yatak başı muayene ve klinik akış'
                : 'Practical patient-directed questions, clinical rationale, physical exam steps, and diagnostic flow'}
            </p>
          </div>
        </div>

        {/* Protocol Selector Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pt-2 pb-1 scrollbar-none">
          {CLINICAL_HISTORY_PROTOCOLS.map((protocol) => {
            const isSelected = protocol.id === activeProtocol.id;
            return (
              <button
                key={protocol.id}
                id={`protocol-tab-${protocol.id}`}
                onClick={() => setSelectedProtocolId(protocol.id)}
                className={`px-3.5 py-2 text-xs font-bold rounded-xl whitespace-nowrap transition flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-sky-600 text-white shadow-md shadow-sky-600/30'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span>{protocol.condition[language].split(' - ')[0]}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Protocol Content */}
      <div className="space-y-4">
        {/* Title & Overview Card */}
        <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 space-y-2">
          <div className="flex items-start justify-between gap-2 flex-wrap">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-sky-400 bg-sky-950/80 border border-sky-800/60 px-2 py-0.5 rounded">
                {activeProtocol.chiefComplaint[language]}
              </span>
              <h3 className="text-lg font-bold text-white mt-1">
                {activeProtocol.condition[language]}
              </h3>
            </div>
            {activeProtocol.associatedScoreId && (
              <div className="bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-right">
                <span className="text-[10px] text-slate-400 font-semibold block">
                  {language === 'tr' ? 'Hesaplanan Skor' : 'Accumulated Score'}
                </span>
                <span className="text-base font-extrabold text-amber-400 font-mono">
                  {totalCalculatedPoints.toFixed(1)} Puan
                </span>
              </div>
            )}
          </div>

          <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3 rounded-xl border border-slate-800/60">
            {activeProtocol.overview[language]}
          </p>
        </div>

        {/* Practical Questions to Ask the Patient */}
        <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-white text-sm flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-sky-400" />
              {t('askPatientHeading')}
            </h4>
            <button
              onClick={() => handleClearProtocolAnswers(activeProtocol.id)}
              className="text-[11px] text-slate-400 hover:text-rose-400 font-semibold transition"
            >
              {t('clearAnswers')}
            </button>
          </div>

          <p className="text-xs text-slate-400">
            {language === 'tr'
              ? 'Hastaya yatak başında sorarken aşağıdaki kalıp cümleleri kullanın ve hasta "Evet" dedikçe kutucuğu işaretleyin:'
              : 'Use the following exact conversational phrases at bedside. Check the box if patient answers "Yes":'}
          </p>

          <div className="space-y-2.5">
            {activeProtocol.mustAskQuestions.map((q) => {
              const isChecked = !!currentAnswers[q.id];
              return (
                <div
                  key={q.id}
                  id={`question-item-${q.id}`}
                  onClick={() => handleToggleQuestion(activeProtocol.id, q.id)}
                  className={`p-3.5 rounded-xl border transition cursor-pointer select-none ${
                    isChecked
                      ? 'bg-sky-950/40 border-sky-700/80 shadow-sm'
                      : 'bg-slate-950/70 border-slate-800/80 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <button
                      className="mt-0.5 text-sky-400 focus:outline-none"
                      aria-label="Toggle question check"
                    >
                      {isChecked ? (
                        <CheckSquare className="w-5 h-5 text-sky-400 fill-sky-950" />
                      ) : (
                        <Square className="w-5 h-5 text-slate-500" />
                      )}
                    </button>

                    <div className="flex-1 space-y-1.5">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <span className="font-bold text-slate-200 text-xs">
                          {q.question[language]}
                        </span>
                        {q.scoreContribution && (
                          <span className="text-[10px] font-mono font-bold text-amber-300 bg-amber-950/60 border border-amber-800/50 px-1.5 py-0.5 rounded">
                            +{q.scoreContribution.points} pts ({q.scoreContribution.scoreName})
                          </span>
                        )}
                      </div>

                      {/* Exact Turkish phrase */}
                      <div className="bg-slate-900/90 p-2.5 rounded-lg border border-slate-800/80 text-xs">
                        <span className="text-slate-400 font-semibold block text-[11px] mb-0.5">
                          🗣️ {t('patientSays')}
                        </span>
                        <p className="text-amber-200 font-medium italic">
                          {q.patientFriendlyPhraseTR}
                        </p>
                      </div>

                      {/* Rationale */}
                      <div className="text-[11px] text-slate-400 flex items-start gap-1.5">
                        <HelpCircle className="w-3.5 h-3.5 text-sky-400 shrink-0 mt-0.5" />
                        <span>
                          <strong className="text-slate-300">{t('rationale')} </strong>
                          {q.rationale[language]}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Physical Exam Checklist */}
        <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 space-y-2">
          <h4 className="font-bold text-white text-sm flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            {language === 'tr' ? 'Yatak Başı Fizik Muayene & EKG İpuçları' : 'Physical Exam & Bedside Findings'}
          </h4>
          <ul className="list-disc list-inside space-y-1.5 text-xs text-slate-300 bg-slate-950/60 p-3 rounded-xl border border-slate-800/60">
            {activeProtocol.physicalExamMusts[language].map((item, idx) => (
              <li key={idx} className="whitespace-pre-line leading-relaxed">{item}</li>
            ))}
          </ul>
        </div>

        {/* Diagnostic & Management Pathway */}
        <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 space-y-3">
          <h4 className="font-bold text-white text-sm flex items-center gap-2">
            <GitPullRequest className="w-4 h-4 text-purple-400" />
            {t('diagnosticPathway')}
          </h4>

          <div className="space-y-2.5">
            {activeProtocol.diagnosticPathway.map((path) => (
              <div
                key={path.step}
                className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-xs space-y-1"
              >
                <span className="font-bold text-purple-300 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-purple-950 border border-purple-700 text-purple-200 flex items-center justify-center text-[10px]">
                    {path.step}
                  </span>
                  {path.title[language]}
                </span>
                <p className="text-slate-300 leading-relaxed pl-6 whitespace-pre-line">
                  {path.description[language]}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Differential Diagnoses */}
        <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 space-y-2">
          <h4 className="font-bold text-white text-sm flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            {language === 'tr' ? 'Ayırıcı Tanıda Asla Atlanmaması Gerekenler' : 'Must-Not-Miss Differentials'}
          </h4>
          <div className="flex flex-wrap gap-1.5">
            {activeProtocol.differentialDiagnoses[language].map((diff, i) => (
              <span
                key={i}
                className="px-2.5 py-1 rounded-md bg-rose-950/40 border border-rose-800/50 text-rose-200 text-xs font-medium"
              >
                {diff}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
