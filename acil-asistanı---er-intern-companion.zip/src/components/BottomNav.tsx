import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Pill, FileText, Stethoscope, Calculator, Sparkles, BookOpen } from 'lucide-react';

export type TabType = 'drugs' | 'prescriptions' | 'history' | 'calculators' | 'pearls' | 'ai';

interface BottomNavProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  const { t } = useLanguage();

  const navItems = [
    { id: 'drugs' as TabType, label: t('drugsTab'), icon: Pill, color: 'text-rose-500' },
    { id: 'prescriptions' as TabType, label: t('prescriptionsTab'), icon: FileText, color: 'text-emerald-500' },
    { id: 'history' as TabType, label: t('historyTab'), icon: Stethoscope, color: 'text-sky-500' },
    { id: 'calculators' as TabType, label: t('calculatorsTab'), icon: Calculator, color: 'text-amber-500' },
    { id: 'pearls' as TabType, label: t('pearlsTab'), icon: BookOpen, color: 'text-purple-500' },
    { id: 'ai' as TabType, label: t('aiConsultantTab'), icon: Sparkles, color: 'text-indigo-500' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 px-2 py-1.5 shadow-2xl">
      <div className="max-w-md mx-auto grid grid-cols-6 gap-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav-btn-${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all ${
                isActive
                  ? 'text-white bg-slate-800/90 font-bold scale-105'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform ${
                    isActive ? `${item.color} scale-110` : 'text-slate-400'
                  }`}
                />
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-rose-500 rounded-full" />
                )}
              </div>
              <span
                className={`text-[10px] tracking-tight mt-1 truncate max-w-full ${
                  isActive ? 'text-slate-100 font-semibold' : 'text-slate-400'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
