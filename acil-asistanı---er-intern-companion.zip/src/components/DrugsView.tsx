import React, { useState, useMemo } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { ER_DRUGS_DATABASE } from '../data/drugsData';
import { ERDrug } from '../types';
import {
  Search,
  Pill,
  AlertTriangle,
  Info,
  CheckCircle2,
  ChevronRight,
  X,
  HeartPulse,
  Droplets,
  ShieldAlert,
} from 'lucide-react';

export const DrugsView: React.FC = () => {
  const { language, t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedDrug, setSelectedDrug] = useState<ERDrug | null>(null);

  // Extract unique categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    ER_DRUGS_DATABASE.forEach((drug) => set.add(drug.category[language]));
    return Array.from(set);
  }, [language]);

  // Filtered drugs
  const filteredDrugs = useMemo(() => {
    return ER_DRUGS_DATABASE.filter((drug) => {
      const matchCategory =
        selectedCategory === 'all' || drug.category[language] === selectedCategory;

      const q = searchQuery.toLowerCase().trim();
      if (!q) return matchCategory;

      const matchGeneric =
        drug.genericName.tr.toLowerCase().includes(q) ||
        drug.genericName.en.toLowerCase().includes(q);
      const matchTRBrand = drug.brandNamesTR.some((b) => b.toLowerCase().includes(q));
      const matchCategoryText = drug.category[language].toLowerCase().includes(q);
      const matchIndication = drug.indications[language].some((ind) =>
        ind.toLowerCase().includes(q)
      );

      return matchCategory && (matchGeneric || matchTRBrand || matchCategoryText || matchIndication);
    });
  }, [searchQuery, selectedCategory, language]);

  return (
    <div className="space-y-4 pb-20">
      {/* Search Header */}
      <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 shadow-md">
        <div className="flex items-center gap-2 mb-3">
          <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20">
            <Pill className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">
              {language === 'tr' ? 'Türkiye Acil Servis İlaç Rehberi' : 'Turkey ER Drug Guide'}
            </h2>
            <p className="text-xs text-slate-400">
              {language === 'tr'
                ? 'Acilde kullanılan jenerik ve Türkiye ticari isimleri, dozaj, sulandırma ve kırmızı bayraklar'
                : 'Generic & Turkey trade names, dosing, dilution instructions, and contraindications'}
            </p>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            id="drug-search-input"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('searchPlaceholder')}
            className="w-full bg-slate-950/80 text-slate-100 placeholder-slate-500 text-sm rounded-xl pl-10 pr-10 py-2.5 border border-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-transparent transition"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Category Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-3 pb-1 scrollbar-none">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1 text-xs font-semibold rounded-full whitespace-nowrap transition ${
              selectedCategory === 'all'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {t('allCategories')} ({ER_DRUGS_DATABASE.length})
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 text-xs font-semibold rounded-full whitespace-nowrap transition ${
                selectedCategory === cat
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Drug List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {filteredDrugs.map((drug) => (
          <div
            key={drug.id}
            id={`drug-card-${drug.id}`}
            onClick={() => setSelectedDrug(drug)}
            className="bg-slate-900/70 hover:bg-slate-800/90 rounded-xl p-4 border border-slate-800/80 hover:border-slate-700 cursor-pointer transition-all shadow-sm group"
          >
            <div className="flex items-start justify-between gap-2 mb-2">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base font-bold text-white group-hover:text-rose-400 transition">
                    {drug.genericName[language]}
                  </h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                    {drug.category[language]}
                  </span>
                </div>
                {/* Turkey Brand Names Highlight */}
                <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                  <span className="text-[11px] font-semibold text-rose-300 bg-rose-950/60 border border-rose-800/50 px-2 py-0.5 rounded">
                    🇹🇷 {drug.brandNamesTR.join(', ')}
                  </span>
                </div>
              </div>

              {/* Routes */}
              <div className="flex flex-col items-end gap-1">
                <div className="flex items-center gap-1">
                  {drug.administration.route.map((r) => (
                    <span
                      key={r}
                      className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-sky-950 text-sky-300 border border-sky-800/60"
                    >
                      {r}
                    </span>
                  ))}
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500 group-hover:translate-x-0.5 group-hover:text-slate-300 transition" />
              </div>
            </div>

            {/* Quick Dose Info */}
            <div className="bg-slate-950/60 rounded-lg p-2.5 border border-slate-800/60 mt-2 text-xs space-y-1">
              <div className="flex items-start gap-1.5 text-slate-200">
                <span className="font-semibold text-amber-400 min-w-[70px]">{t('adultDose')}:</span>
                <span className="text-slate-300 line-clamp-1">{drug.erAdultDose[language]}</span>
              </div>
              <div className="flex items-start gap-1.5 text-slate-400">
                <span className="font-semibold text-sky-400 min-w-[70px]">{t('administrationInfo')}:</span>
                <span className="text-slate-300 line-clamp-1">{drug.administration.preparation[language]}</span>
              </div>
            </div>
          </div>
        ))}

        {filteredDrugs.length === 0 && (
          <div className="col-span-full py-12 text-center text-slate-400 space-y-2">
            <Info className="w-8 h-8 mx-auto text-slate-500" />
            <p className="text-sm font-medium">{t('noResultsFound')}</p>
            <p className="text-xs text-slate-500">
              "{searchQuery}" aramasına uygun ilaç bulunamadı.
            </p>
          </div>
        )}
      </div>

      {/* Drug Detail Modal */}
      {selectedDrug && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-800 flex items-start justify-between bg-slate-950/80">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-bold text-white">
                    {selectedDrug.genericName[language]}
                  </h3>
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                    {selectedDrug.category[language]}
                  </span>
                </div>
                <div className="mt-1 flex items-center gap-1.5 flex-wrap">
                  <span className="text-xs font-semibold text-rose-300 bg-rose-950/80 border border-rose-700/60 px-2 py-0.5 rounded">
                    🇹🇷 {t('brandNamesInTR')}: {selectedDrug.brandNamesTR.join(', ')}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedDrug(null)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 overflow-y-auto space-y-4 text-xs">
              {/* Indications */}
              <div>
                <h4 className="font-bold text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  {language === 'tr' ? 'Acil Endikasyonları' : 'ER Indications'}
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {selectedDrug.indications[language].map((ind, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-md bg-emerald-950/60 border border-emerald-800/60 text-emerald-200 text-xs font-medium"
                    >
                      {ind}
                    </span>
                  ))}
                </div>
              </div>

              {/* Adult & Pediatric Doses */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-amber-400 font-bold flex items-center gap-1">
                    <HeartPulse className="w-3.5 h-3.5" />
                    {t('adultDose')}
                  </span>
                  <p className="text-slate-200 leading-relaxed font-medium">
                    {selectedDrug.erAdultDose[language]}
                  </p>
                </div>

                <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-sky-400 font-bold flex items-center gap-1">
                    <Droplets className="w-3.5 h-3.5" />
                    {t('pediatricDose')}
                  </span>
                  <p className="text-slate-200 leading-relaxed font-medium">
                    {selectedDrug.erPediatricDose
                      ? selectedDrug.erPediatricDose[language]
                      : language === 'tr'
                      ? 'Pediatrik dozu uzman konsültasyonuyla ayarlayınız.'
                      : 'Adjust with pediatric specialist.'}
                  </p>
                </div>
              </div>

              {/* Administration & Dilution */}
              <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 space-y-1.5">
                <span className="text-sky-300 font-bold flex items-center gap-1.5">
                  <Info className="w-4 h-4" />
                  {t('administrationInfo')}
                </span>
                <p className="text-slate-200 leading-relaxed whitespace-pre-line">
                  {selectedDrug.administration.preparation[language]}
                </p>
                {selectedDrug.administration.infusionRate && (
                  <p className="text-amber-300 font-mono text-[11px] pt-1">
                    ⏱️ İnfüzyon Süresi: {selectedDrug.administration.infusionRate[language]}
                  </p>
                )}
              </div>

              {/* Contraindications */}
              <div className="bg-rose-950/30 p-3.5 rounded-xl border border-rose-900/50 space-y-1.5">
                <span className="text-rose-400 font-bold flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4" />
                  {t('contraindications')}
                </span>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  {selectedDrug.contraindications[language].map((c, i) => (
                    <li key={i}>{c}</li>
                  ))}
                </ul>
              </div>

              {/* Precautions / Red Flags */}
              <div className="bg-amber-950/30 p-3.5 rounded-xl border border-amber-900/50 space-y-1.5">
                <span className="text-amber-400 font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4" />
                  {t('precautions')}
                </span>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  {selectedDrug.redFlagsAndPrecautions[language].map((p, i) => (
                    <li key={i}>{p}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-slate-950 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedDrug(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition"
              >
                {language === 'tr' ? 'Kapat' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
