import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import {
  Sparkles,
  Send,
  Loader2,
  Bot,
  User,
  Copy,
  Check,
  AlertCircle,
  HelpCircle,
  Stethoscope,
  Trash2,
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export const AIConsultantView: React.FC = () => {
  const { language, t } = useLanguage();
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content:
        language === 'tr'
          ? `Merhaba Meslektaşım! 🩺 Ben Acil Servis Kıdemli AI Konsültanınızım.

Acil nöbetinizde karşılaştığınız:
- Zorlu vaka ayırıcı tanıları & anamnez stratejileri
- Türkiye'de bulunan ticari ilaç isimleri ve acil dozajları
- e-Reçete şablonları ve SGK endikasyon uyumu
- EKG / Kan Gazı / Triyaj değerlendirmeleri

hakkında bana dilediğinizi sorabilirsiniz. Aşağıdaki hızlı vaka butonlarını deneyebilir veya kendi vakanızı yazabilirsiniz!`
          : `Hello Colleague! 🩺 I am your Senior ER AI Co-Pilot.

Feel free to ask about:
- Difficult differential diagnoses & history taking in ER
- Brand drug names in Turkey, emergency dosages, and dilutions
- Medula e-Prescription templates
- ECG / Blood Gas interpretation

Type your case below or tap any of the quick case prompts!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const quickPromptsTR = [
    '55 yaş erkek, epigastrik yanma ve soğuk terleme ile geldi. EKG\'de V1-V4 ST depresyonu var. Acil yaklaşım?',
    'Gebelikte akut nefes darlığı ve taşikardi: Pulmoner Emboli tanı ve antikoagülasyon algoritması nedir?',
    'Penisilin alerjisi olan erişkin akut tonsillit hastasına Türkiye\'de yazılabilecek e-reçete?',
    'Renal kolik atağında IV NSAİİ\'ye yanıt vermeyen şiddetli ağrıda 2. ve 3. basamak acil tedavi?',
  ];

  const quickPromptsEN = [
    '55 yo male with epigastric burning and diaphoresis. ST depressions in V1-V4. Urgent management?',
    'Acute dyspnea and tachycardia in pregnancy: Diagnostic & anticoagulation algorithm for PE?',
    'Outpatient prescription for acute bacterial tonsillitis in a patient with severe penicillin allergy?',
    'Refractory renal colic pain unresponsive to IV NSAIDs: 2nd and 3rd line ER analgesia?',
  ];

  const quickPrompts = language === 'tr' ? quickPromptsTR : quickPromptsEN;

  const handleSendMessage = async (userText: string) => {
    if (!userText.trim() || loading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setPrompt('');
    setLoading(true);

    try {
      const response = await fetch('/api/gemini/consult', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userText,
          language,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.reply || (language === 'tr' ? 'Yanıt alınamadı.' : 'No response received.'),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content:
          language === 'tr'
            ? `Bağlantı hatası oluştu: ${err.message || 'Lütfen tekrar deneyiniz.'}`
            : `Connection error: ${err.message || 'Please try again.'}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleCopyMessage = (msg: ChatMessage) => {
    navigator.clipboard.writeText(msg.content);
    setCopiedId(msg.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearChat = () => {
    setMessages([messages[0]]);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header card */}
      <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 shadow-md">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                {language === 'tr' ? 'Acil Klinik AI Konsültan' : 'ER Senior AI Co-Pilot'}
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                  Gemini 3.7 Flash
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {language === 'tr'
                  ? '7/24 Yatak başı klinik danışman, Türkiye ilaç ve reçete asistanı'
                  : '24/7 Bedside clinical decision support and Turkey prescription helper'}
              </p>
            </div>
          </div>

          <button
            onClick={handleClearChat}
            className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition"
            title="Sohbeti Temizle"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="mt-3 space-y-1.5">
          <span className="text-[11px] font-semibold text-slate-400 block">
            {language === 'tr' ? 'Örnek Acil Vakaları:' : 'Quick Emergency Prompts:'}
          </span>
          <div className="flex flex-wrap gap-1.5">
            {quickPrompts.map((qp, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(qp)}
                disabled={loading}
                className="text-[11px] text-left p-2 rounded-lg bg-slate-950/80 hover:bg-indigo-950/60 border border-slate-800 hover:border-indigo-700/60 text-slate-300 hover:text-indigo-200 transition"
              >
                💡 {qp}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Messages Feed */}
      <div className="space-y-3">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-8 h-8 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0 mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[88%] sm:max-w-[80%] rounded-2xl p-4 border text-xs leading-relaxed space-y-2 relative group ${
                  isUser
                    ? 'bg-rose-600 text-white border-rose-500 rounded-tr-none shadow-md shadow-rose-600/20'
                    : 'bg-slate-900/90 text-slate-200 border-slate-800 rounded-tl-none shadow-sm'
                }`}
              >
                <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-1.5 mb-1.5">
                  <span className="font-bold text-[11px] flex items-center gap-1">
                    {isUser
                      ? (language === 'tr' ? 'İntörn Hekim' : 'Intern Doctor')
                      : (language === 'tr' ? 'Acil Kıdemli Konsültan' : 'Senior ER Attending')}
                  </span>
                  <span className="text-[10px] opacity-70 font-mono">{msg.timestamp}</span>
                </div>

                <div className="whitespace-pre-wrap leading-relaxed">
                  {msg.content}
                </div>

                {!isUser && (
                  <div className="pt-2 flex justify-end">
                    <button
                      onClick={() => handleCopyMessage(msg)}
                      className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white p-1 rounded transition"
                      title="Metni Kopyala"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400 font-semibold">{t('copiedToClipboard')}</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Kopyala</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>

              {isUser && (
                <div className="w-8 h-8 rounded-xl bg-rose-600 flex items-center justify-center text-white shrink-0 mt-1 shadow-md shadow-rose-600/30">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {loading && (
          <div className="flex gap-3 justify-start">
            <div className="w-8 h-8 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
              <Bot className="w-4 h-4 animate-spin" />
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-none p-4 text-xs text-indigo-300 flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
              <span>{t('asking')}</span>
            </div>
          </div>
        )}
      </div>

      {/* Input Box */}
      <div className="sticky bottom-16 z-30 bg-slate-950/90 backdrop-blur-md p-2 rounded-2xl border border-slate-800 shadow-xl">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage(prompt);
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            id="ai-prompt-input"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={t('askAIPlaceholder')}
            disabled={loading}
            className="flex-1 bg-slate-900 text-white placeholder-slate-500 text-xs rounded-xl px-4 py-3 border border-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
          />
          <button
            type="submit"
            id="ai-submit-btn"
            disabled={loading || !prompt.trim()}
            className="px-4 py-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/30 flex items-center gap-1.5 transition active:scale-95 shrink-0"
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span className="hidden sm:inline">{t('askButton')}</span>
              </>
            )}
          </button>
        </form>
        <p className="text-[10px] text-slate-500 text-center mt-1.5">
          {t('aiDisclaimer')}
        </p>
      </div>
    </div>
  );
};
