import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language } from '../types';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, enDefault?: string) => string;
}

const translations: Record<string, { tr: string; en: string }> = {
  // App Title & Nav
  appName: { tr: 'Acil Asistanı', en: 'ER Intern Companion' },
  appSubtitle: { tr: 'İntörn & Pratisyen Hekim Acil Rehberi', en: 'Emergency Medicine Pocket Guide' },
  drugsTab: { tr: 'İlaçlar', en: 'Drugs' },
  prescriptionsTab: { tr: 'Reçeteler', en: 'Prescriptions' },
  historyTab: { tr: 'Anamnez', en: 'History Taking' },
  calculatorsTab: { tr: 'Skorlar & Hesap', en: 'Calculators' },
  pearlsTab: { tr: 'Nöbet İpuçları', en: 'Shift Pearls' },
  aiConsultantTab: { tr: 'AI Konsültan', en: 'AI Co-Pilot' },

  // General Actions & Labels
  searchPlaceholder: { tr: 'İlaç, ticari isim, hastalık, semptom ara...', en: 'Search drugs, brand names, diseases, symptoms...' },
  allCategories: { tr: 'Tüm Kategoriler', en: 'All Categories' },
  favorites: { tr: 'Favorilerim', en: 'My Favorites' },
  noResultsFound: { tr: 'Sonuç bulunamadı', en: 'No results found' },
  copyPrescription: { tr: 'Reçeteyi Kopyala', en: 'Copy Prescription' },
  copiedToClipboard: { tr: 'Panoya Kopyalandı!', en: 'Copied to clipboard!' },
  erOrder: { tr: 'Acil Servis İçi Order / Uygulama', en: 'ER Bedside Order' },
  outpatientPrescription: { tr: 'Taburculuk e-Reçetesi (SGK / Medula Uyumlu)', en: 'Outpatient Discharge Prescription' },
  redFlagsTitle: { tr: 'Kırmızı Bayraklar & Konsültasyon', en: 'Red Flags & Consultations' },
  nonPharmAdvice: { tr: 'Hastaya Yaşam Tarzı ve Diyet Önerileri', en: 'Patient Lifestyle & Dietary Advice' },
  returnCriteria: { tr: 'Acile Tekrar Başvuru Kriterleri', en: 'Return to ER Warning Signs' },
  askPatientHeading: { tr: 'Hastaya Yatak Başında Sorulacak Sorular', en: 'Bedside Questions to Ask the Patient' },
  patientSays: { tr: 'Hastaya söylenecek kalıp cümle:', en: 'Exact phrase to say to patient:' },
  rationale: { tr: 'Klinik Önemi & Gerekçesi:', en: 'Clinical Rationale:' },
  diagnosticPathway: { tr: 'Acil Tanı ve Yönetim Algoritması', en: 'Diagnostic & Management Pathway' },
  calculateScore: { tr: 'Skoru Hesapla', en: 'Calculate Score' },
  totalScore: { tr: 'Toplam Skor:', en: 'Total Score:' },
  riskInterpretation: { tr: 'Klinik Yorum & Yönetim Önerisi', en: 'Interpretation & Management' },
  aiDisclaimer: { tr: 'Gemini 3.7 Flash ile desteklenmektedir. Klinik karar hekimin sorumluluğundadır.', en: 'Powered by Gemini 3.7 Flash. Clinical decisions remain the sole responsibility of the physician.' },
  askAIPlaceholder: { tr: 'Vaka sorusu, ilaç dozu, ayırıcı tanı veya reçete önerisi isteyin...', en: 'Ask a case question, drug dosing, differential diagnosis, or prescription query...' },
  askButton: { tr: 'Konsülte Et', en: 'Consult AI' },
  asking: { tr: 'Yanıtlanıyor...', en: 'Consulting...' },
  clearAnswers: { tr: 'Seçimleri Temizle', en: 'Clear Selections' },
  brandNamesInTR: { tr: 'Türkiye\'de Mevcut Ticari İsimler', en: 'Brand Names Available in Turkey' },
  adultDose: { tr: 'Acil Yetişkin Dozu', en: 'Adult ER Dose' },
  pediatricDose: { tr: 'Pediatrik Doz', en: 'Pediatric Dose' },
  administrationInfo: { tr: 'Uygulama Şekli & Sulandırma (Mayi)', en: 'Administration Route & Dilution' },
  contraindications: { tr: 'Kontrendikasyonlar', en: 'Contraindications' },
  precautions: { tr: 'Acilde Dikkat Edilecekler & Yan Etkiler', en: 'ER Precautions & Red Flags' },
  greenZone: { tr: 'Yeşil Alan', en: 'Green Zone' },
  yellowZone: { tr: 'Sarı Alan', en: 'Yellow Zone' },
  redZone: { tr: 'Kırmızı Alan', en: 'Red Zone' },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('er_app_lang');
    return saved === 'en' ? 'en' : 'tr';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('er_app_lang', lang);
  };

  const t = (key: string, enDefault?: string): string => {
    if (translations[key]) {
      return translations[key][language];
    }
    return enDefault || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
