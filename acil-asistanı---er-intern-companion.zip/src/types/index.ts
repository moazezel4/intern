export type Language = 'tr' | 'en';

export interface ERDrug {
  id: string;
  genericName: {
    tr: string;
    en: string;
  };
  brandNamesTR: string[]; // e.g. ["Parol", "Perfalgan", "Minoset"]
  category: {
    tr: string;
    en: string;
  };
  forms: string[]; // e.g. ["1000 mg / 100 ml IV Flakon", "500 mg Tablet", "120 mg/5ml Şurup"]
  indications: {
    tr: string[];
    en: string[];
  };
  erAdultDose: {
    tr: string;
    en: string;
  };
  erPediatricDose?: {
    tr: string;
    en: string;
  };
  administration: {
    route: string[]; // ["IV", "IM", "PO", "SC", "Inhaler"]
    preparation: {
      tr: string;
      en: string;
    };
    infusionRate?: {
      tr: string;
      en: string;
    };
  };
  contraindications: {
    tr: string[];
    en: string[];
  };
  redFlagsAndPrecautions: {
    tr: string[];
    en: string[];
  };
  pregnancyCategory?: string; // "A" | "B" | "C" | "D" | "X"
  tags: string[];
}

export interface PrescriptionItem {
  drugName: string; // e.g. "AUGMENTIN-BID 1000 mg 14 Film Tablet"
  activeIngredient: string;
  boxCount: string; // e.g. "DIB: 1 (Bir) Kutu"
  dosageInstructions: {
    tr: string;
    en: string;
  }; // e.g. "S: 2x1 Tok karnına 7 gün"
  notes?: {
    tr: string;
    en: string;
  };
}

export interface MinorDisease {
  id: string;
  title: {
    tr: string;
    en: string;
  };
  category: {
    tr: string;
    en: string;
  };
  triageColor: 'green' | 'yellow' | 'red';
  summary: {
    tr: string;
    en: string;
  };
  clinicalKeys: {
    tr: string[];
    en: string[];
  };
  redFlagsForConsultation: {
    tr: string[];
    en: string[];
  };
  erOrder: {
    ivAccess?: boolean;
    fluids?: {
      tr: string;
      en: string;
    };
    medications: {
      tr: string[];
      en: string[];
    };
    monitoring?: {
      tr: string;
      en: string;
    };
  };
  outpatientPrescription: {
    diagnosisCode: string; // ICD-10
    diagnosisName: {
      tr: string;
      en: string;
    };
    items: PrescriptionItem[];
    nonPharmacologicalAdvice: {
      tr: string[];
      en: string[];
    };
  };
  returnToERCriteria: {
    tr: string[];
    en: string[];
  };
}

export interface HistoryQuestion {
  id: string;
  question: {
    tr: string;
    en: string;
  };
  patientFriendlyPhraseTR: string; // Direct sentence to say to the patient in Turkish
  rationale: {
    tr: string;
    en: string;
  };
  isRedFlagAlert?: boolean;
  scoreContribution?: {
    scoreName: string;
    points: number;
  };
}

export interface ClinicalHistoryProtocol {
  id: string;
  condition: {
    tr: string;
    en: string;
  };
  chiefComplaint: {
    tr: string;
    en: string;
  };
  triagePriority: 'red' | 'yellow' | 'green';
  overview: {
    tr: string;
    en: string;
  };
  mustAskQuestions: HistoryQuestion[];
  differentialDiagnoses: {
    tr: string[];
    en: string[];
  };
  physicalExamMusts: {
    tr: string[];
    en: string[];
  };
  diagnosticPathway: {
    step: number;
    title: { tr: string; en: string };
    description: { tr: string; en: string };
  }[];
  associatedScoreId?: string;
}

export interface CalculatorScoreOption {
  label: { tr: string; en: string };
  points: number;
  description?: { tr: string; en: string };
}

export interface CalculatorScoreItem {
  id: string;
  label: { tr: string; en: string };
  options: CalculatorScoreOption[];
}

export interface ClinicalCalculator {
  id: string;
  name: { tr: string; en: string };
  shortName: string;
  category: { tr: string; en: string };
  description: { tr: string; en: string };
  items: CalculatorScoreItem[];
  interpretations: {
    minScore: number;
    maxScore: number;
    riskLevel: 'low' | 'moderate' | 'high';
    title: { tr: string; en: string };
    management: { tr: string; en: string };
  }[];
}

export interface ShiftPearl {
  id: string;
  title: { tr: string; en: string };
  category: { tr: string; en: string };
  iconName: string;
  content: {
    tr: string;
    en: string;
  };
  bulletPoints?: {
    tr: string[];
    en: string[];
  };
  isHighYield?: boolean;
}
