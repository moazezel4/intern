import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client (lazy/safe initialization)
let aiClient: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// AI ER Clinical Assistant Endpoint
app.post("/api/gemini/consult", async (req, res) => {
  try {
    const { query, prompt: promptInput, language = "tr", patientContext, mode = "general" } = req.body;
    const userQuery = query || promptInput;

    if (!userQuery) {
      return res.status(400).json({ error: "Query or prompt is required" });
    }

    const ai = getGeminiClient();
    if (!ai) {
      // Fallback helpful guidance if API key isn't provided yet
      return res.json({
        success: true,
        isFallback: true,
        reply: language === "tr"
          ? `[Sistem Bilgisi: AI Asistanı devrede. Çevrimdışı veritabanındaki tüm Türkiye onaylı ilaçlar, reçeteler, skorlar ve anamnez kılavuzları eksiksiz çalışmaktadır.]\n\nKlinik Öneri (${userQuery}): Acil serviste öncelikle ABCDE stabilizasyonunu sağlayın, kırmızı bayrak bulgularını (hemodinamik bozukluk, peritoneal bulgular, bilinç değişikliği) değerlendirin ve ilgili uzman hekime danışın.`
          : `[System Note: Offline emergency database is fully active with all Turkey medications, prescription guides, and clinical decision rules.]\n\nClinical Guidance for "${userQuery}": In emergency evaluation, prioritize ABCDE stabilization, check for high-risk red flags, and consult the attending specialist.`,
      });
    }

    const systemInstruction = language === "tr"
      ? `Sen Türkiye'de Acil Servis (ER) rotasyonundaki intörn ve pratisyen hekimlere rehberlik eden kıdemli Acil Tıp Uzmanı klinik asistanısın.
Kurallar:
1. Türkçe yanıt ver. İlaç isimlerinde Türkiye'de mevcut ticari isimleri (parantez içinde etken madde ile) belirt (Örn: Parol ampul [Parasetamol], Arveles ampul [Deksketoprofen], Rocephin flakon [Seftriakson], Buscopan ampul [Hiyosin-N-butilbromür]).
2. Hastaya tam olarak sorulması gereken soruları, kırmızı bayrakları (Red Flags), acil servis içi order'ı ve reçete posolojisini (Örn: 2x1 tok karnına) pratik, net ve madde madde sun.
3. Kırmızı, Sarı ve Yeşil alan triyaj ayrımını net yap.
4. Acil serviste hayati tehlike oluşturabilecek durumları (SAK, STEMI, Pulmoner Emboli, Aort Diseksiyonu, İleus vb.) asla atlama.`
      : `You are a Senior Emergency Medicine Specialist clinical assistant guiding intern and resident doctors in the Emergency Department in Turkey.
Rules:
1. Provide practical, high-yield clinical advice with both English and Turkish trade names available in Turkey (e.g. Parol [Paracetamol], Arveles [Dexketoprofen], Rocephin [Ceftriaxone]).
2. Provide exact bedside history questions to ask, Red Flags, immediate ER orders, and full outpatient prescription format.
3. Keep answers concise, high-contrast, structured, and easy to read quickly on a mobile phone during a busy ER shift.`;

    const prompt = `Mod: ${mode}
Dil: ${language}
${patientContext ? `Hasta/Vaka Bilgisi: ${JSON.stringify(patientContext)}` : ""}
Hekim Sorusu/Talep: ${query}

Lütfen acil serviste anında kullanılabilecek, pratik ve yapılandırılmış yanıt ver.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.2,
      },
    });

    res.json({
      success: true,
      reply: response.text,
    });
  } catch (error: any) {
    console.error("Gemini ER Consult Error:", error);
    res.status(500).json({
      error: "AI consultation temporarily unavailable",
      details: error?.message || String(error),
    });
  }
});

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Emergency Doctor Assistant server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
